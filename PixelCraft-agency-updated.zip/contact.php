<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Contact Us';
$pageDescription = 'Tell PixelCraft about your project. We reply within one business day with clear next steps, honest timelines, and a practical plan.';
$activePage = 'contact';

$settings = site_settings();
$services = featured_services(6);
$requestedService = trim((string) ($_GET['service'] ?? ''));
$defaultSubject = $requestedService !== '' ? 'Project enquiry: ' . $requestedService : '';

require __DIR__ . '/includes/header.php';
?>
<main id="mainContent">

  <section class="page-hero">
    <div class="container">
      <div class="page-hero__inner reveal">
        <nav class="breadcrumbs" aria-label="Breadcrumb">
          <a href="<?= e(url('index.php')) ?>">Home</a>
          <i data-lucide="chevron-right"></i>
          <span aria-current="page">Contact</span>
        </nav>
        <span class="eyebrow">Let's Talk</span>
        <h1>Tell us what you are building.</h1>
        <p>Share a little about your goals and we will reply within one business day. No hard sell, no automated sequence — just a useful conversation with someone senior.</p>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="contact-grid">
        <div class="contact-form-card reveal">
          <h2>Start a conversation</h2>
          <p>Fill in the form and we will get back to you shortly.</p>

          <form class="contact-form" action="<?= e(url('api/contact.php')) ?>" method="post" novalidate>
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <div class="honeypot" aria-hidden="true">
              <label for="contactWebsite">Website</label>
              <input type="text" id="contactWebsite" name="website" tabindex="-1" autocomplete="off">
            </div>

            <div class="form-row">
              <div class="form-group">
                <label for="contactName">Your name</label>
                <input class="form-control" type="text" id="contactName" name="name" placeholder="Jane Cooper" autocomplete="name" required>
                <span class="form-error" data-error-for="contactName"></span>
              </div>
              <div class="form-group">
                <label for="contactEmail">Email address</label>
                <input class="form-control" type="email" id="contactEmail" name="email" placeholder="jane@company.com" autocomplete="email" required>
                <span class="form-error" data-error-for="contactEmail"></span>
              </div>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label for="contactPhone">Phone <span class="optional">(optional)</span></label>
                <input class="form-control" type="tel" id="contactPhone" name="phone" placeholder="+92 300 123 4567" autocomplete="tel">
                <span class="form-error" data-error-for="contactPhone"></span>
              </div>
              <div class="form-group">
                <label for="contactSubject">What can we help with?</label>
                <select class="form-control" id="contactSubject" name="subject" required>
                  <option value="">Select a topic</option>
                  <option value="General enquiry"<?= $defaultSubject === '' ? ' selected' : '' ?>>General enquiry</option>
                  <?php foreach ($services as $service): ?>
                    <option value="Project enquiry: <?= e($service['title']) ?>"<?= $defaultSubject === 'Project enquiry: ' . $service['title'] ? ' selected' : '' ?>><?= e($service['title']) ?></option>
                  <?php endforeach; ?>
                  <option value="Careers">Careers</option>
                  <option value="Support">Support</option>
                  <?php if ($defaultSubject !== '' && !in_array($defaultSubject, array_map(static function (array $service): string {
                      return 'Project enquiry: ' . $service['title'];
                  }, $services), true)): ?>
                    <option value="<?= e($defaultSubject) ?>" selected><?= e($defaultSubject) ?></option>
                  <?php endif; ?>
                </select>
                <span class="form-error" data-error-for="contactSubject"></span>
              </div>
            </div>

            <div class="form-group">
              <label for="contactMessage">Tell us about your project</label>
              <textarea class="form-control" id="contactMessage" name="message" placeholder="A few words about your goals, timeline, and budget..." required></textarea>
              <span class="form-error" data-error-for="contactMessage"></span>
            </div>

            <div class="form-status" role="status" aria-live="polite"></div>

            <button class="btn btn-primary" type="submit">
              Send Message
              <i data-lucide="send"></i>
            </button>
          </form>

          <div class="form-success" data-form-success role="status" aria-live="polite">
            <span class="success-icon"><i data-lucide="check"></i></span>
            <h3>Thanks for reaching out!</h3>
            <p>Your message is with our team. We will reply within one business day.</p>
            <a class="btn btn-outline btn-sm" href="<?= e(url('portfolio.php')) ?>">See Our Work</a>
          </div>
        </div>

        <div class="contact-info-stack reveal delay-2">
          <div class="contact-info-card">
            <span class="icon-tile icon-tile--sm tint-blue"><i data-lucide="mail"></i></span>
            <div>
              <h3>Email us</h3>
              <a href="mailto:<?= e($settings['site_email']) ?>"><?= e($settings['site_email']) ?></a>
              <p>For new projects and partnerships.</p>
            </div>
          </div>

          <div class="contact-info-card">
            <span class="icon-tile icon-tile--sm tint-violet"><i data-lucide="phone"></i></span>
            <div>
              <h3>Call the studio</h3>
              <a href="tel:<?= e(preg_replace('/[^0-9+]/', '', $settings['site_phone'])) ?>"><?= e($settings['site_phone']) ?></a>
              <p>Monday to Friday, 9am–6pm.</p>
            </div>
          </div>

          <div class="contact-info-card">
            <span class="icon-tile icon-tile--sm tint-orange"><i data-lucide="map-pin"></i></span>
            <div>
              <h3>Visit us</h3>
              <p><?= e($settings['site_address']) ?></p>
            </div>
          </div>

          <div class="hours-card">
            <h3>Studio hours</h3>
            <p>We are available for calls and workshops during the week.</p>
            <strong><?= e($settings['working_hours']) ?></strong>
          </div>
        </div>
      </div>

      <div class="map-panel reveal">
        <iframe src="<?= e($settings['map_embed']) ?>" title="PixelCraft studio location" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
      </div>
    </div>
  </section>

  <section class="cta-section">
    <div class="container">
      <div class="cta-banner reveal">
        <div class="cta-copy">
          <span class="eyebrow">Prefer to Talk First?</span>
          <h2>Book a free 30-minute consultation.</h2>
          <p>Bring your questions, your constraints, and your ambitions. We will bring a clear point of view and a practical next step.</p>
          <button class="btn btn-white" type="button" data-open-modal>
            Open Contact Form
            <i data-lucide="arrow-up-right"></i>
          </button>
        </div>
        <div class="cta-media">
          <img src="<?= e(img_src('assets/img/scenes/contact.svg')) ?>" alt="Colleagues talking in a bright studio" loading="lazy">
        </div>
      </div>
    </div>
  </section>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
