<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$slug = trim((string) ($_GET['slug'] ?? ''));

if ($slug === '') {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$statement = db()->prepare(
    "SELECT * FROM blog_posts WHERE slug = :slug AND status = 'published' LIMIT 1"
);
$statement->execute(['slug' => $slug]);
$post = $statement->fetch();

if (!$post) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$authorStatement = db()->prepare('SELECT photo_url, role FROM team WHERE name = :name LIMIT 1');
$authorStatement->execute(['name' => $post['author']]);
$author = $authorStatement->fetch();

$relatedStatement = db()->prepare(
    "SELECT id, title, slug, excerpt, image_url, category, author, published_at
     FROM blog_posts
     WHERE category = :category AND id <> :id AND status = 'published'
     ORDER BY published_at DESC
     LIMIT 3"
);
$relatedStatement->execute(['category' => $post['category'], 'id' => $post['id']]);
$related = $relatedStatement->fetchAll();

$services = featured_services(5);

$wordCount = str_word_count(strip_tags((string) $post['content']));
$readingMinutes = max(1, (int) ceil($wordCount / 200));

$pageTitle = $post['title'];
$pageDescription = excerpt($post['excerpt'], 160);
$activePage = 'blog';
$ogImage = $post['image_url'] ?: '';

$postUrl = static function (string $articleSlug): string {
    return url('blog-single.php?slug=' . urlencode($articleSlug));
};

require __DIR__ . '/includes/header.php';
?>
<main id="mainContent">

  <article>
    <header class="article-hero">
      <div class="container">
        <div class="article-hero__inner reveal">
          <nav class="breadcrumbs" aria-label="Breadcrumb">
            <a href="<?= e(url('index.php')) ?>">Home</a>
            <i data-lucide="chevron-right"></i>
            <a href="<?= e(url('blog.php')) ?>">Blog</a>
            <i data-lucide="chevron-right"></i>
            <span aria-current="page"><?= e($post['category']) ?></span>
          </nav>

          <span class="eyebrow"><?= e($post['category']) ?></span>
          <h1><?= e($post['title']) ?></h1>

          <div class="article-meta">
            <?php if ($author && $author['photo_url']): ?>
              <img src="<?= e(img_src($author['photo_url'])) ?>" alt="<?= e($post['author']) ?>" loading="lazy">
            <?php endif; ?>
            <span><?= e($post['author']) ?></span>
            <span class="dot"></span>
            <time datetime="<?= e(date('Y-m-d', strtotime((string) $post['published_at']))) ?>"><?= e(format_date($post['published_at'])) ?></time>
            <span class="dot"></span>
            <span><?= $readingMinutes ?> min read</span>
          </div>
        </div>
      </div>

      <div class="article-cover reveal">
        <img src="<?= e(img_src($post['image_url'])) ?>" alt="<?= e($post['title']) ?>" width="1200" height="700">
      </div>
    </header>

    <div class="container">
      <div class="article-layout">
        <div class="article-content reveal">
          <?= $post['content'] ?>

          <div class="sidebar-card">
            <h3>Enjoyed this article?</h3>
            <p>Share it with someone who would find it useful, or talk to us about applying these ideas to your own business.</p>
            <button class="btn btn-primary btn-sm" type="button" data-open-modal>Start a Conversation</button>
          </div>
        </div>

        <aside class="article-sidebar reveal delay-2">
          <div class="sidebar-card">
            <h3>About the author</h3>
            <?php if ($author && $author['photo_url']): ?>
              <img class="author-avatar" src="<?= e(img_src($author['photo_url'])) ?>" alt="<?= e($post['author']) ?>" width="60" height="60" loading="lazy">
            <?php endif; ?>
            <p><strong class="author-name"><?= e($post['author']) ?></strong><br><?= e($author['role'] ?? 'PixelCraft Team') ?><br>A senior member of the PixelCraft team, writing about strategy, design, and building better digital experiences.</p>
          </div>

          <div class="sidebar-card">
            <h3>Explore services</h3>
            <div class="sidebar-links">
              <?php foreach ($services as $service): ?>
                <a href="<?= e(url('services.php#' . $service['slug'])) ?>">
                  <i data-lucide="<?= e($service['icon']) ?>"></i>
                  <?= e($service['title']) ?>
                </a>
              <?php endforeach; ?>
            </div>
          </div>

          <div class="sidebar-card">
            <h3>Have a project in mind?</h3>
            <p>Get a clear, practical plan from a senior team. No pressure, no jargon.</p>
            <button class="btn btn-primary btn-sm" type="button" data-open-modal>Book a Call</button>
          </div>
        </aside>
      </div>
    </div>
  </article>

  <?php if ($related): ?>
    <section class="section section--tint">
      <div class="container">
        <div class="section-head reveal">
          <div class="section-head__copy">
            <span class="eyebrow">Keep Reading</span>
            <h2 class="section-title">More on <?= e(strtolower($post['category'])) ?>.</h2>
          </div>
          <a class="text-link" href="<?= e(url('blog.php')) ?>">
            All Articles
            <i data-lucide="arrow-right"></i>
          </a>
        </div>

        <div class="blog-grid">
          <?php foreach ($related as $index => $item): ?>
            <article class="blog-card reveal delay-<?= (int) ($index + 1) ?>">
              <a class="blog-card__media" href="<?= e($postUrl($item['slug'])) ?>" tabindex="-1" aria-hidden="true">
                <img src="<?= e(img_src($item['image_url'])) ?>" alt="" loading="lazy">
              </a>
              <div class="blog-card__body">
                <div class="blog-meta">
                  <span class="blog-category"><?= e($item['category']) ?></span>
                  <span class="dot"></span>
                  <time datetime="<?= e(date('Y-m-d', strtotime((string) $item['published_at']))) ?>"><?= e(format_date($item['published_at'])) ?></time>
                </div>
                <h3><a href="<?= e($postUrl($item['slug'])) ?>"><?= e($item['title']) ?></a></h3>
                <p><?= e($item['excerpt']) ?></p>
                <a class="text-link" href="<?= e($postUrl($item['slug'])) ?>">
                  Read Article
                  <i data-lucide="arrow-right"></i>
                </a>
              </div>
            </article>
          <?php endforeach; ?>
        </div>
      </div>
    </section>
  <?php endif; ?>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
