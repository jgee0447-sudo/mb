<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

if (!headers_sent()) {
    http_response_code(404);
}

$pageTitle = 'Page Not Found';
$pageDescription = 'The page you are looking for could not be found. Explore PixelCraft services, portfolio, and insights instead.';
$activePage = '';

require __DIR__ . '/includes/header.php';
?>
<main id="mainContent">
  <section class="error-page">
    <div class="container">
      <div class="error-page__inner reveal">
        <div class="error-code">404</div>
        <h1>We could not find that page.</h1>
        <p>The link may be out of date, or the page may have moved. Let's get you back to something useful.</p>
        <div class="hero-actions">
          <a class="btn btn-primary" href="<?= e(url('index.php')) ?>">
            Back to Home
            <i data-lucide="home"></i>
          </a>
          <a class="btn btn-outline" href="<?= e(url('portfolio.php')) ?>">Browse Our Work</a>
        </div>
      </div>
    </div>
  </section>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
