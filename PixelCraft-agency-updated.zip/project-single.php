<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$projectId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$projectId) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$statement = db()->prepare(
    'SELECT p.*, c.name AS client_name, c.company AS client_company, c.email AS client_email
     FROM projects p
     LEFT JOIN clients c ON c.id = p.client_id
     WHERE p.id = :id
     LIMIT 1'
);
$statement->execute(['id' => $projectId]);
$project = $statement->fetch();

if (!$project) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$relatedStatement = db()->prepare(
    'SELECT p.*, c.company AS client_company
     FROM projects p
     LEFT JOIN clients c ON c.id = p.client_id
     WHERE p.category = :category AND p.id <> :id
     ORDER BY p.featured DESC, p.created_at DESC
     LIMIT 3'
);
$relatedStatement->execute(['category' => $project['category'], 'id' => $projectId]);
$related = $relatedStatement->fetchAll();

$services = featured_services(5);

$pageTitle = $project['name'];
$pageDescription = excerpt($project['description'] ?? '', 160);
$activePage = 'portfolio';
$ogImage = $project['image_url'] ?: '';

$resultLines = array_filter(array_map('trim', preg_split('/(?<=[.!?])\s+/', (string) $project['results'])));

require __DIR__ . '/includes/header.php';
?>
<main id="mainContent">

  <section class="case-hero">
    <div class="container">
      <div class="breadcrumbs reveal">
        <a href="<?= e(url('index.php')) ?>">Home</a>
        <i data-lucide="chevron-right"></i>
        <a href="<?= e(url('portfolio.php')) ?>">Portfolio</a>
        <i data-lucide="chevron-right"></i>
        <span aria-current="page"><?= e($project['name']) ?></span>
      </div>

      <div class="case-hero__grid">
        <div class="reveal">
          <span class="eyebrow"><?= e($project['category']) ?> Case Study</span>
          <h1><?= e($project['name']) ?></h1>
          <p><?= e($project['description']) ?></p>

          <div class="case-meta">
            <div>
              <span>Client</span>
              <strong><?= e($project['client_company'] ?: $project['client_name'] ?: 'Confidential') ?></strong>
            </div>
            <div>
              <span>Status</span>
              <strong><?= e($project['status']) ?> &middot; <?= (int) $project['progress'] ?>%</strong>
            </div>
            <div>
              <span>Category</span>
              <strong><?= e($project['category']) ?></strong>
            </div>
            <div>
              <span>Timeline</span>
              <strong><?= e(format_date($project['deadline'])) ?></strong>
            </div>
          </div>
        </div>

        <div class="case-media reveal delay-2">
          <img src="<?= e(img_src($project['image_url'])) ?>" alt="<?= e($project['name']) ?>" width="1200" height="900">
        </div>
      </div>
    </div>
  </section>

  <section class="container">
    <div class="case-content">
      <div class="case-body reveal">
        <h2>Overview</h2>
        <p><?= e($project['description']) ?></p>

        <h2>The challenge</h2>
        <p><?= e($project['client_company'] ?: 'The client') ?> needed a digital experience that could keep pace with the business. The existing approach was not clear enough for customers, and not flexible enough for the internal team to manage confidently.</p>

        <h2>Our approach</h2>
        <p>We started by aligning the team around the outcomes that mattered most, then translated those goals into a focused experience strategy. Design and engineering worked in short cycles, with regular reviews and real content from the very beginning.</p>

        <h2>What we delivered</h2>
        <p>Strategy, experience design, and a production-ready build — supported by clear documentation and a handover session so the team could move forward independently.</p>

        <a class="btn btn-primary" href="<?= e(url('contact.php?service=' . urlencode($project['category']))) ?>">
          Start a Similar Project
          <i data-lucide="arrow-right"></i>
        </a>
      </div>

      <aside class="article-sidebar reveal delay-2">
        <div class="results-panel">
          <h3>Results</h3>
          <p>Measurable impact from the engagement.</p>
          <ul class="result-list">
            <?php foreach ($resultLines as $line): ?>
              <li><i data-lucide="check-circle-2"></i><span><?= e($line) ?></span></li>
            <?php endforeach; ?>
            <li><i data-lucide="check-circle-2"></i><span><?= (int) $project['progress'] ?>% of planned milestones delivered.</span></li>
          </ul>
        </div>

        <div class="sidebar-card">
          <h3>Services used</h3>
          <div class="sidebar-links">
            <?php foreach ($services as $service): ?>
              <a href="<?= e(url('services.php#' . $service['slug'])) ?>">
                <i data-lucide="<?= e($service['icon']) ?>"></i>
                <?= e($service['title']) ?>
              </a>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="sidebar-card">
          <h3>Have a similar challenge?</h3>
          <p>Tell us what you are working on and we will suggest a practical next step.</p>
          <button class="btn btn-primary btn-sm" type="button" data-open-modal>Start a Project</button>
        </div>
      </aside>
    </div>
  </section>

  <?php if ($related): ?>
    <section class="section section--tint">
      <div class="container">
        <div class="section-head reveal">
          <div class="section-head__copy">
            <span class="eyebrow">More Work</span>
            <h2 class="section-title">Related <?= e(strtolower($project['category'])) ?> projects.</h2>
          </div>
          <a class="text-link" href="<?= e(url('portfolio.php')) ?>">
            All Projects
            <i data-lucide="arrow-right"></i>
          </a>
        </div>

        <div class="portfolio-grid">
          <?php foreach ($related as $index => $item): ?>
            <a class="project-card reveal delay-<?= (int) ($index + 1) ?>" href="<?= e(url('project-single.php?id=' . (int) $item['id'])) ?>">
              <div class="project-media">
                <img src="<?= e(img_src($item['image_url'])) ?>" alt="<?= e($item['name']) ?>" loading="lazy">
                <span class="project-category"><?= e($item['category']) ?></span>
                <span class="project-open"><i data-lucide="arrow-up-right"></i></span>
              </div>
              <div class="project-content">
                <div>
                  <h3><?= e($item['name']) ?></h3>
                  <p><?= e($item['client_company'] ?: 'PixelCraft Studio') ?> &middot; <?= e($item['status']) ?></p>
                </div>
                <i data-lucide="arrow-up-right"></i>
              </div>
            </a>
          <?php endforeach; ?>
        </div>
      </div>
    </section>
  <?php endif; ?>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
