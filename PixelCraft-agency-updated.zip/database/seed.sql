-- =========================================================
-- PixelCraft sample data
-- Default admin: admin@pixelcraft.agency / Admin@123
-- Import schema.sql first, then this file.
-- =========================================================

USE pixelcraft;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE login_attempts;
TRUNCATE TABLE analytics_daily;
TRUNCATE TABLE activity_log;
TRUNCATE TABLE settings;
TRUNCATE TABLE blog_posts;
TRUNCATE TABLE testimonials;
TRUNCATE TABLE team;
TRUNCATE TABLE tasks;
TRUNCATE TABLE projects;
TRUNCATE TABLE clients;
TRUNCATE TABLE messages;
TRUNCATE TABLE services;
TRUNCATE TABLE admins;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------
-- Administrator (Admin@123)
-- ---------------------------------------------------------
INSERT INTO admins (id, name, email, password_hash, role, avatar_url, created_at) VALUES
(1, 'Admin', 'admin@pixelcraft.agency', '$2y$10$QCFoaot3qZnFWRHVbqAChuay1S0qc/psF/UoKhcD4vH0eFhsa7aPC', 'admin', 'assets/img/people/admin.svg', DATE_SUB(NOW(), INTERVAL 180 DAY));

-- ---------------------------------------------------------
-- Clients
-- ---------------------------------------------------------
INSERT INTO clients (id, name, company, email, phone, status, logo_initial, created_at) VALUES
(1, 'Sarah Khan', 'BrightStore', 'sarah@brightstore.com', '+92 300 111 2200', 'Active', 'BS', DATE_SUB(NOW(), INTERVAL 240 DAY)),
(2, 'Ayesha Malik', 'StyleHub', 'ayesha@stylehub.com', '+92 301 445 8890', 'Active', 'SH', DATE_SUB(NOW(), INTERVAL 210 DAY)),
(3, 'Usman Tariq', 'TechPro', 'usman@techpro.io', '+92 302 778 1120', 'Active', 'TP', DATE_SUB(NOW(), INTERVAL 175 DAY)),
(4, 'Hira Ahmed', 'GreenLife', 'hira@greenlife.co', '+92 303 992 3344', 'Active', 'GL', DATE_SUB(NOW(), INTERVAL 150 DAY)),
(5, 'Omer Siddiqui', 'NextGen', 'omer@nextgen.com', '+92 304 223 7788', 'Active', 'NG', DATE_SUB(NOW(), INTERVAL 120 DAY)),
(6, 'Mina Farooq', 'Nova Foods', 'mina@novafoods.pk', '+92 305 667 4411', 'Active', 'NF', DATE_SUB(NOW(), INTERVAL 90 DAY)),
(7, 'Daniyal Raza', 'UrbanNest', 'daniyal@urbannest.com', '+92 306 334 2211', 'Active', 'UN', DATE_SUB(NOW(), INTERVAL 60 DAY)),
(8, 'Rida Shah', 'Luma Finance', 'rida@lumafinance.com', '+92 307 556 9900', 'Inactive', 'LF', DATE_SUB(NOW(), INTERVAL 30 DAY));

-- ---------------------------------------------------------
-- Projects
-- ---------------------------------------------------------
INSERT INTO projects
(id, client_id, name, category, status, description, results, image_url, deadline, budget, progress, featured, created_at, updated_at)
VALUES
(1, 1, 'BrightStore E-Commerce Website', 'E-Commerce', 'Completed',
 'A conversion-focused online store for a fast-growing lifestyle retailer. We rebuilt the shopping experience around clear product discovery, a frictionless cart, and a content system the BrightStore team can manage in-house.',
 'Checkout completion increased by 34%, average order value grew 18%, and the store now loads in under two seconds on mobile.',
 'assets/img/projects/project-01.svg',
 DATE_ADD(NOW(), INTERVAL 12 DAY), 8500.00, 100, 1,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-01-09 09:00:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 1 DAY)),
(2, 2, 'StyleHub Brand Identity', 'Branding', 'In Progress',
 'A complete identity system for a modern fashion marketplace, spanning logo, typography, colour, packaging, and a practical brand guideline for the in-house creative team.',
 'The new identity is being rolled out across retail, social, and packaging with a consistent visual language.',
 'assets/img/projects/project-02.svg',
 DATE_ADD(NOW(), INTERVAL 36 DAY), 4200.00, 74, 1,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-02-17 10:00:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 2 DAY)),
(3, 3, 'TechPro Mobile App Design', 'Mobile App', 'Pending',
 'A native mobile experience for managing connected devices, built around a calm dashboard, quick actions, and thoughtful onboarding for first-time users.',
 'Prototype testing raised task completion by 27% before development began.',
 'assets/img/projects/project-03.svg',
 DATE_ADD(NOW(), INTERVAL 21 DAY), 6500.00, 28, 1,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-03-21 11:00:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 3 DAY)),
(4, 4, 'GreenLife Marketing Campaign', 'Marketing', 'Completed',
 'An integrated launch campaign for a plant-based wellness range, combining paid social, email flows, influencer partnerships, and a refreshed landing page.',
 'The campaign generated 2.4 million impressions and exceeded its lead target by 41%.',
 'assets/img/projects/project-04.svg',
 DATE_ADD(NOW(), INTERVAL 60 DAY), 3800.00, 100, 1,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-04-11 08:30:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 4 DAY)),
(5, 5, 'NextGen Corporate Website', 'Corporate', 'In Progress',
 'A clear, credible digital home for a fast-moving technology consultancy. The site balances ambitious storytelling with detailed service and investor information.',
 'Early usability tests show a 46% improvement in finding key service information.',
 'assets/img/projects/project-05.svg',
 DATE_ADD(NOW(), INTERVAL 8 DAY), 5200.00, 82, 1,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-05-19 14:00:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 5 DAY)),
(6, 2, 'StyleHub Social Media Design', 'Social Media', 'Completed',
 'A flexible social design system and monthly content templates that help StyleHub stay consistent and recognisable across every channel.',
 'Engagement rate improved by 52% during the first three months.',
 'assets/img/projects/project-06.svg',
 DATE_ADD(NOW(), INTERVAL 45 DAY), 2800.00, 100, 1,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-06-06 12:00:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 6 DAY)),
(7, 6, 'Nova Foods Corporate Website', 'Corporate', 'Completed',
 'A warm, editorial website for a family food brand, with a product story library, stockist locator, and a simple recipe publishing workflow.',
 'Organic traffic doubled in the first quarter after launch.',
 'assets/img/projects/project-07.svg',
 DATE_ADD(NOW(), INTERVAL 30 DAY), 4600.00, 100, 0,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-07-23 09:30:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 7 DAY)),
(8, 7, 'UrbanNest Brand Identity', 'Branding', 'In Progress',
 'A new identity for a property rental platform aimed at young professionals, with a bold wordmark, modular icon system, and city-by-city campaign toolkit.',
 'The visual system is now in rollout across the product and out-of-home campaign.',
 'assets/img/projects/project-08.svg',
 DATE_ADD(NOW(), INTERVAL 18 DAY), 3500.00, 61, 0,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-08-14 15:00:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 8 DAY)),
(9, 8, 'Luma Finance Dashboard', 'Mobile App', 'Pending',
 'A secure finance dashboard concept for small business owners, focused on cash-flow clarity, quick transfers, and understandable reports.',
 'The concept is currently in technical discovery and architecture review.',
 'assets/img/projects/project-09.svg',
 DATE_ADD(NOW(), INTERVAL 52 DAY), 7200.00, 18, 0,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-09-02 10:00:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 9 DAY)),
(10, 1, 'BrightStore Mobile Commerce', 'Mobile App', 'Completed',
 'A mobile-first shopping companion for BrightStore with saved lists, one-tap reordering, and personalised product recommendations.',
 'Mobile revenue increased by 28% within eight weeks of launch.',
 'assets/img/projects/project-10.svg',
 DATE_ADD(NOW(), INTERVAL 72 DAY), 5000.00, 100, 0,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-09-25 13:00:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 10 DAY)),
(11, 4, 'GreenLife Packaging System', 'Branding', 'On Hold',
 'A sustainable packaging family for GreenLife products, using uncoated materials and a modular label system that scales across the range.',
 'The project is paused while the client finalises its new production partner.',
 'assets/img/projects/project-11.svg',
 DATE_ADD(NOW(), INTERVAL 40 DAY), 3100.00, 45, 0,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-10-08 11:30:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 11 DAY)),
(12, 3, 'TechPro Search Campaign', 'Marketing', 'Cancelled',
 'A search and content campaign designed to grow qualified demo requests for TechPro''s device management platform.',
 'The engagement was cancelled after the client shifted its acquisition strategy in-house.',
 'assets/img/projects/project-12.svg',
 DATE_ADD(NOW(), INTERVAL 10 DAY), 2400.00, 0, 0,
 STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-10-21 16:00:00'), '%Y-%m-%d %H:%i:%s'), DATE_SUB(NOW(), INTERVAL 12 DAY));

-- ---------------------------------------------------------
-- Team
-- ---------------------------------------------------------
INSERT INTO team (name, role, bio, photo_url, facebook_url, instagram_url, linkedin_url, twitter_url, created_at) VALUES
('Maya Hassan', 'Creative Director', 'Maya leads brand thinking and visual direction, helping every project find a clear and memorable point of view.', 'assets/img/people/team-maya.svg', 'https://facebook.com', 'https://instagram.com', 'https://linkedin.com', 'https://twitter.com', DATE_SUB(NOW(), INTERVAL 120 DAY)),
('Zain Abbas', 'Lead Developer', 'Zain turns ambitious designs into fast, accessible, and maintainable digital products.', 'assets/img/people/team-zain.svg', 'https://facebook.com', 'https://instagram.com', 'https://linkedin.com', 'https://twitter.com', DATE_SUB(NOW(), INTERVAL 115 DAY)),
('Noor Fatima', 'UX Strategist', 'Noor connects research, product thinking, and business goals to shape experiences that feel effortless.', 'assets/img/people/team-noor.svg', 'https://facebook.com', 'https://instagram.com', 'https://linkedin.com', 'https://twitter.com', DATE_SUB(NOW(), INTERVAL 100 DAY)),
('Hamza Iqbal', 'Growth Lead', 'Hamza builds measurable marketing systems that turn attention into long-term customer relationships.', 'assets/img/people/team-hamza.svg', 'https://facebook.com', 'https://instagram.com', 'https://linkedin.com', 'https://twitter.com', DATE_SUB(NOW(), INTERVAL 80 DAY));

-- ---------------------------------------------------------
-- Tasks
-- ---------------------------------------------------------
INSERT INTO tasks (project_id, team_id, title, description, status, priority, due_date, created_at) VALUES
(2, 1, 'Finalise colour palette', 'Review primary and secondary palettes against print and digital tests.', 'In Progress', 'High', DATE_ADD(CURDATE(), INTERVAL 4 DAY), DATE_SUB(NOW(), INTERVAL 6 DAY)),
(3, 3, 'Mobile onboarding flow', 'Complete prototype for account setup and device pairing.', 'In Progress', 'High', DATE_ADD(CURDATE(), INTERVAL 7 DAY), DATE_SUB(NOW(), INTERVAL 5 DAY)),
(5, 2, 'Build service templates', 'Implement reusable service detail layouts in the new design system.', 'To Do', 'Medium', DATE_ADD(CURDATE(), INTERVAL 11 DAY), DATE_SUB(NOW(), INTERVAL 4 DAY)),
(4, 4, 'Campaign performance review', 'Summarise launch results and identify next-quarter opportunities.', 'Done', 'Medium', DATE_SUB(CURDATE(), INTERVAL 2 DAY), DATE_SUB(NOW(), INTERVAL 9 DAY)),
(8, 1, 'City launch artwork', 'Prepare social and outdoor artwork for the first three launch cities.', 'To Do', 'Low', DATE_ADD(CURDATE(), INTERVAL 16 DAY), DATE_SUB(NOW(), INTERVAL 3 DAY)),
(9, 3, 'Finance dashboard architecture', 'Document data model and security considerations for the prototype.', 'In Progress', 'High', DATE_ADD(CURDATE(), INTERVAL 2 DAY), DATE_SUB(NOW(), INTERVAL 2 DAY)),
(1, 2, 'Post-launch QA sweep', 'Check checkout, email flows, and analytics tracking after launch.', 'Done', 'High', DATE_SUB(CURDATE(), INTERVAL 8 DAY), DATE_SUB(NOW(), INTERVAL 14 DAY)),
(6, 1, 'Social template handoff', 'Package editable templates and a short usage guide for StyleHub.', 'Done', 'Low', DATE_SUB(CURDATE(), INTERVAL 13 DAY), DATE_SUB(NOW(), INTERVAL 20 DAY));

-- ---------------------------------------------------------
-- Contact messages
-- ---------------------------------------------------------
INSERT INTO messages (name, email, phone, subject, message, is_read, created_at) VALUES
('Adeel Khan', 'adeel@northstar.pk', '+92 321 555 0192', 'New e-commerce build', 'Hi PixelCraft, we are launching a premium homeware store and need help with strategy, design, and development. Could we set up a call this week?', 0, DATE_SUB(NOW(), INTERVAL 35 MINUTE)),
('Mariam Javed', 'mariam@thefern.co', '+92 333 780 2210', 'Brand refresh enquiry', 'Our wellness brand is growing quickly and the current identity feels dated. We would love to discuss a thoughtful refresh with you.', 0, DATE_SUB(NOW(), INTERVAL 3 HOUR)),
('Bilal Ahmed', 'bilal@fleetly.io', '+92 345 110 8833', 'Mobile product partnership', 'We are looking for a product design partner for a fleet management app. Do you have availability for a discovery sprint next month?', 1, DATE_SUB(NOW(), INTERVAL 1 DAY)),
('Sana Yousuf', 'sana@studioarc.pk', '+92 300 665 7788', 'Website maintenance', 'We are interested in an ongoing support arrangement for our portfolio website. Can you share your monthly support options?', 1, DATE_SUB(NOW(), INTERVAL 3 DAY));

-- ---------------------------------------------------------
-- Testimonials
-- ---------------------------------------------------------
INSERT INTO testimonials (name, role, company, quote, avatar_url, rating, is_featured, created_at) VALUES
('Sarah Khan', 'CEO', 'BrightStore', 'PixelCraft understood our vision from day one. The new store is beautiful, fast, and has made a real difference to our conversions.', 'assets/img/people/client-sarah.svg', 5, 1, DATE_SUB(NOW(), INTERVAL 40 DAY)),
('Ali Raza', 'Marketing Manager', 'NextGen', 'Their strategy and creative work helped us reach a completely new audience. The team is responsive, thoughtful, and genuinely invested.', 'assets/img/people/client-ali.svg', 5, 1, DATE_SUB(NOW(), INTERVAL 32 DAY)),
('Ayesha Malik', 'Founder', 'StyleHub', 'The rebrand gave us the confidence to show up differently. Our customers noticed immediately, and our team finally feels proud of the brand.', 'assets/img/people/client-ayesha.svg', 5, 1, DATE_SUB(NOW(), INTERVAL 24 DAY));

-- ---------------------------------------------------------
-- Blog posts
-- ---------------------------------------------------------
INSERT INTO blog_posts (title, slug, excerpt, content, image_url, category, author, status, published_at, created_at) VALUES
('Why a clear brand strategy makes design easier', 'clear-brand-strategy-makes-design-easier',
 'A strong visual identity starts long before the first logo sketch. Here is how strategy gives every design decision a reason to exist.',
 '<p>Design becomes much simpler when everyone agrees on what the brand is here to do. A clear strategy defines the audience, the promise, and the personality that should come through in every touchpoint.</p><h2>Start with the problem</h2><p>Before choosing colours or typography, define the business problem the brand needs to solve. Is the challenge recognition, trust, premium positioning, or clarity? Each answer leads to a different creative direction.</p><h2>Build a shared language</h2><p>Use workshops and simple brand principles to align stakeholders early. When language is shared, feedback becomes more useful and design reviews stop turning into personal preference debates.</p><h2>Design with intent</h2><p>Every visual choice should connect back to the strategy. That does not make design boring; it makes it more confident, distinctive, and easier to scale across a growing business.</p>',
 'assets/img/blog/post-01.svg', 'Branding', 'Maya Hassan', 'published', DATE_SUB(NOW(), INTERVAL 5 DAY), DATE_SUB(NOW(), INTERVAL 5 DAY)),
('Five signs your website is ready for a redesign', 'five-signs-your-website-is-ready-for-a-redesign',
 'Not every redesign needs to start from zero. These practical signals will help you decide when it is time for a meaningful refresh.',
 '<p>Websites age in different ways. Sometimes the visual style feels dated, but often the bigger issue is that the site no longer reflects how the business works or what customers need.</p><h2>1. Content is hard to update</h2><p>If simple changes require a developer, your team cannot respond quickly to new opportunities. A modern content system should make everyday publishing straightforward.</p><h2>2. Mobile visitors struggle</h2><p>Review analytics and session recordings. Long forms, tiny tap targets, and layout shifts on mobile are strong signs that the experience needs attention.</p><h2>3. The story is unclear</h2><p>Visitors should understand what you do, who it is for, and why it matters within a few seconds. If they cannot, better visuals alone will not solve the problem.</p><h2>4. Performance is slipping</h2><p>Slow pages quietly cost conversions. A focused performance review can sometimes deliver a strong return without a full rebuild.</p><h2>5. Your business has changed</h2><p>New services, audiences, or positioning deserve a digital experience that keeps up. A redesign is an opportunity to make the website useful again.</p>',
 'assets/img/blog/post-02.svg', 'Web Design', 'Zain Abbas', 'published', DATE_SUB(NOW(), INTERVAL 12 DAY), DATE_SUB(NOW(), INTERVAL 12 DAY)),
('Designing product onboarding that respects users', 'designing-product-onboarding-that-respects-users',
 'The best onboarding does not feel like a tour. It helps people do something valuable quickly and get out of the way.',
 '<p>Onboarding is often treated as a checklist of features to explain. In reality, it is the first working relationship between a product and its user.</p><h2>Focus on the first meaningful action</h2><p>Identify the moment where a new user experiences value. Design the shortest path to that moment, then provide context after the action rather than before it.</p><h2>Use progressive disclosure</h2><p>Do not show every option at once. Reveal complexity as confidence grows. This keeps early screens calm and prevents new users from feeling overwhelmed.</p><h2>Test with real tasks</h2><p>Measure completion, time to value, and recovery from mistakes. A polished animation is useful only if it helps people move forward with less uncertainty.</p>',
 'assets/img/blog/post-03.svg', 'UX Design', 'Noor Fatima', 'published', DATE_SUB(NOW(), INTERVAL 19 DAY), DATE_SUB(NOW(), INTERVAL 19 DAY)),
('A practical content system for growing teams', 'practical-content-system-for-growing-teams',
 'Great content becomes easier to sustain when the team has a clear system for planning, producing, and improving it.',
 '<p>Content marketing rarely fails because a team lacks ideas. It fails because there is no repeatable system for turning ideas into useful work.</p><h2>Define a small set of content pillars</h2><p>Choose three to five themes that connect your expertise to customer questions. Pillars keep planning focused without making every article feel the same.</p><h2>Create reusable formats</h2><p>Turn each strong idea into an article, a short social post, a newsletter section, and a sales enablement note. This multiplies value without multiplying production time.</p><h2>Review and improve</h2><p>Use search data, sales conversations, and engagement metrics to identify what deserves an update. A useful monthly review is more valuable than publishing more without a plan.</p>',
 'assets/img/blog/post-04.svg', 'Content', 'Hamza Iqbal', 'published', DATE_SUB(NOW(), INTERVAL 27 DAY), DATE_SUB(NOW(), INTERVAL 27 DAY)),
('What makes a digital campaign feel human?', 'what-makes-a-digital-campaign-feel-human',
 'Campaigns perform better when the idea starts with a real customer tension instead of a list of channels.',
 '<p>People do not remember channel plans. They remember a clear idea that made them feel understood. Human campaigns begin with an observation about the customer, not a platform.</p><h2>Find the tension</h2><p>What is the customer trying to do, and what is getting in the way? The tension between those two things is often the richest creative territory.</p><h2>Choose one memorable idea</h2><p>A single strong idea can move across social, email, landing pages, and sales conversations. Adding too many messages early usually weakens the campaign.</p><h2>Measure what matters</h2><p>Impressions are useful for reach, but look for signs of understanding: saves, replies, qualified leads, and repeat visits. Those signals show that the idea is doing real work.</p>',
 'assets/img/blog/post-05.svg', 'Marketing', 'Hamza Iqbal', 'published', DATE_SUB(NOW(), INTERVAL 34 DAY), DATE_SUB(NOW(), INTERVAL 34 DAY)),
('The quiet power of a well-made design system', 'quiet-power-of-a-well-made-design-system',
 'A design system is not a library of components. It is a shared way of making consistent decisions at speed.',
 '<p>As digital products grow, consistency becomes harder to maintain. A practical design system gives teams a shared foundation without removing the judgment that good design requires.</p><h2>Start with principles</h2><p>Document the principles that guide decisions: clarity, accessibility, restraint, or whatever matters most to the product. Principles help teams solve new problems that are not covered by a component library.</p><h2>Build for real screens</h2><p>Create components from actual product needs, not an imagined exhaustive catalogue. A smaller system that is used every day is more valuable than a large one that stays theoretical.</p><h2>Make it easy to contribute</h2><p>Give designers and developers a clear route to propose improvements. A design system should evolve with the product, not become a separate project that slowly drifts out of date.</p>',
 'assets/img/blog/post-06.svg', 'Design Systems', 'Maya Hassan', 'published', DATE_SUB(NOW(), INTERVAL 44 DAY), DATE_SUB(NOW(), INTERVAL 44 DAY));

-- ---------------------------------------------------------
-- Services
-- ---------------------------------------------------------
INSERT INTO services (title, slug, description, icon, is_featured, sort_order) VALUES
('Website Development', 'website-development', 'Responsive, secure websites engineered for speed, usability, and long-term growth.', 'code-2', 1, 1),
('UI/UX Design', 'ui-ux-design', 'Research-led interfaces that feel intuitive, look refined, and keep customers coming back.', 'pen-tool', 1, 2),
('Digital Marketing', 'digital-marketing', 'Data-driven campaigns that turn attention into meaningful, measurable business results.', 'megaphone', 1, 3),
('Branding & Identity', 'branding-identity', 'Distinctive visual identities and brand systems that make your business unforgettable.', 'palette', 1, 4),
('Social Media Management', 'social-media-management', 'Consistent content and community care that build a loyal, engaged audience.', 'share-2', 1, 5),
('Content Creation', 'content-creation', 'Compelling copy, visuals, and stories that communicate your value with clarity.', 'file-text', 1, 6);

-- ---------------------------------------------------------
-- Site settings
-- ---------------------------------------------------------
INSERT INTO settings (setting_key, setting_value) VALUES
('site_name', 'PixelCraft'),
('site_tagline', 'Digital Agency'),
('site_email', 'hello@pixelcraft.agency'),
('site_phone', '+92 300 123 4567'),
('site_address', '4th Floor, Creative Hub, Gulberg III, Lahore, Pakistan'),
('working_hours', 'Mon – Fri, 9:00 AM – 6:00 PM'),
('facebook_url', 'https://facebook.com'),
('instagram_url', 'https://instagram.com'),
('linkedin_url', 'https://linkedin.com'),
('twitter_url', 'https://twitter.com'),
('social_note', 'Creative solutions for modern businesses. Let''s build your digital future together.'),
('map_embed', 'https://www.google.com/maps?q=Gulberg%20III%20Lahore&output=embed');

-- ---------------------------------------------------------
-- Analytics (current year and previous year)
-- ---------------------------------------------------------
INSERT INTO analytics_daily (metric_date, visitors, pageviews, revenue) VALUES
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-01-15'), '%Y-%m-%d'), 820, 2400, 1200.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-02-15'), '%Y-%m-%d'), 940, 2700, 1300.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-03-15'), '%Y-%m-%d'), 1020, 3100, 1450.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-04-15'), '%Y-%m-%d'), 1180, 3450, 1500.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-05-15'), '%Y-%m-%d'), 1320, 3800, 1600.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-06-15'), '%Y-%m-%d'), 1450, 4200, 1700.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-07-15'), '%Y-%m-%d'), 1580, 4600, 1800.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-08-15'), '%Y-%m-%d'), 1710, 5100, 1930.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-09-15'), '%Y-%m-%d'), 1840, 5450, 2050.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-10-15'), '%Y-%m-%d'), 1960, 5800, 2180.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-11-15'), '%Y-%m-%d'), 2110, 6200, 2350.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()), '-12-15'), '%Y-%m-%d'), 2270, 6650, 2520.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-01-15'), '%Y-%m-%d'), 610, 1800, 900.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-02-15'), '%Y-%m-%d'), 690, 2000, 975.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-03-15'), '%Y-%m-%d'), 760, 2250, 1080.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-04-15'), '%Y-%m-%d'), 840, 2500, 1125.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-05-15'), '%Y-%m-%d'), 920, 2750, 1200.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-06-15'), '%Y-%m-%d'), 1010, 3020, 1275.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-07-15'), '%Y-%m-%d'), 1100, 3300, 1350.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-08-15'), '%Y-%m-%d'), 1190, 3600, 1450.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-09-15'), '%Y-%m-%d'), 1280, 3900, 1520.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-10-15'), '%Y-%m-%d'), 1370, 4150, 1600.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-11-15'), '%Y-%m-%d'), 1460, 4450, 1725.00),
(STR_TO_DATE(CONCAT(YEAR(CURDATE()) - 1, '-12-15'), '%Y-%m-%d'), 1550, 4750, 1850.00);

-- ---------------------------------------------------------
-- Recent activity
-- ---------------------------------------------------------
INSERT INTO activity_log (admin_id, action, entity_type, entity_id, created_at) VALUES
(1, 'New project added — BrightStore e-commerce', 'project', 1, DATE_SUB(NOW(), INTERVAL 2 MINUTE)),
(1, 'Proposal approved by StyleHub', 'project', 2, DATE_SUB(NOW(), INTERVAL 1 HOUR)),
(1, 'Homepage design task completed', 'task', 7, DATE_SUB(NOW(), INTERVAL 3 HOUR)),
(1, 'TechPro team member added', 'team', 2, DATE_SUB(NOW(), INTERVAL 1 DAY)),
(1, 'New client added — UrbanNest', 'client', 7, DATE_SUB(NOW(), INTERVAL 2 DAY)),
(1, 'Marketing campaign results reviewed', 'project', 4, DATE_SUB(NOW(), INTERVAL 4 DAY));
