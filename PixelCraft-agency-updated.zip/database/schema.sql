-- =========================================================
-- PixelCraft database schema
-- MySQL 8 / MariaDB 10.4+
-- =========================================================

CREATE DATABASE IF NOT EXISTS pixelcraft
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE pixelcraft;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS login_attempts;
DROP TABLE IF EXISTS analytics_daily;
DROP TABLE IF EXISTS activity_log;
DROP TABLE IF EXISTS settings;
DROP TABLE IF EXISTS blog_posts;
DROP TABLE IF EXISTS testimonials;
DROP TABLE IF EXISTS team;
DROP TABLE IF EXISTS tasks;
DROP TABLE IF EXISTS projects;
DROP TABLE IF EXISTS clients;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS services;
DROP TABLE IF EXISTS admins;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------
-- Administrators
-- ---------------------------------------------------------
CREATE TABLE admins (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin', 'editor') NOT NULL DEFAULT 'admin',
  avatar_url VARCHAR(500) DEFAULT NULL,
  last_login DATETIME DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_admins_email (email)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Clients
-- ---------------------------------------------------------
CREATE TABLE clients (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(140) NOT NULL,
  company VARCHAR(160) NOT NULL,
  email VARCHAR(160) NOT NULL,
  phone VARCHAR(40) DEFAULT NULL,
  status ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  logo_initial VARCHAR(4) NOT NULL DEFAULT 'PC',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_clients_name (name),
  INDEX idx_clients_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Projects
-- ---------------------------------------------------------
CREATE TABLE projects (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_id INT UNSIGNED DEFAULT NULL,
  name VARCHAR(180) NOT NULL,
  category VARCHAR(80) NOT NULL,
  status ENUM('Completed', 'In Progress', 'Pending', 'On Hold', 'Cancelled') NOT NULL DEFAULT 'In Progress',
  description TEXT DEFAULT NULL,
  results TEXT DEFAULT NULL,
  image_url VARCHAR(500) DEFAULT NULL,
  deadline DATE DEFAULT NULL,
  budget DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
  progress TINYINT UNSIGNED NOT NULL DEFAULT 0,
  featured TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_projects_client
    FOREIGN KEY (client_id) REFERENCES clients (id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  INDEX idx_projects_status (status),
  INDEX idx_projects_category (category),
  INDEX idx_projects_client (client_id),
  INDEX idx_projects_created (created_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Team members
-- ---------------------------------------------------------
CREATE TABLE team (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(140) NOT NULL,
  role VARCHAR(140) NOT NULL,
  bio TEXT DEFAULT NULL,
  photo_url VARCHAR(500) DEFAULT NULL,
  facebook_url VARCHAR(500) DEFAULT NULL,
  instagram_url VARCHAR(500) DEFAULT NULL,
  linkedin_url VARCHAR(500) DEFAULT NULL,
  twitter_url VARCHAR(500) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Tasks
-- ---------------------------------------------------------
CREATE TABLE tasks (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  project_id INT UNSIGNED DEFAULT NULL,
  team_id INT UNSIGNED DEFAULT NULL,
  title VARCHAR(180) NOT NULL,
  description TEXT DEFAULT NULL,
  status ENUM('To Do', 'In Progress', 'Done') NOT NULL DEFAULT 'To Do',
  priority ENUM('Low', 'Medium', 'High') NOT NULL DEFAULT 'Medium',
  due_date DATE DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_tasks_project
    FOREIGN KEY (project_id) REFERENCES projects (id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_tasks_team
    FOREIGN KEY (team_id) REFERENCES team (id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  INDEX idx_tasks_status (status),
  INDEX idx_tasks_project (project_id),
  INDEX idx_tasks_due (due_date)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Contact messages
-- ---------------------------------------------------------
CREATE TABLE messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(140) NOT NULL,
  email VARCHAR(160) NOT NULL,
  phone VARCHAR(40) DEFAULT NULL,
  subject VARCHAR(180) NOT NULL,
  message TEXT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_messages_read (is_read),
  INDEX idx_messages_created (created_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Testimonials
-- ---------------------------------------------------------
CREATE TABLE testimonials (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(140) NOT NULL,
  role VARCHAR(140) NOT NULL,
  company VARCHAR(160) NOT NULL,
  quote TEXT NOT NULL,
  avatar_url VARCHAR(500) DEFAULT NULL,
  rating TINYINT UNSIGNED NOT NULL DEFAULT 5,
  is_featured TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Blog posts
-- ---------------------------------------------------------
CREATE TABLE blog_posts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  slug VARCHAR(220) NOT NULL UNIQUE,
  excerpt VARCHAR(500) NOT NULL,
  content LONGTEXT NOT NULL,
  image_url VARCHAR(500) DEFAULT NULL,
  category VARCHAR(80) NOT NULL DEFAULT 'Insights',
  author VARCHAR(140) NOT NULL DEFAULT 'PixelCraft Team',
  status ENUM('draft', 'published') NOT NULL DEFAULT 'published',
  published_at DATETIME DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_blog_status (status),
  INDEX idx_blog_published (published_at),
  FULLTEXT KEY ft_blog_search (title, excerpt, content)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Services
-- ---------------------------------------------------------
CREATE TABLE services (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(160) NOT NULL,
  slug VARCHAR(180) NOT NULL UNIQUE,
  description TEXT NOT NULL,
  icon VARCHAR(60) NOT NULL DEFAULT 'sparkles',
  is_featured TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_services_featured (is_featured),
  INDEX idx_services_order (sort_order)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Activity feed
-- ---------------------------------------------------------
CREATE TABLE activity_log (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_id INT UNSIGNED DEFAULT NULL,
  action VARCHAR(255) NOT NULL,
  entity_type VARCHAR(60) DEFAULT NULL,
  entity_id INT UNSIGNED DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_activity_admin
    FOREIGN KEY (admin_id) REFERENCES admins (id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  INDEX idx_activity_created (created_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Site settings
-- ---------------------------------------------------------
CREATE TABLE settings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  setting_value TEXT DEFAULT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Daily analytics snapshots
-- ---------------------------------------------------------
CREATE TABLE analytics_daily (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  metric_date DATE NOT NULL UNIQUE,
  visitors INT UNSIGNED NOT NULL DEFAULT 0,
  pageviews INT UNSIGNED NOT NULL DEFAULT 0,
  revenue DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
  INDEX idx_analytics_date (metric_date)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Login rate limiting
-- ---------------------------------------------------------
CREATE TABLE login_attempts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(160) NOT NULL,
  ip_address VARCHAR(45) NOT NULL,
  attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_attempt_email (email),
  INDEX idx_attempt_ip (ip_address),
  INDEX idx_attempt_time (attempted_at)
) ENGINE=InnoDB;
