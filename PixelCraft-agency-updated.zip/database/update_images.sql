-- ---------------------------------------------------------
-- PixelCraft: switch an existing database to the new local artwork.
-- Run once after deploying the new files. Only rows that still point
-- at the old remote photos are changed; custom images are left alone.
-- ---------------------------------------------------------

UPDATE projects SET image_url = CONCAT('assets/img/projects/project-', LPAD(id, 2, '0'), '.svg')
WHERE id BETWEEN 1 AND 12 AND image_url LIKE 'https://images.unsplash.com/%';

UPDATE team SET photo_url = CASE name
  WHEN 'Maya Hassan' THEN 'assets/img/people/team-maya.svg'
  WHEN 'Zain Abbas'  THEN 'assets/img/people/team-zain.svg'
  WHEN 'Noor Fatima' THEN 'assets/img/people/team-noor.svg'
  WHEN 'Hamza Iqbal' THEN 'assets/img/people/team-hamza.svg'
  ELSE photo_url END
WHERE photo_url LIKE 'https://images.unsplash.com/%';

UPDATE testimonials SET avatar_url = CASE name
  WHEN 'Sarah Khan'   THEN 'assets/img/people/client-sarah.svg'
  WHEN 'Ali Raza'     THEN 'assets/img/people/client-ali.svg'
  WHEN 'Ayesha Malik' THEN 'assets/img/people/client-ayesha.svg'
  ELSE avatar_url END
WHERE avatar_url LIKE 'https://images.unsplash.com/%';

UPDATE blog_posts SET image_url = CASE slug
  WHEN 'clear-brand-strategy-makes-design-easier'      THEN 'assets/img/blog/post-01.svg'
  WHEN 'five-signs-your-website-is-ready-for-a-redesign' THEN 'assets/img/blog/post-02.svg'
  WHEN 'designing-product-onboarding-that-respects-users' THEN 'assets/img/blog/post-03.svg'
  WHEN 'practical-content-system-for-growing-teams'    THEN 'assets/img/blog/post-04.svg'
  WHEN 'what-makes-a-digital-campaign-feel-human'      THEN 'assets/img/blog/post-05.svg'
  WHEN 'quiet-power-of-a-well-made-design-system'      THEN 'assets/img/blog/post-06.svg'
  ELSE image_url END
WHERE image_url LIKE 'https://images.unsplash.com/%';

UPDATE admins SET avatar_url = 'assets/img/people/admin.svg'
WHERE avatar_url LIKE 'https://images.unsplash.com/%';
