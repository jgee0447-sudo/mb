<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Insights & Ideas';
$pageDescription = 'Practical thinking on branding, web design, UX, content, and digital marketing from the PixelCraft team.';
$activePage = 'blog';

$search = trim((string) ($_GET['q'] ?? ''));
$category = trim((string) ($_GET['category'] ?? ''));
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 6;

$where = ["status = 'published'"];
$params = [];

if ($search !== '') {
    $where[] = '(title LIKE :search_title OR excerpt LIKE :search_excerpt OR content LIKE :search_content)';
    $like = '%' . $search . '%';
    $params['search_title'] = $like;
    $params['search_excerpt'] = $like;
    $params['search_content'] = $like;
}

if ($category !== '') {
    $where[] = 'category = :category';
    $params['category'] = $category;
}

$whereSql = implode(' AND ', $where);

$countStatement = db()->prepare('SELECT COUNT(*) FROM blog_posts WHERE ' . $whereSql);
$countStatement->execute($params);
$totalPosts = (int) $countStatement->fetchColumn();
$totalPages = max(1, (int) ceil($totalPosts / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$postStatement = db()->prepare(
    'SELECT id, title, slug, excerpt, image_url, category, author, published_at
     FROM blog_posts
     WHERE ' . $whereSql . '
     ORDER BY published_at DESC, id DESC
     LIMIT :limit OFFSET :offset'
);
foreach ($params as $key => $value) {
    $postStatement->bindValue(':' . $key, $value);
}
$postStatement->bindValue(':limit', $perPage, PDO::PARAM_INT);
$postStatement->bindValue(':offset', $offset, PDO::PARAM_INT);
$postStatement->execute();
$posts = $postStatement->fetchAll();

$categories = db()->query(
    "SELECT category, COUNT(*) AS total
     FROM blog_posts
     WHERE status = 'published'
     GROUP BY category
     ORDER BY category ASC"
)->fetchAll();

$queryBase = [];
if ($search !== '') {
    $queryBase['q'] = $search;
}
if ($category !== '') {
    $queryBase['category'] = $category;
}

$postUrl = static function (string $slug): string {
    return url('blog-single.php?slug=' . urlencode($slug));
};

require __DIR__ . '/includes/header.php';
?>
<main id="mainContent">

  <section class="page-hero">
    <div class="container">
      <div class="page-hero__inner reveal">
        <nav class="breadcrumbs" aria-label="Breadcrumb">
          <a href="<?= e(url('index.php')) ?>">Home</a>
          <i data-lucide="chevron-right"></i>
          <span aria-current="page">Blog</span>
        </nav>
        <span class="eyebrow">The PixelCraft Journal</span>
        <h1>Ideas, frameworks, and lessons from the studio.</h1>
        <p>Practical thinking on brand strategy, web design, product experiences, and campaigns that earn attention — written by the people doing the work.</p>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="blog-tools">
        <form class="search-form" action="<?= e(url('blog.php')) ?>" method="get" role="search">
          <i data-lucide="search"></i>
          <input type="search" name="q" value="<?= e($search) ?>" placeholder="Search articles..." aria-label="Search articles">
          <?php if ($category !== ''): ?>
            <input type="hidden" name="category" value="<?= e($category) ?>">
          <?php endif; ?>
        </form>

        <div class="filter-bar filter-bar--inline">
          <a class="filter-btn<?= $category === '' ? ' is-active' : '' ?>" href="<?= e(url('blog.php' . ($search !== '' ? '?q=' . urlencode($search) : ''))) ?>">All Topics</a>
          <?php foreach ($categories as $topic): ?>
            <a class="filter-btn<?= $category === $topic['category'] ? ' is-active' : '' ?>" href="<?= e(url('blog.php?' . http_build_query(array_merge($search !== '' ? ['q' => $search] : [], ['category' => $topic['category']])))) ?>">
              <?= e($topic['category']) ?>
            </a>
          <?php endforeach; ?>
        </div>
      </div>

      <?php if ($search !== '' || $category !== ''): ?>
        <p class="section-subtitle blog-result-note">
          <?= $totalPosts ?> <?= $totalPosts === 1 ? 'article' : 'articles' ?> found
          <?php if ($search !== ''): ?> for &ldquo;<?= e($search) ?>&rdquo;<?php endif; ?>
          <?php if ($category !== ''): ?> in <?= e($category) ?><?php endif; ?>.
          <a class="text-link" href="<?= e(url('blog.php')) ?>">Clear filters</a>
        </p>
      <?php endif; ?>

      <div class="blog-grid">
        <?php foreach ($posts as $index => $post): ?>
          <article class="blog-card reveal delay-<?= (int) (($index % 3) + 1) ?>">
            <a class="blog-card__media" href="<?= e($postUrl($post['slug'])) ?>" tabindex="-1" aria-hidden="true">
              <img src="<?= e(img_src($post['image_url'])) ?>" alt="" loading="lazy">
            </a>
            <div class="blog-card__body">
              <div class="blog-meta">
                <span class="blog-category"><?= e($post['category']) ?></span>
                <span class="dot"></span>
                <time datetime="<?= e(date('Y-m-d', strtotime((string) $post['published_at']))) ?>"><?= e(format_date($post['published_at'])) ?></time>
              </div>
              <h2><a href="<?= e($postUrl($post['slug'])) ?>"><?= e($post['title']) ?></a></h2>
              <p><?= e($post['excerpt']) ?></p>
              <a class="text-link" href="<?= e($postUrl($post['slug'])) ?>">
                Read Article
                <i data-lucide="arrow-right"></i>
              </a>
            </div>
          </article>
        <?php endforeach; ?>

        <?php if (!$posts): ?>
          <div class="empty-state">
            <i data-lucide="file-search"></i>
            <p>No articles match that search yet. Try a different keyword or browse all topics.</p>
          </div>
        <?php endif; ?>
      </div>

      <?php if ($totalPages > 1): ?>
        <nav class="pagination" aria-label="Blog pagination">
          <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a class="page-link<?= $i === $page ? ' is-active' : '' ?>" href="<?= e(url('blog.php?' . http_build_query(array_merge($queryBase, ['page' => $i])))) ?>"<?= $i === $page ? ' aria-current="page"' : '' ?>><?= $i ?></a>
          <?php endfor; ?>
        </nav>
      <?php endif; ?>
    </div>
  </section>

  <section class="cta-section">
    <div class="container">
      <div class="cta-banner reveal">
        <div class="cta-copy">
          <span class="eyebrow">Let's Work Together</span>
          <h2>Want thinking like this applied to your business?</h2>
          <p>We turn strategy into digital experiences that are clear, useful, and built to grow. Tell us what you are working on.</p>
          <button class="btn btn-white" type="button" data-open-modal>
            Start a Conversation
            <i data-lucide="arrow-up-right"></i>
          </button>
        </div>
        <div class="cta-media">
          <img src="<?= e(img_src('assets/img/scenes/blog-notebook.svg')) ?>" alt="Team discussing ideas in the studio" loading="lazy">
        </div>
      </div>
    </div>
  </section>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
