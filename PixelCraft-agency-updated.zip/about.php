<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'About Our Studio';
$pageDescription = 'Meet PixelCraft — a senior team of strategists, designers, and developers helping ambitious businesses build better digital experiences since 2013.';
$activePage = 'about';

$members = team_members();
$testimonials = featured_testimonials(3);

require __DIR__ . '/includes/header.php';
?>
<main id="mainContent">

  <section class="page-hero">
    <div class="container">
      <div class="page-hero__inner reveal">
        <nav class="breadcrumbs" aria-label="Breadcrumb">
          <a href="<?= e(url('index.php')) ?>">Home</a>
          <i data-lucide="chevron-right"></i>
          <span aria-current="page">About</span>
        </nav>
        <span class="eyebrow">Our Story</span>
        <h1>We are a studio built around clarity, craft, and measurable progress.</h1>
        <p>PixelCraft brings strategy, design, and engineering into one focused team. We work with businesses that want more than a good-looking website — they want a digital presence that earns trust and drives growth.</p>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="split-grid">
        <div class="split-media reveal">
          <img src="<?= e(img_src('assets/img/scenes/about-team.svg')) ?>" alt="PixelCraft team working together in the studio" width="1000" height="750" loading="lazy">
          <div class="media-badge">
            <span class="icon-tile icon-tile--sm tint-violet"><i data-lucide="users"></i></span>
            <span>
              <strong>18 specialists</strong>
              <span>Strategy, design, and engineering</span>
            </span>
          </div>
        </div>

        <div class="split-copy reveal delay-2">
          <span class="eyebrow">Why PixelCraft</span>
          <h2 class="section-title">Good work happens when the right people share a clear goal.</h2>
          <p>We started in 2013 with a simple belief: digital projects fail when strategy, design, and development sit in separate rooms. So we built a studio where they sit together.</p>
          <p>Today we partner with e-commerce brands, technology companies, and growing service businesses across Pakistan and beyond. Every engagement is led by a senior team, with direct access to the people doing the work.</p>

          <ul class="check-list">
            <li><span class="check-icon"><i data-lucide="check"></i></span> One accountable team from kickoff to launch</li>
            <li><span class="check-icon"><i data-lucide="check"></i></span> Research-backed decisions, never guesswork</li>
            <li><span class="check-icon"><i data-lucide="check"></i></span> Systems built to be maintained and extended</li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <section class="section section--tint">
    <div class="container">
      <div class="section-head reveal">
        <div class="section-head__copy">
          <span class="eyebrow">What We Value</span>
          <h2 class="section-title">Principles that shape every project.</h2>
          <p class="section-subtitle">These are not posters on a wall. They are the filters we use when making decisions, especially the difficult ones.</p>
        </div>
      </div>

      <div class="mission-grid">
        <article class="value-card reveal delay-1">
          <span class="icon-tile tint-blue"><i data-lucide="target"></i></span>
          <h3>Outcomes over output</h3>
          <p>We measure success by what changes for your business, not by how many screens or features we ship.</p>
        </article>
        <article class="value-card reveal delay-2">
          <span class="icon-tile tint-violet"><i data-lucide="sparkles"></i></span>
          <h3>Craft with restraint</h3>
          <p>Thoughtful details, clear hierarchy, and purposeful motion. Every choice should earn its place.</p>
        </article>
        <article class="value-card reveal delay-3">
          <span class="icon-tile tint-green"><i data-lucide="handshake"></i></span>
          <h3>Partnership, not vending</h3>
          <p>We tell you what we think, share the trade-offs, and stay engaged long after launch day.</p>
        </article>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="section-head reveal">
        <div class="section-head__copy">
          <span class="eyebrow">How We Work</span>
          <h2 class="section-title">A calm, transparent process.</h2>
          <p class="section-subtitle">No black boxes. You will always know what we are doing, why it matters, and what comes next.</p>
        </div>
      </div>

      <div class="process-grid">
        <article class="process-step reveal delay-1">
          <h3>Discover</h3>
          <p>We align on goals, audiences, and constraints through research and focused workshops.</p>
        </article>
        <article class="process-step reveal delay-2">
          <h3>Define</h3>
          <p>We turn insight into a clear brief, success metrics, and a prioritised roadmap.</p>
        </article>
        <article class="process-step reveal delay-3">
          <h3>Design</h3>
          <p>We prototype, test, and refine the experience before a line of production code is written.</p>
        </article>
        <article class="process-step reveal delay-3">
          <h3>Deliver</h3>
          <p>We build, launch, and optimise — with documentation and training your team can use.</p>
        </article>
      </div>
    </div>
  </section>

  <section class="section section--tint">
    <div class="container">
      <div class="section-head reveal">
        <div class="section-head__copy">
          <span class="eyebrow">The Team</span>
          <h2 class="section-title">Senior people, close to the work.</h2>
          <p class="section-subtitle">Small enough to stay nimble. Experienced enough to handle complex, high-stakes projects.</p>
        </div>
      </div>

      <div class="team-grid">
        <?php foreach ($members as $index => $member): ?>
          <article class="team-card reveal delay-<?= (int) (($index % 3) + 1) ?>">
            <div class="team-photo">
              <img src="<?= e(img_src($member['photo_url'])) ?>" alt="<?= e($member['name']) ?>, <?= e($member['role']) ?>" loading="lazy">
              <div class="team-socials">
                <?php if ($member['linkedin_url']): ?><a href="<?= e($member['linkedin_url']) ?>" target="_blank" rel="noopener" aria-label="<?= e($member['name']) ?> on LinkedIn"><i data-lucide="linkedin"></i></a><?php endif; ?>
                <?php if ($member['instagram_url']): ?><a href="<?= e($member['instagram_url']) ?>" target="_blank" rel="noopener" aria-label="<?= e($member['name']) ?> on Instagram"><i data-lucide="instagram"></i></a><?php endif; ?>
                <?php if ($member['twitter_url']): ?><a href="<?= e($member['twitter_url']) ?>" target="_blank" rel="noopener" aria-label="<?= e($member['name']) ?> on Twitter"><i data-lucide="twitter"></i></a><?php endif; ?>
              </div>
            </div>
            <div class="team-info">
              <h3><?= e($member['name']) ?></h3>
              <p><?= e($member['role']) ?></p>
              <span><?= e($member['bio']) ?></span>
            </div>
          </article>
        <?php endforeach; ?>
      </div>

      <div class="stats-row">
        <div class="stat-block">
          <strong><span data-counter="250" data-suffix="+">250+</span></strong>
          <span>Projects delivered</span>
        </div>
        <div class="stat-block">
          <strong><span data-counter="120" data-suffix="+">120+</span></strong>
          <span>Clients served</span>
        </div>
        <div class="stat-block">
          <strong><span data-counter="12" data-suffix="+">12+</span></strong>
          <span>Years in business</span>
        </div>
        <div class="stat-block">
          <strong><span data-counter="98" data-suffix="%">98%</span></strong>
          <span>Client retention</span>
        </div>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="section-head reveal">
        <div class="section-head__copy">
          <span class="eyebrow">Client Stories</span>
          <h2 class="section-title">What it is like to work with us.</h2>
        </div>
      </div>

      <div class="testimonial-grid">
        <?php foreach ($testimonials as $index => $testimonial): ?>
          <article class="testimonial-card reveal delay-<?= (int) ($index + 1) ?>">
            <div class="testimonial-top">
              <img src="<?= e(img_src($testimonial['avatar_url'])) ?>" alt="<?= e($testimonial['name']) ?>" loading="lazy">
              <div>
                <h3><?= e($testimonial['name']) ?></h3>
                <span><?= e($testimonial['role']) ?>, <?= e($testimonial['company']) ?></span>
              </div>
              <span class="stars" aria-label="<?= (int) $testimonial['rating'] ?> out of 5 stars"><?= str_repeat('★', (int) $testimonial['rating']) ?></span>
            </div>
            <p class="testimonial-quote"><?= e($testimonial['quote']) ?></p>
          </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section class="cta-section">
    <div class="container">
      <div class="cta-banner reveal">
        <div class="cta-copy">
          <span class="eyebrow">Start a Conversation</span>
          <h2>Let's build something your team is proud to share.</h2>
          <p>Whether you are starting fresh or improving what you already have, we would love to hear what you are working on.</p>
          <button class="btn btn-white" type="button" data-open-modal>
            Talk to Our Team
            <i data-lucide="arrow-up-right"></i>
          </button>
        </div>
        <div class="cta-media">
          <img src="<?= e(img_src('assets/img/scenes/about-board.svg')) ?>" alt="Team meeting at PixelCraft" loading="lazy">
        </div>
      </div>
    </div>
  </section>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
