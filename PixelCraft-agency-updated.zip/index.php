<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Creative Digital Agency for Modern Brands';
$pageDescription = 'PixelCraft is a full-service digital agency crafting high-performing websites, memorable brands, and marketing campaigns that grow ambitious businesses.';
$activePage = 'home';

$services = featured_services(6);
$projects = featured_projects(3);
$testimonials = featured_testimonials(3);
$members = team_members();

require __DIR__ . '/includes/header.php';

$tints = ['tint-blue', 'tint-violet', 'tint-orange', 'tint-green', 'tint-cyan', 'tint-red'];
?>
<main id="mainContent">

  <section class="nx-hero">
    <div class="nx-hero__panel">
      <div class="nx-hero__grid">
        <div class="nx-hero__copy reveal">
          <span class="nx-tag"><i></i> Digital Agency &middot; Lahore</span>
          <h1>We build brands and digital experiences that <em>move business forward.</em></h1>
          <p>Strategy, design, and engineering under one roof. We partner with ambitious teams to launch websites, products, and campaigns people genuinely love to use.</p>
          <div class="nx-hero__actions">
            <button class="btn btn-accent" type="button" data-open-modal>Start a Project <i data-lucide="arrow-up-right"></i></button>
            <a class="btn btn-ghost" href="<?= e(url('portfolio.php')) ?>">View Our Work</a>
          </div>
          <div class="nx-hero__proof">
            <div class="avatar-stack">
              <?php foreach (array_slice($testimonials, 0, 3) as $person): ?>
                <img src="<?= e(img_src($person['avatar_url'])) ?>" alt="<?= e($person['name']) ?>" loading="lazy">
              <?php endforeach; ?>
            </div>
            <p><strong>Trusted by 120+ growing businesses</strong><span>4.9/5 average client rating</span></p>
          </div>
        </div>
        <div class="nx-hero__art reveal delay-2">
          <div class="nx-arch"><img src="<?= e(img_src('assets/img/scenes/hero.svg')) ?>" alt="PixelCraft team collaborating on a digital project" width="1200" height="800"></div>
          <div class="nx-sticker"><strong>+38%</strong><span>conversion lift across recent launches</span></div>
          <div class="nx-seal" aria-hidden="true"><span>Since<br>2013</span></div>
        </div>
      </div>
    </div>
    <div class="nx-marquee" aria-hidden="true">
      <div class="nx-marquee__track">
        <?php for ($i = 0; $i < 2; $i++): foreach (['Strategy', 'Branding', 'Web Design', 'Development', 'Marketing', 'UI/UX', 'Growth'] as $word): ?>
          <span><?= e($word) ?></span><b>&#10022;</b>
        <?php endforeach; endfor; ?>
      </div>
    </div>
  </section>

  <section class="nx-section">
    <div class="container">
      <div class="nx-steps">
        <?php foreach ([['Discover', 'Research and strategy that set clear direction.'], ['Design', 'Interfaces and identities built to be remembered.'], ['Build', 'Fast, accessible products engineered to scale.'], ['Grow', 'Campaigns and optimisation that compound results.']] as $i => $step): ?>
          <div class="nx-step reveal delay-<?= $i + 1 ?>">
            <span class="nx-step__no"><?= sprintf('%02d', $i + 1) ?></span>
            <h3><?= e($step[0]) ?></h3>
            <p><?= e($step[1]) ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section class="nx-section nx-about">
    <div class="container nx-about__grid">
      <div class="reveal">
        <span class="nx-label">Who we are</span>
        <h2 class="nx-big">A senior team that treats your goals <em>like our own.</em></h2>
        <p class="nx-lead">Since 2013, PixelCraft has helped founders, marketing leaders, and product teams turn complex ideas into digital experiences that feel simple. No hand-offs, no bloated teams &mdash; just the right specialists around the table.</p>
        <ul class="nx-ticks">
          <li>A dedicated strategist on every engagement</li>
          <li>Transparent timelines, budgets, and reporting</li>
          <li>Design and development working side by side</li>
        </ul>
        <a class="btn btn-outline" href="<?= e(url('about.php')) ?>">More About Us <i data-lucide="arrow-right"></i></a>
      </div>
      <div class="nx-about__art reveal delay-2">
        <img src="<?= e(img_src('assets/img/scenes/roadmap.svg')) ?>" alt="PixelCraft strategists reviewing a project plan" width="1000" height="750" loading="lazy">
      </div>
    </div>
    <div class="container">
      <div class="nx-stats reveal">
        <div><strong><span data-counter="250" data-suffix="+">250+</span></strong><span>Projects delivered</span></div>
        <div><strong><span data-counter="120" data-suffix="+">120+</span></strong><span>Happy clients</span></div>
        <div><strong><span data-counter="18" data-suffix="">18</span></strong><span>Industry awards</span></div>
        <div><strong><span data-counter="98" data-suffix="%">98%</span></strong><span>Client retention</span></div>
      </div>
    </div>
  </section>

  <section class="nx-section">
    <div class="container">
      <div class="nx-head reveal">
        <div><span class="nx-label">Our services</span><h2 class="nx-big">Everything you need to launch and grow.</h2></div>
        <a class="nx-link" href="<?= e(url('services.php')) ?>">All services <i data-lucide="arrow-right"></i></a>
      </div>
      <div class="nx-index">
        <?php foreach ($services as $index => $service): ?>
          <a class="nx-row reveal" id="<?= e($service['slug']) ?>" href="<?= e(url('services.php#' . $service['slug'])) ?>">
            <span class="nx-row__no"><?= sprintf('%02d', $index + 1) ?></span>
            <h3><?= e($service['title']) ?></h3>
            <p><?= e($service['description']) ?></p>
            <span class="nx-row__go"><i data-lucide="arrow-up-right"></i></span>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section class="nx-section nx-work">
    <div class="container">
      <div class="nx-head reveal">
        <div><span class="nx-label nx-label--light">Selected work</span><h2 class="nx-big">Recent projects, real outcomes.</h2></div>
        <a class="nx-link" href="<?= e(url('portfolio.php')) ?>">View portfolio <i data-lucide="arrow-right"></i></a>
      </div>
      <div class="nx-bento">
        <?php foreach ($projects as $index => $project): ?>
          <a class="nx-case reveal" href="<?= e(url('project-single.php?id=' . (int) $project['id'])) ?>">
            <img src="<?= e(img_src($project['image_url'])) ?>" alt="<?= e($project['name']) ?>" loading="lazy">
            <div class="nx-case__meta">
              <span class="nx-pill"><?= e($project['category']) ?></span>
              <h3><?= e($project['name']) ?></h3>
              <p><?= e($project['client_name'] ?: 'PixelCraft Studio') ?> &middot; <?= e($project['status']) ?></p>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section class="nx-section">
    <div class="container">
      <div class="nx-head reveal"><div><span class="nx-label">Client stories</span><h2 class="nx-big">Trusted by teams who care about the details.</h2></div></div>
      <div class="nx-quotes">
        <?php foreach ($testimonials as $index => $testimonial): ?>
          <figure class="nx-quote<?= $index === 0 ? ' nx-quote--lead' : '' ?> reveal">
            <blockquote><?= e($testimonial['quote']) ?></blockquote>
            <figcaption>
              <img src="<?= e(img_src($testimonial['avatar_url'])) ?>" alt="<?= e($testimonial['name']) ?>" loading="lazy">
              <span><strong><?= e($testimonial['name']) ?></strong><?= e($testimonial['role']) ?>, <?= e($testimonial['company']) ?></span>
              <em aria-label="<?= (int) $testimonial['rating'] ?> out of 5 stars"><?= str_repeat('★', (int) $testimonial['rating']) ?></em>
            </figcaption>
          </figure>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section class="nx-section nx-section--end">
    <div class="container">
      <div class="nx-cta reveal">
        <div>
          <span class="nx-label nx-label--dark">Let's build together</span>
          <h2>Have a project in mind? Let's make it remarkable.</h2>
          <p>Tell us where you want to go. We will come back with a clear plan, honest timeline, and the right team to get you there.</p>
          <button class="btn btn-primary" type="button" data-open-modal>Book a Free Consultation <i data-lucide="arrow-up-right"></i></button>
        </div>
        <img src="<?= e(img_src('assets/img/scenes/cta-calendar.svg')) ?>" alt="Creative team planning a new project" loading="lazy">
      </div>
    </div>
  </section>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
