<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Privacy Policy';
$pageDescription = 'How PixelCraft collects, uses, and protects the personal information you share with us.';
$activePage = '';

require __DIR__ . '/includes/header.php';
?>
<main id="mainContent">

  <section class="page-hero">
    <div class="container">
      <div class="page-hero__inner reveal">
        <nav class="breadcrumbs" aria-label="Breadcrumb">
          <a href="<?= e(url('index.php')) ?>">Home</a>
          <i data-lucide="chevron-right"></i>
          <span aria-current="page">Privacy Policy</span>
        </nav>
        <span class="eyebrow">Legal</span>
        <h1>Privacy Policy</h1>
        <p>Last updated: <?= e(date('F j, Y')) ?>. This policy explains what information we collect, why we collect it, and the choices you have.</p>
      </div>
    </div>
  </section>

  <section class="container">
    <div class="legal-layout reveal">
      <h2>Information we collect</h2>
      <p>When you contact us through our website, we collect the information you choose to provide, including your name, email address, phone number, and the details of your enquiry. We may also collect basic technical information such as your browser type and pages visited to understand how the site is used.</p>

      <h2>How we use information</h2>
      <p>We use the information you share to respond to enquiries, prepare proposals, deliver services, and improve our website. We do not sell your personal information. We only share information with trusted service providers when it is necessary to operate our business or meet a legal obligation.</p>

      <h2>Cookies and analytics</h2>
      <p>Our website may use cookies and privacy-friendly analytics to remember preferences and understand aggregate traffic patterns. You can control cookies through your browser settings. Disabling cookies may affect some website features.</p>

      <h2>Data retention</h2>
      <p>We keep enquiry and client information only for as long as it is needed for the purpose it was collected, to maintain our business records, or to comply with legal requirements. When information is no longer needed, we delete or anonymise it.</p>

      <h2>Security</h2>
      <p>We take reasonable technical and organisational measures to protect personal information against unauthorised access, loss, or misuse. No method of transmission or storage is completely secure, so we cannot guarantee absolute security.</p>

      <h2>Your rights</h2>
      <p>Depending on where you live, you may have the right to access, correct, delete, or restrict the use of your personal information. To make a request, contact us using the details below and we will respond within a reasonable timeframe.</p>

      <h2>Third-party links</h2>
      <p>Our website may link to third-party sites. We are not responsible for the privacy practices of those sites, and we encourage you to review their policies before sharing personal information.</p>

      <h2>Changes to this policy</h2>
      <p>We may update this policy from time to time. When we do, we will revise the date at the top of this page. Continued use of the website after a change means you accept the updated policy.</p>

      <h2>Contact us</h2>
      <p>If you have questions about this policy or how your information is handled, email <a href="mailto:<?= e(setting('site_email')) ?>"><?= e(setting('site_email')) ?></a> or write to <?= e(setting('site_address')) ?>.</p>
    </div>
  </section>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
