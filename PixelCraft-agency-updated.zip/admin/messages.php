<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

$read = trim((string) ($_GET['read'] ?? ''));
$search = trim((string) ($_GET['search'] ?? ''));

if (!in_array($read, ['unread', 'read'], true)) {
    $read = '';
}

$conditions = [];
$params = [];

if ($read === 'unread') {
    $conditions[] = 'is_read = 0';
} elseif ($read === 'read') {
    $conditions[] = 'is_read = 1';
}

if ($search !== '') {
    $conditions[] = '(name LIKE :search_name OR email LIKE :search_email OR subject LIKE :search_subject OR message LIKE :search_message)';
    $like = '%' . $search . '%';
    $params['search_name'] = $like;
    $params['search_email'] = $like;
    $params['search_subject'] = $like;
    $params['search_message'] = $like;
}

$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';

$messagesStatement = db()->prepare(
    'SELECT * FROM messages' . $where . '
     ORDER BY is_read ASC, created_at DESC
     LIMIT 300'
);
$messagesStatement->execute($params);
$messages = $messagesStatement->fetchAll();

$summary = db()->query(
    "SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN is_read = 0 THEN 1 ELSE 0 END) AS unread,
        SUM(CASE WHEN created_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01') THEN 1 ELSE 0 END) AS this_month
     FROM messages"
)->fetch() ?: [];

$pageTitle = 'Messages';
$pageSubtitle = 'Enquiries and conversations from the public website.';
$activeAdmin = 'messages';

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-stats">
  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Unread</span>
      <span class="admin-icon-tile tint-orange"><i data-lucide="mail-warning"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['unread'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Waiting for a reply</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">All messages</span>
      <span class="admin-icon-tile tint-blue"><i data-lucide="inbox"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['total'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Total enquiries received</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">This month</span>
      <span class="admin-icon-tile tint-violet"><i data-lucide="calendar-days"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['this_month'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>New conversations in <?= e(date('F')) ?></span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Showing</span>
      <span class="admin-icon-tile tint-green"><i data-lucide="list-filter"></i></span>
    </div>
    <strong class="admin-stat__value"><?= count($messages) ?></strong>
    <div class="admin-stat__meta"><span><?= $read !== '' || $search !== '' ? 'Matching current filters' : 'Most recent first' ?></span></div>
  </article>
</div>

<div class="admin-toolbar">
  <form class="admin-toolbar__group" method="get" action="<?= e(url('admin/messages.php')) ?>">
    <label class="admin-search">
      <i data-lucide="search"></i>
      <input type="search" name="search" value="<?= e($search) ?>" placeholder="Search messages…" aria-label="Search messages">
    </label>
    <select class="admin-filter-select" name="read" aria-label="Filter by read status" data-auto-submit>
      <option value="">All messages</option>
      <option value="unread"<?= $read === 'unread' ? ' selected' : '' ?>>Unread only</option>
      <option value="read"<?= $read === 'read' ? ' selected' : '' ?>>Read only</option>
    </select>
    <button class="admin-btn admin-btn--outline admin-btn--sm" type="submit">
      <i data-lucide="sliders-horizontal"></i>
      Filter
    </button>
    <?php if ($read !== '' || $search !== ''): ?>
      <a class="admin-btn admin-btn--ghost admin-btn--sm" href="<?= e(url('admin/messages.php')) ?>">Reset</a>
    <?php endif; ?>
  </form>

  <a class="admin-btn admin-btn--outline" href="<?= e(url('contact.php')) ?>" target="_blank" rel="noopener">
    <i data-lucide="external-link"></i>
    View contact page
  </a>
</div>

<section class="admin-card">
  <div class="admin-card__head">
    <div>
      <h2>Inbox</h2>
      <p><?= count($messages) ?> <?= count($messages) === 1 ? 'message' : 'messages' ?> in this view</p>
    </div>
  </div>

  <div class="admin-card__body">
    <?php if (!$messages): ?>
      <div class="admin-empty">
        <i data-lucide="inbox"></i>
        No messages match these filters.
      </div>
    <?php else: ?>
      <div class="admin-message-list">
        <?php foreach ($messages as $message): ?>
          <article class="admin-message-item<?= !(int) $message['is_read'] ? ' is-unread' : '' ?>" data-message-row="<?= (int) $message['id'] ?>">
            <span class="admin-message-item__avatar"><?= e(name_initials($message['name'])) ?></span>

            <div class="admin-message-item__body">
              <div class="admin-message-item__top">
                <strong><?= e($message['name']) ?></strong>
                <span><?= e($message['email']) ?></span>
                <span>· <?= e(format_date($message['created_at'], 'M j, g:i a')) ?></span>
              </div>
              <div class="admin-message-item__subject"><?= e($message['subject']) ?></div>
              <div class="admin-message-item__preview"><?= e(excerpt($message['message'], 150)) ?></div>
            </div>

            <div class="admin-message-item__actions">
              <button
                class="admin-btn admin-btn--ghost admin-btn--icon admin-btn--sm"
                type="button"
                title="Read message"
                data-message-view
                data-modal-open="#messageModal"
                data-message-api="<?= e(url('api/messages.php')) ?>"
                data-message-id="<?= (int) $message['id'] ?>"
              >
                <i data-lucide="eye"></i>
              </button>
              <button
                class="admin-btn admin-btn--ghost admin-btn--icon admin-btn--sm"
                type="button"
                title="<?= (int) $message['is_read'] ? 'Mark as unread' : 'Mark as read' ?>"
                data-message-toggle
                data-message-api="<?= e(url('api/messages.php')) ?>"
                data-message-id="<?= (int) $message['id'] ?>"
                data-mark-read="<?= (int) $message['is_read'] ? '0' : '1' ?>"
              >
                <i data-lucide="<?= (int) $message['is_read'] ? 'mail' : 'mail-open' ?>"></i>
              </button>
              <button
                class="admin-btn admin-btn--ghost admin-btn--icon admin-btn--sm"
                type="button"
                title="Delete message"
                data-delete-api="<?= e(url('api/messages.php')) ?>"
                data-delete-id="<?= (int) $message['id'] ?>"
                data-confirm="Delete this message from <?= e($message['name']) ?>? This cannot be undone."
              >
                <i data-lucide="trash-2"></i>
              </button>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<div class="admin-modal" id="messageModal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="messageModalTitle">
  <div class="admin-modal__backdrop" data-modal-close></div>
  <div class="admin-modal__panel">
    <div class="admin-modal__head">
      <div>
        <h2 id="messageModalTitle" data-modal-title>Message details</h2>
        <p>Read the full enquiry and reply by email.</p>
      </div>
      <button class="admin-modal__close" type="button" aria-label="Close dialog" data-modal-close>
        <i data-lucide="x"></i>
      </button>
    </div>

    <div class="admin-message-detail">
      <div class="admin-message-detail__meta">
        <div>
          <span>From</span>
          <strong data-message-field="name"></strong>
        </div>
        <div>
          <span>Email</span>
          <strong data-message-field="email"></strong>
        </div>
        <div>
          <span>Phone</span>
          <strong data-message-field="phone"></strong>
        </div>
        <div>
          <span>Received</span>
          <strong data-message-field="created_at"></strong>
        </div>
      </div>

      <div>
        <span class="admin-field__hint">Subject</span>
        <h3 data-message-field="subject"></h3>
      </div>

      <div class="admin-message-detail__text" data-message-field="message"></div>
    </div>

    <div class="admin-form-actions">
      <button class="admin-btn admin-btn--ghost" type="button" data-modal-close>Close</button>
      <a class="admin-btn admin-btn--primary" href="#" data-message-reply>
        <i data-lucide="reply"></i>
        Reply by email
      </a>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
