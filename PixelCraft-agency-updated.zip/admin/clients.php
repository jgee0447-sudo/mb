<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

$status = trim((string) ($_GET['status'] ?? ''));
$search = trim((string) ($_GET['search'] ?? ''));

if (!in_array($status, ['Active', 'Inactive'], true)) {
    $status = '';
}

$conditions = [];
$params = [];

if ($status !== '') {
    $conditions[] = 'c.status = :status';
    $params['status'] = $status;
}

if ($search !== '') {
    $conditions[] = '(c.name LIKE :search_name OR c.company LIKE :search_company OR c.email LIKE :search_email)';
    $like = '%' . $search . '%';
    $params['search_name'] = $like;
    $params['search_company'] = $like;
    $params['search_email'] = $like;
}

$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';

$clientsStatement = db()->prepare(
    'SELECT c.*, COUNT(p.id) AS project_count, COALESCE(SUM(p.budget), 0) AS project_value
     FROM clients c
     LEFT JOIN projects p ON p.client_id = c.id' . $where . '
     GROUP BY c.id
     ORDER BY c.created_at DESC, c.id DESC
     LIMIT 200'
);
$clientsStatement->execute($params);
$clients = $clientsStatement->fetchAll();

$summary = db()->query(
    "SELECT
        COUNT(*) AS total_clients,
        SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END) AS active_clients,
        (SELECT COALESCE(SUM(budget), 0) FROM projects) AS portfolio_value
     FROM clients"
)->fetch() ?: [];

$pageTitle = 'Clients';
$pageSubtitle = 'Your accounts, contacts and portfolio value.';
$activeAdmin = 'clients';

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-stats">
  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Total clients</span>
      <span class="admin-icon-tile tint-blue"><i data-lucide="building-2"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['total_clients'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>All accounts in the workspace</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Active accounts</span>
      <span class="admin-icon-tile tint-green"><i data-lucide="user-round-check"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['active_clients'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Available for new projects</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Portfolio value</span>
      <span class="admin-icon-tile tint-violet"><i data-lucide="wallet-cards"></i></span>
    </div>
    <strong class="admin-stat__value">$<?= number_format((float) ($summary['portfolio_value'] ?? 0), 0) ?></strong>
    <div class="admin-stat__meta"><span>Combined project budgets</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Showing</span>
      <span class="admin-icon-tile tint-orange"><i data-lucide="list-filter"></i></span>
    </div>
    <strong class="admin-stat__value"><?= count($clients) ?></strong>
    <div class="admin-stat__meta"><span><?= $search !== '' || $status !== '' ? 'Matching current filters' : 'Most recent accounts' ?></span></div>
  </article>
</div>

<div class="admin-toolbar">
  <form class="admin-toolbar__group" method="get" action="<?= e(url('admin/clients.php')) ?>">
    <label class="admin-search">
      <i data-lucide="search"></i>
      <input type="search" name="search" value="<?= e($search) ?>" placeholder="Search clients…" aria-label="Search clients">
    </label>
    <select class="admin-filter-select" name="status" aria-label="Filter by status" data-auto-submit>
      <option value="">All statuses</option>
      <option value="Active"<?= $status === 'Active' ? ' selected' : '' ?>>Active</option>
      <option value="Inactive"<?= $status === 'Inactive' ? ' selected' : '' ?>>Inactive</option>
    </select>
    <button class="admin-btn admin-btn--outline admin-btn--sm" type="submit">
      <i data-lucide="sliders-horizontal"></i>
      Filter
    </button>
    <?php if ($search !== '' || $status !== ''): ?>
      <a class="admin-btn admin-btn--ghost admin-btn--sm" href="<?= e(url('admin/clients.php')) ?>">Reset</a>
    <?php endif; ?>
  </form>

  <button class="admin-btn admin-btn--primary" type="button" data-modal-open="#clientModal" data-modal-reset>
    <i data-lucide="plus"></i>
    Add client
  </button>
</div>

<section class="admin-card">
  <div class="admin-card__head">
    <div>
      <h2>Client directory</h2>
      <p>Click a project count to view that client’s work.</p>
    </div>
  </div>

  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Company</th>
          <th>Contact</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Status</th>
          <th>Projects</th>
          <th>Value</th>
          <th aria-label="Actions"></th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$clients): ?>
          <tr>
            <td colspan="8" class="admin-table__empty">No clients match these filters.</td>
          </tr>
        <?php endif; ?>

        <?php foreach ($clients as $client): ?>
          <tr>
            <td>
              <div class="admin-client">
                <span class="admin-client__avatar"><?= e($client['logo_initial']) ?></span>
                <span class="admin-client__text">
                  <strong><?= e($client['company']) ?></strong>
                  <small>Client since <?= e(format_date($client['created_at'], 'M Y')) ?></small>
                </span>
              </div>
            </td>
            <td><?= e($client['name']) ?></td>
            <td><a class="admin-link" href="mailto:<?= e($client['email']) ?>"><?= e($client['email']) ?></a></td>
            <td><?= e($client['phone'] ?: '—') ?></td>
            <td><span class="admin-badge admin-badge--<?= e(status_slug($client['status'])) ?>"><?= e($client['status']) ?></span></td>
            <td>
              <a class="admin-link" href="<?= e(url('admin/projects.php?' . http_build_query(['search' => $client['company']]))) ?>">
                <?= (int) $client['project_count'] ?>
              </a>
            </td>
            <td class="is-strong">$<?= number_format((float) $client['project_value'], 0) ?></td>
            <td>
              <div class="admin-table__actions">
                <button
                  class="admin-btn admin-btn--ghost admin-btn--icon admin-btn--sm"
                  type="button"
                  title="Edit client"
                  data-modal-open="#clientModal"
                  data-edit-api="<?= e(url('api/clients.php')) ?>"
                  data-edit-id="<?= (int) $client['id'] ?>"
                  data-edit-title="Edit client"
                >
                  <i data-lucide="pencil"></i>
                </button>
                <button
                  class="admin-btn admin-btn--ghost admin-btn--icon admin-btn--sm"
                  type="button"
                  title="Delete client"
                  data-delete-api="<?= e(url('api/clients.php')) ?>"
                  data-delete-id="<?= (int) $client['id'] ?>"
                  data-confirm="Delete <?= e($client['company']) ?>? Their projects will be kept and unassigned."
                >
                  <i data-lucide="trash-2"></i>
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>

<div class="admin-modal" id="clientModal" data-add-title="Add client" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="clientModalTitle">
  <div class="admin-modal__backdrop" data-modal-close></div>
  <div class="admin-modal__panel">
    <div class="admin-modal__head">
      <div>
        <h2 id="clientModalTitle" data-modal-title>Add client</h2>
        <p>Store the primary contact and account status.</p>
      </div>
      <button class="admin-modal__close" type="button" aria-label="Close dialog" data-modal-close>
        <i data-lucide="x"></i>
      </button>
    </div>

    <form data-api="<?= e(url('api/clients.php')) ?>">
      <input type="hidden" name="id" value="">
      <div class="admin-form-grid">
        <div class="admin-field">
          <label for="clientCompany">Company</label>
          <input id="clientCompany" name="company" type="text" maxlength="160" required>
          <span class="admin-field__error" data-error-for="company"></span>
        </div>

        <div class="admin-field">
          <label for="clientName">Contact name</label>
          <input id="clientName" name="name" type="text" maxlength="140" required>
          <span class="admin-field__error" data-error-for="name"></span>
        </div>

        <div class="admin-field">
          <label for="clientEmail">Email</label>
          <input id="clientEmail" name="email" type="email" maxlength="160" required>
          <span class="admin-field__error" data-error-for="email"></span>
        </div>

        <div class="admin-field">
          <label for="clientPhone">Phone</label>
          <input id="clientPhone" name="phone" type="tel" maxlength="40">
          <span class="admin-field__error" data-error-for="phone"></span>
        </div>

        <div class="admin-field">
          <label for="clientStatus">Status</label>
          <select id="clientStatus" name="status">
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
          <span class="admin-field__error" data-error-for="status"></span>
        </div>

        <div class="admin-field">
          <label for="clientInitials">Logo initials</label>
          <input id="clientInitials" name="logo_initial" type="text" maxlength="4" placeholder="Auto from company">
          <span class="admin-field__hint">Up to 4 characters. Leave blank to generate.</span>
          <span class="admin-field__error" data-error-for="logo_initial"></span>
        </div>
      </div>

      <div class="admin-form-actions">
        <button class="admin-btn admin-btn--ghost" type="button" data-modal-close>Cancel</button>
        <button class="admin-btn admin-btn--primary" type="submit">
          <i data-lucide="check"></i>
          Save client
        </button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
