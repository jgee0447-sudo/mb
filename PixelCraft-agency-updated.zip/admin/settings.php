<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

$allowedKeys = [
    'site_name',
    'site_tagline',
    'site_email',
    'site_phone',
    'site_address',
    'working_hours',
    'facebook_url',
    'instagram_url',
    'linkedin_url',
    'twitter_url',
    'social_note',
    'map_embed',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        flash('error', 'Your session expired. Please try again.');
        redirect('admin/settings.php');
    }

    $values = [];
    foreach ($allowedKeys as $key) {
        $values[$key] = trim(strip_tags((string) ($_POST[$key] ?? '')));
    }

    $errors = [];

    if ($values['site_name'] === '' || mb_strlen($values['site_name']) > 120) {
        $errors[] = 'Site name is required and must be under 120 characters.';
    }

    if ($values['site_email'] === '' || !filter_var($values['site_email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid contact email address.';
    }

    if (mb_strlen($values['site_tagline']) > 160) {
        $errors[] = 'The tagline must be under 160 characters.';
    }

    if (mb_strlen($values['site_phone']) > 40) {
        $errors[] = 'The phone number is too long.';
    }

    if (mb_strlen($values['site_address']) > 255) {
        $errors[] = 'The address must be under 255 characters.';
    }

    if (mb_strlen($values['working_hours']) > 120) {
        $errors[] = 'Working hours must be under 120 characters.';
    }

    if (mb_strlen($values['social_note']) > 500) {
        $errors[] = 'The social note must be under 500 characters.';
    }

    foreach (['facebook_url', 'instagram_url', 'linkedin_url', 'twitter_url', 'map_embed'] as $urlKey) {
        if ($values[$urlKey] !== '' && !filter_var($values[$urlKey], FILTER_VALIDATE_URL)) {
            $errors[] = 'Please enter a valid URL for ' . str_replace('_', ' ', $urlKey) . '.';
        }

        if (mb_strlen($values[$urlKey]) > 500) {
            $errors[] = str_replace('_', ' ', $urlKey) . ' must be under 500 characters.';
        }
    }

    if ($errors) {
        foreach ($errors as $error) {
            flash('error', $error);
        }
        redirect('admin/settings.php');
    }

    $statement = db()->prepare(
        'INSERT INTO settings (setting_key, setting_value, updated_at)
         VALUES (:setting_key, :setting_value, NOW())
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()'
    );

    db()->beginTransaction();

    try {
        foreach ($values as $key => $value) {
            $statement->execute([
                'setting_key' => $key,
                'setting_value' => $value,
            ]);
        }

        db()->commit();
        log_activity('Updated site settings', 'settings');
        flash('success', 'Site settings saved.');
    } catch (Throwable $exception) {
        db()->rollBack();
        flash('error', 'Settings could not be saved. Please try again.');
    }

    redirect('admin/settings.php');
}

$settings = site_settings();

$pageTitle = 'Settings';
$pageSubtitle = 'Contact details, social profiles and public site content.';
$activeAdmin = 'settings';

require_once __DIR__ . '/includes/header.php';
?>

<form method="post" action="<?= e(url('admin/settings.php')) ?>">
  <?= csrf_field() ?>

  <div class="admin-settings-grid">
    <div class="admin-stack">
      <section class="admin-card">
        <div class="admin-card__head">
          <div>
            <h2>Brand & contact</h2>
            <p>Used across the website header, footer and contact page.</p>
          </div>
        </div>
        <div class="admin-card__body">
          <div class="admin-settings-section">
            <div class="admin-form-grid">
              <div class="admin-field">
                <label for="siteName">Site name</label>
                <input id="siteName" name="site_name" type="text" maxlength="120" value="<?= e($settings['site_name'] ?? 'PixelCraft') ?>" required>
              </div>

              <div class="admin-field">
                <label for="siteTagline">Tagline</label>
                <input id="siteTagline" name="site_tagline" type="text" maxlength="160" value="<?= e($settings['site_tagline'] ?? '') ?>">
              </div>

              <div class="admin-field">
                <label for="siteEmail">Contact email</label>
                <input id="siteEmail" name="site_email" type="email" maxlength="160" value="<?= e($settings['site_email'] ?? '') ?>" required>
              </div>

              <div class="admin-field">
                <label for="sitePhone">Phone</label>
                <input id="sitePhone" name="site_phone" type="tel" maxlength="40" value="<?= e($settings['site_phone'] ?? '') ?>">
              </div>

              <div class="admin-field admin-field--full">
                <label for="siteAddress">Office address</label>
                <input id="siteAddress" name="site_address" type="text" maxlength="255" value="<?= e($settings['site_address'] ?? '') ?>">
              </div>

              <div class="admin-field admin-field--full">
                <label for="workingHours">Working hours</label>
                <input id="workingHours" name="working_hours" type="text" maxlength="120" value="<?= e($settings['working_hours'] ?? '') ?>">
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="admin-card">
        <div class="admin-card__head">
          <div>
            <h2>Social profiles</h2>
            <p>Leave a field blank to hide that link on the website.</p>
          </div>
        </div>
        <div class="admin-card__body">
          <div class="admin-settings-section">
            <div class="admin-form-grid">
              <div class="admin-field">
                <label for="facebookUrl">Facebook URL</label>
                <input id="facebookUrl" name="facebook_url" type="url" value="<?= e($settings['facebook_url'] ?? '') ?>">
              </div>

              <div class="admin-field">
                <label for="instagramUrl">Instagram URL</label>
                <input id="instagramUrl" name="instagram_url" type="url" value="<?= e($settings['instagram_url'] ?? '') ?>">
              </div>

              <div class="admin-field">
                <label for="linkedinUrl">LinkedIn URL</label>
                <input id="linkedinUrl" name="linkedin_url" type="url" value="<?= e($settings['linkedin_url'] ?? '') ?>">
              </div>

              <div class="admin-field">
                <label for="twitterUrl">X / Twitter URL</label>
                <input id="twitterUrl" name="twitter_url" type="url" value="<?= e($settings['twitter_url'] ?? '') ?>">
              </div>

              <div class="admin-field admin-field--full">
                <label for="socialNote">Social note</label>
                <textarea id="socialNote" name="social_note" rows="3" maxlength="500"><?= e($settings['social_note'] ?? '') ?></textarea>
                <span class="admin-field__hint">Short line used in social or footer areas.</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="admin-card">
        <div class="admin-card__head">
          <div>
            <h2>Map</h2>
            <p>Google Maps embed URL shown on the contact page.</p>
          </div>
        </div>
        <div class="admin-card__body">
          <div class="admin-field">
            <label for="mapEmbed">Map embed URL</label>
            <input id="mapEmbed" name="map_embed" type="url" value="<?= e($settings['map_embed'] ?? '') ?>" placeholder="https://www.google.com/maps?q=…&output=embed">
            <span class="admin-field__hint">Use the “embed” URL from Google Maps share options.</span>
          </div>
        </div>
      </section>

      <div class="admin-form-actions">
        <a class="admin-btn admin-btn--ghost" href="<?= e(url('admin/dashboard.php')) ?>">Cancel</a>
        <button class="admin-btn admin-btn--primary" type="submit">
          <i data-lucide="save"></i>
          Save settings
        </button>
      </div>
    </div>

    <aside class="admin-stack">
      <section class="admin-card">
        <div class="admin-card__head">
          <div>
            <h2>Public preview</h2>
            <p>How your contact details are used.</p>
          </div>
        </div>
        <div class="admin-card__body">
          <div class="admin-note">
            <strong><?= e($settings['site_name'] ?? 'PixelCraft') ?></strong><br>
            <?= e($settings['site_tagline'] ?? 'Digital Agency') ?><br><br>
            <?= e($settings['site_email'] ?? '') ?><br>
            <?= e($settings['site_phone'] ?? '') ?><br>
            <?= e($settings['site_address'] ?? '') ?>
          </div>

          <div class="admin-form-actions">
            <a class="admin-btn admin-btn--outline admin-btn--sm" href="<?= e(url('contact.php')) ?>" target="_blank" rel="noopener">
              <i data-lucide="external-link"></i>
              View contact page
            </a>
          </div>
        </div>
      </section>

      <section class="admin-card">
        <div class="admin-card__head">
          <div>
            <h2>Good to know</h2>
          </div>
        </div>
        <div class="admin-card__body">
          <div class="admin-note">
            Changes are applied to the public website immediately after saving. Invalid social or map URLs are rejected so broken links never reach visitors.
          </div>
        </div>
      </section>
    </aside>
  </div>
</form>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
