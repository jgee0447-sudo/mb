<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

$statusOptions = ['To Do', 'In Progress', 'Done'];
$priorityOptions = ['Low', 'Medium', 'High'];

$status = trim((string) ($_GET['status'] ?? ''));
$projectFilter = (int) ($_GET['project_id'] ?? 0);
$search = trim((string) ($_GET['search'] ?? ''));

if (!in_array($status, $statusOptions, true)) {
    $status = '';
}

$conditions = [];
$params = [];

if ($status !== '') {
    $conditions[] = 't.status = :status';
    $params['status'] = $status;
}

if ($projectFilter > 0) {
    $conditions[] = 't.project_id = :project_id';
    $params['project_id'] = $projectFilter;
}

if ($search !== '') {
    $conditions[] = '(t.title LIKE :search_title OR t.description LIKE :search_description)';
    $like = '%' . $search . '%';
    $params['search_title'] = $like;
    $params['search_description'] = $like;
}

$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';

$tasksStatement = db()->prepare(
    'SELECT t.*, p.name AS project_name, tm.name AS team_name, tm.photo_url AS team_photo
     FROM tasks t
     LEFT JOIN projects p ON p.id = t.project_id
     LEFT JOIN team tm ON tm.id = t.team_id' . $where . '
     ORDER BY FIELD(t.status, "In Progress", "To Do", "Done"), t.due_date IS NULL, t.due_date ASC, t.id DESC
     LIMIT 300'
);
$tasksStatement->execute($params);
$tasks = $tasksStatement->fetchAll();

$summary = db()->query(
    "SELECT
        SUM(CASE WHEN status = 'To Do' THEN 1 ELSE 0 END) AS todo,
        SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) AS in_progress,
        SUM(CASE WHEN status = 'Done' THEN 1 ELSE 0 END) AS done,
        SUM(CASE WHEN status <> 'Done' AND due_date IS NOT NULL AND due_date < CURDATE() THEN 1 ELSE 0 END) AS overdue
     FROM tasks"
)->fetch() ?: [];

$projects = db()->query('SELECT id, name FROM projects ORDER BY name ASC')->fetchAll();
$team = db()->query('SELECT id, name, role FROM team ORDER BY name ASC')->fetchAll();

$pageTitle = 'Tasks';
$pageSubtitle = 'Coordinate priorities, owners and upcoming deadlines.';
$activeAdmin = 'tasks';

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-stats">
  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">To do</span>
      <span class="admin-icon-tile tint-orange"><i data-lucide="circle-dashed"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['todo'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Waiting to be started</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">In progress</span>
      <span class="admin-icon-tile tint-blue"><i data-lucide="loader-circle"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['in_progress'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Currently being worked on</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Completed</span>
      <span class="admin-icon-tile tint-green"><i data-lucide="circle-check-big"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['done'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Finished tasks</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Overdue</span>
      <span class="admin-icon-tile tint-red"><i data-lucide="alarm-clock"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['overdue'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Past due and still open</span></div>
  </article>
</div>

<div class="admin-toolbar">
  <form class="admin-toolbar__group" method="get" action="<?= e(url('admin/tasks.php')) ?>">
    <label class="admin-search">
      <i data-lucide="search"></i>
      <input type="search" name="search" value="<?= e($search) ?>" placeholder="Search tasks…" aria-label="Search tasks">
    </label>
    <select class="admin-filter-select" name="status" aria-label="Filter by status" data-auto-submit>
      <option value="">All statuses</option>
      <?php foreach ($statusOptions as $option): ?>
        <option value="<?= e($option) ?>"<?= $status === $option ? ' selected' : '' ?>><?= e($option) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="admin-filter-select" name="project_id" aria-label="Filter by project" data-auto-submit>
      <option value="">All projects</option>
      <?php foreach ($projects as $project): ?>
        <option value="<?= (int) $project['id'] ?>"<?= $projectFilter === (int) $project['id'] ? ' selected' : '' ?>><?= e($project['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="admin-btn admin-btn--outline admin-btn--sm" type="submit">
      <i data-lucide="sliders-horizontal"></i>
      Filter
    </button>
    <?php if ($search !== '' || $status !== '' || $projectFilter > 0): ?>
      <a class="admin-btn admin-btn--ghost admin-btn--sm" href="<?= e(url('admin/tasks.php')) ?>">Reset</a>
    <?php endif; ?>
  </form>

  <button class="admin-btn admin-btn--primary" type="button" data-modal-open="#taskModal" data-modal-reset>
    <i data-lucide="plus"></i>
    Add task
  </button>
</div>

<section class="admin-card">
  <div class="admin-card__head">
    <div>
      <h2>Task board</h2>
      <p><?= count($tasks) ?> <?= count($tasks) === 1 ? 'task' : 'tasks' ?> in the current view</p>
    </div>
  </div>

  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Task</th>
          <th>Project</th>
          <th>Owner</th>
          <th>Priority</th>
          <th>Status</th>
          <th>Due</th>
          <th aria-label="Actions"></th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$tasks): ?>
          <tr>
            <td colspan="7" class="admin-table__empty">No tasks match these filters.</td>
          </tr>
        <?php endif; ?>

        <?php foreach ($tasks as $task): ?>
          <?php $overdue = $task['status'] !== 'Done' && $task['due_date'] && $task['due_date'] < date('Y-m-d'); ?>
          <tr>
            <td>
              <span class="is-strong"><?= e($task['title']) ?></span>
              <?php if ($task['description']): ?>
                <div class="admin-table__desc"><?= e(excerpt($task['description'], 64)) ?></div>
              <?php endif; ?>
            </td>
            <td><?= e($task['project_name'] ?: 'General') ?></td>
            <td>
              <?php if ($task['team_name']): ?>
                <div class="admin-client">
                  <?php if ($task['team_photo']): ?>
                    <img class="admin-client__avatar" src="<?= e(img_src($task['team_photo'])) ?>" alt="" loading="lazy">
                  <?php else: ?>
                    <span class="admin-client__avatar"><?= e(name_initials($task['team_name'])) ?></span>
                  <?php endif; ?>
                  <span class="admin-client__text"><strong><?= e($task['team_name']) ?></strong></span>
                </div>
              <?php else: ?>
                <span class="admin-muted">Unassigned</span>
              <?php endif; ?>
            </td>
            <td><span class="admin-badge admin-badge--<?= e(status_slug($task['priority'])) ?>"><?= e($task['priority']) ?></span></td>
            <td><span class="admin-badge admin-badge--<?= e(status_slug($task['status'])) ?>"><?= e($task['status']) ?></span></td>
            <td class="<?= $overdue ? 'admin-text-danger' : '' ?>">
              <?= e(format_date($task['due_date'], 'M j, Y')) ?>
              <?php if ($overdue): ?><div class="admin-muted">Overdue</div><?php endif; ?>
            </td>
            <td>
              <div class="admin-table__actions">
                <button
                  class="admin-btn admin-btn--ghost admin-btn--icon admin-btn--sm"
                  type="button"
                  title="Edit task"
                  data-modal-open="#taskModal"
                  data-edit-api="<?= e(url('api/tasks.php')) ?>"
                  data-edit-id="<?= (int) $task['id'] ?>"
                  data-edit-title="Edit task"
                >
                  <i data-lucide="pencil"></i>
                </button>
                <button
                  class="admin-btn admin-btn--ghost admin-btn--icon admin-btn--sm"
                  type="button"
                  title="Delete task"
                  data-delete-api="<?= e(url('api/tasks.php')) ?>"
                  data-delete-id="<?= (int) $task['id'] ?>"
                  data-confirm="Delete <?= e($task['title']) ?>? This cannot be undone."
                >
                  <i data-lucide="trash-2"></i>
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>

<div class="admin-modal" id="taskModal" data-add-title="Add task" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="taskModalTitle">
  <div class="admin-modal__backdrop" data-modal-close></div>
  <div class="admin-modal__panel">
    <div class="admin-modal__head">
      <div>
        <h2 id="taskModalTitle" data-modal-title>Add task</h2>
        <p>Assign work, set a priority and keep delivery on track.</p>
      </div>
      <button class="admin-modal__close" type="button" aria-label="Close dialog" data-modal-close>
        <i data-lucide="x"></i>
      </button>
    </div>

    <form data-api="<?= e(url('api/tasks.php')) ?>">
      <input type="hidden" name="id" value="">
      <div class="admin-form-grid">
        <div class="admin-field admin-field--full">
          <label for="taskTitle">Task title</label>
          <input id="taskTitle" name="title" type="text" maxlength="180" required>
          <span class="admin-field__error" data-error-for="title"></span>
        </div>

        <div class="admin-field">
          <label for="taskProject">Project</label>
          <select id="taskProject" name="project_id">
            <option value="">General / no project</option>
            <?php foreach ($projects as $project): ?>
              <option value="<?= (int) $project['id'] ?>"><?= e($project['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <span class="admin-field__error" data-error-for="project_id"></span>
        </div>

        <div class="admin-field">
          <label for="taskOwner">Owner</label>
          <select id="taskOwner" name="team_id">
            <option value="">Unassigned</option>
            <?php foreach ($team as $member): ?>
              <option value="<?= (int) $member['id'] ?>"><?= e($member['name']) ?> — <?= e($member['role']) ?></option>
            <?php endforeach; ?>
          </select>
          <span class="admin-field__error" data-error-for="team_id"></span>
        </div>

        <div class="admin-field">
          <label for="taskStatus">Status</label>
          <select id="taskStatus" name="status">
            <?php foreach ($statusOptions as $option): ?>
              <option value="<?= e($option) ?>"><?= e($option) ?></option>
            <?php endforeach; ?>
          </select>
          <span class="admin-field__error" data-error-for="status"></span>
        </div>

        <div class="admin-field">
          <label for="taskPriority">Priority</label>
          <select id="taskPriority" name="priority">
            <?php foreach ($priorityOptions as $option): ?>
              <option value="<?= e($option) ?>"<?= $option === 'Medium' ? ' selected' : '' ?>><?= e($option) ?></option>
            <?php endforeach; ?>
          </select>
          <span class="admin-field__error" data-error-for="priority"></span>
        </div>

        <div class="admin-field">
          <label for="taskDue">Due date</label>
          <input id="taskDue" name="due_date" type="date">
          <span class="admin-field__error" data-error-for="due_date"></span>
        </div>

        <div class="admin-field admin-field--full">
          <label for="taskDescription">Description</label>
          <textarea id="taskDescription" name="description" rows="3" placeholder="Add context, links or acceptance criteria…"></textarea>
          <span class="admin-field__error" data-error-for="description"></span>
        </div>
      </div>

      <div class="admin-form-actions">
        <button class="admin-btn admin-btn--ghost" type="button" data-modal-close>Cancel</button>
        <button class="admin-btn admin-btn--primary" type="submit">
          <i data-lucide="check"></i>
          Save task
        </button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
