<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

$team = db()->query('SELECT * FROM team ORDER BY name ASC')->fetchAll();

$summary = db()->query(
    "SELECT
        (SELECT COUNT(*) FROM team) AS total_members,
        (SELECT COUNT(*) FROM tasks WHERE team_id IS NOT NULL AND status <> 'Done') AS assigned_tasks,
        (SELECT COUNT(*) FROM team WHERE photo_url IS NOT NULL AND photo_url <> '') AS with_photos,
        (SELECT COUNT(*) FROM team WHERE linkedin_url IS NOT NULL AND linkedin_url <> '') AS with_linkedin"
)->fetch() ?: [];

$pageTitle = 'Team';
$pageSubtitle = 'The people behind the work, their roles and public profiles.';
$activeAdmin = 'team';

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-stats">
  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Team members</span>
      <span class="admin-icon-tile tint-blue"><i data-lucide="users-round"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['total_members'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>People in the studio</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Assigned work</span>
      <span class="admin-icon-tile tint-orange"><i data-lucide="list-checks"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['assigned_tasks'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Open tasks with an owner</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Team photos</span>
      <span class="admin-icon-tile tint-violet"><i data-lucide="image-user"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['with_photos'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Profiles ready for the public page</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">LinkedIn profiles</span>
      <span class="admin-icon-tile tint-green"><i data-lucide="linkedin"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['with_linkedin'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Connected professional profiles</span></div>
  </article>
</div>

<div class="admin-toolbar">
  <div class="admin-toolbar__group">
    <span class="admin-muted"><?= count($team) ?> <?= count($team) === 1 ? 'member' : 'members' ?> on the team</span>
  </div>
  <button class="admin-btn admin-btn--primary" type="button" data-modal-open="#teamModal" data-modal-reset>
    <i data-lucide="user-plus"></i>
    Add team member
  </button>
</div>

<?php if (!$team): ?>
  <section class="admin-card">
    <div class="admin-card__body">
      <div class="admin-empty">
        <i data-lucide="users"></i>
        No team members yet. Add your first teammate to get started.
      </div>
    </div>
  </section>
<?php else: ?>
  <div class="admin-team-grid">
    <?php foreach ($team as $member): ?>
      <article class="admin-team-card">
        <div class="admin-team-card__photo<?= $member['photo_url'] ? '' : ' admin-team-card__photo--fallback' ?>">
          <?php if ($member['photo_url']): ?>
            <img src="<?= e(img_src($member['photo_url'])) ?>" alt="<?= e($member['name']) ?>" loading="lazy">
          <?php else: ?>
            <?= e(name_initials($member['name'])) ?>
          <?php endif; ?>
        </div>
        <div class="admin-team-card__body">
          <h3><?= e($member['name']) ?></h3>
          <p><?= e($member['role']) ?></p>
          <span><?= e($member['bio'] ? excerpt($member['bio'], 100) : 'No bio added yet.') ?></span>

          <div class="admin-team-card__actions">
            <button
              class="admin-btn admin-btn--outline admin-btn--sm"
              type="button"
              data-modal-open="#teamModal"
              data-edit-api="<?= e(url('api/team.php')) ?>"
              data-edit-id="<?= (int) $member['id'] ?>"
              data-edit-title="Edit team member"
            >
              <i data-lucide="pencil"></i>
              Edit
            </button>
            <button
              class="admin-btn admin-btn--ghost admin-btn--icon admin-btn--sm"
              type="button"
              title="Remove team member"
              data-delete-api="<?= e(url('api/team.php')) ?>"
              data-delete-id="<?= (int) $member['id'] ?>"
              data-confirm="Remove <?= e($member['name']) ?> from the team? Assigned tasks will be unassigned."
            >
              <i data-lucide="trash-2"></i>
            </button>
          </div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<div class="admin-modal" id="teamModal" data-add-title="Add team member" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="teamModalTitle">
  <div class="admin-modal__backdrop" data-modal-close></div>
  <div class="admin-modal__panel">
    <div class="admin-modal__head">
      <div>
        <h2 id="teamModalTitle" data-modal-title>Add team member</h2>
        <p>These details power the public team section.</p>
      </div>
      <button class="admin-modal__close" type="button" aria-label="Close dialog" data-modal-close>
        <i data-lucide="x"></i>
      </button>
    </div>

    <form data-api="<?= e(url('api/team.php')) ?>">
      <input type="hidden" name="id" value="">
      <div class="admin-form-grid">
        <div class="admin-field">
          <label for="teamName">Full name</label>
          <input id="teamName" name="name" type="text" maxlength="140" required>
          <span class="admin-field__error" data-error-for="name"></span>
        </div>

        <div class="admin-field">
          <label for="teamRole">Role</label>
          <input id="teamRole" name="role" type="text" maxlength="140" placeholder="e.g. Creative Director" required>
          <span class="admin-field__error" data-error-for="role"></span>
        </div>

        <div class="admin-field admin-field--full">
          <label for="teamPhoto">Photo URL</label>
          <input id="teamPhoto" name="photo_url" type="text" placeholder="https://… or assets/img/…">
          <span class="admin-field__error" data-error-for="photo_url"></span>
        </div>

        <div class="admin-field admin-field--full">
          <label for="teamBio">Bio</label>
          <textarea id="teamBio" name="bio" rows="4" maxlength="1200" placeholder="A short introduction for the website…"></textarea>
          <span class="admin-field__error" data-error-for="bio"></span>
        </div>

        <div class="admin-field">
          <label for="teamLinkedin">LinkedIn URL</label>
          <input id="teamLinkedin" name="linkedin_url" type="url" placeholder="https://linkedin.com/in/…">
          <span class="admin-field__error" data-error-for="linkedin_url"></span>
        </div>

        <div class="admin-field">
          <label for="teamInstagram">Instagram URL</label>
          <input id="teamInstagram" name="instagram_url" type="url" placeholder="https://instagram.com/…">
          <span class="admin-field__error" data-error-for="instagram_url"></span>
        </div>

        <div class="admin-field">
          <label for="teamTwitter">X / Twitter URL</label>
          <input id="teamTwitter" name="twitter_url" type="url" placeholder="https://x.com/…">
          <span class="admin-field__error" data-error-for="twitter_url"></span>
        </div>

        <div class="admin-field">
          <label for="teamFacebook">Facebook URL</label>
          <input id="teamFacebook" name="facebook_url" type="url" placeholder="https://facebook.com/…">
          <span class="admin-field__error" data-error-for="facebook_url"></span>
        </div>
      </div>

      <div class="admin-form-actions">
        <button class="admin-btn admin-btn--ghost" type="button" data-modal-close>Cancel</button>
        <button class="admin-btn admin-btn--primary" type="submit">
          <i data-lucide="check"></i>
          Save member
        </button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
