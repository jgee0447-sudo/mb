<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

if (!is_logged_in()) {
    redirect('admin/login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !verify_csrf()) {
    flash('error', 'Your session expired. Please try again.');
    redirect('admin/dashboard.php');
}

log_activity('Signed out of the admin panel');

$_SESSION = [];
session_regenerate_id(true);
flash('success', 'You have been signed out securely.');
redirect('admin/login.php');
