<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

$statusOptions = ['Completed', 'In Progress', 'Pending', 'On Hold', 'Cancelled'];
$categories = project_categories();

$status = trim((string) ($_GET['status'] ?? ''));
$category = trim((string) ($_GET['category'] ?? ''));
$search = trim((string) ($_GET['search'] ?? ''));
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;

if ($status !== '' && !in_array($status, $statusOptions, true)) {
    $status = '';
}

if ($category !== '' && !in_array($category, $categories, true)) {
    $category = '';
}

$conditions = [];
$params = [];

if ($status !== '') {
    $conditions[] = 'p.status = :status';
    $params['status'] = $status;
}

if ($category !== '') {
    $conditions[] = 'p.category = :category';
    $params['category'] = $category;
}

if ($search !== '') {
    $conditions[] = '(p.name LIKE :search_name OR c.company LIKE :search_company)';
    $like = '%' . $search . '%';
    $params['search_name'] = $like;
    $params['search_company'] = $like;
}

$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';

$countStatement = db()->prepare(
    'SELECT COUNT(*)
     FROM projects p
     LEFT JOIN clients c ON c.id = p.client_id' . $where
);
$countStatement->execute($params);
$totalProjects = (int) $countStatement->fetchColumn();
$totalPages = max(1, (int) ceil($totalProjects / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$projectsStatement = db()->prepare(
    'SELECT p.*, c.company AS client_company
     FROM projects p
     LEFT JOIN clients c ON c.id = p.client_id' . $where . '
     ORDER BY p.updated_at DESC, p.id DESC
     LIMIT :limit OFFSET :offset'
);

foreach ($params as $key => $value) {
    $projectsStatement->bindValue(':' . $key, $value);
}

$projectsStatement->bindValue(':limit', $perPage, PDO::PARAM_INT);
$projectsStatement->bindValue(':offset', $offset, PDO::PARAM_INT);
$projectsStatement->execute();
$projects = $projectsStatement->fetchAll();

$clients = db()->query('SELECT id, name, company FROM clients ORDER BY company ASC')->fetchAll();

$filterParams = array_filter([
    'status' => $status,
    'category' => $category,
    'search' => $search,
], static fn (string $value): bool => $value !== '');

$pageLink = static function (int $targetPage) use ($filterParams): string {
    return url('admin/projects.php') . '?' . http_build_query(array_merge($filterParams, ['page' => $targetPage]));
};

$rangeStart = max(1, $page - 2);
$rangeEnd = min($totalPages, $rangeStart + 4);
$rangeStart = max(1, $rangeEnd - 4);

$pageTitle = 'Projects';
$pageSubtitle = 'Manage active work, budgets and delivery progress.';
$activeAdmin = 'projects';

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-toolbar">
  <form class="admin-toolbar__group" method="get" action="<?= e(url('admin/projects.php')) ?>">
    <label class="admin-search">
      <i data-lucide="search"></i>
      <input type="search" name="search" value="<?= e($search) ?>" placeholder="Search projects or clients…" aria-label="Search projects">
    </label>
    <select class="admin-filter-select" name="status" aria-label="Filter by status" data-auto-submit>
      <option value="">All statuses</option>
      <?php foreach ($statusOptions as $option): ?>
        <option value="<?= e($option) ?>"<?= $status === $option ? ' selected' : '' ?>><?= e($option) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="admin-filter-select" name="category" aria-label="Filter by category" data-auto-submit>
      <option value="">All categories</option>
      <?php foreach ($categories as $option): ?>
        <option value="<?= e($option) ?>"<?= $category === $option ? ' selected' : '' ?>><?= e($option) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="admin-btn admin-btn--outline admin-btn--sm" type="submit">
      <i data-lucide="sliders-horizontal"></i>
      Filter
    </button>
    <?php if ($filterParams): ?>
      <a class="admin-btn admin-btn--ghost admin-btn--sm" href="<?= e(url('admin/projects.php')) ?>">Reset</a>
    <?php endif; ?>
  </form>

  <button class="admin-btn admin-btn--primary" type="button" data-modal-open="#projectModal" data-modal-reset>
    <i data-lucide="plus"></i>
    Add project
  </button>
</div>

<section class="admin-card">
  <div class="admin-card__head">
    <div>
      <h2>All projects</h2>
      <p><?= number_format($totalProjects) ?> <?= $totalProjects === 1 ? 'project' : 'projects' ?> found</p>
    </div>
  </div>

  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Project</th>
          <th>Client</th>
          <th>Category</th>
          <th>Status</th>
          <th>Progress</th>
          <th>Deadline</th>
          <th>Budget</th>
          <th aria-label="Actions"></th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$projects): ?>
          <tr>
            <td colspan="8" class="admin-table__empty">No projects match these filters.</td>
          </tr>
        <?php endif; ?>

        <?php foreach ($projects as $project): ?>
          <tr>
            <td>
              <div class="admin-table__title">
                <?php if ($project['image_url']): ?>
                  <img class="admin-table__thumb" src="<?= e(img_src($project['image_url'])) ?>" alt="" loading="lazy">
                <?php endif; ?>
                <span class="is-strong"><?= e($project['name']) ?></span>
              </div>
            </td>
            <td><?= e($project['client_company'] ?: 'Internal') ?></td>
            <td><?= e($project['category']) ?></td>
            <td><span class="admin-badge admin-badge--<?= e(status_slug($project['status'])) ?>"><?= e($project['status']) ?></span></td>
            <td>
              <div class="admin-progress">
                <div class="admin-progress__bar"><span style="width: <?= (int) $project['progress'] ?>%"></span></div>
                <small><?= (int) $project['progress'] ?>%</small>
              </div>
            </td>
            <td><?= e(format_date($project['deadline'], 'M j, Y')) ?></td>
            <td class="is-strong">$<?= number_format((float) $project['budget'], 0) ?></td>
            <td>
              <div class="admin-table__actions">
                <button
                  class="admin-btn admin-btn--ghost admin-btn--icon admin-btn--sm"
                  type="button"
                  title="Edit project"
                  data-modal-open="#projectModal"
                  data-edit-api="<?= e(url('api/projects.php')) ?>"
                  data-edit-id="<?= (int) $project['id'] ?>"
                  data-edit-title="Edit project"
                >
                  <i data-lucide="pencil"></i>
                </button>
                <button
                  class="admin-btn admin-btn--ghost admin-btn--icon admin-btn--sm"
                  type="button"
                  title="Delete project"
                  data-delete-api="<?= e(url('api/projects.php')) ?>"
                  data-delete-id="<?= (int) $project['id'] ?>"
                  data-confirm="Delete <?= e($project['name']) ?>? This cannot be undone."
                >
                  <i data-lucide="trash-2"></i>
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php if ($totalPages > 1): ?>
    <div class="admin-pagination">
      <span>Showing <?= number_format($offset + 1) ?>–<?= number_format(min($offset + $perPage, $totalProjects)) ?> of <?= number_format($totalProjects) ?></span>
      <div class="admin-pagination__links">
        <a class="admin-page-link" href="<?= e($pageLink(max(1, $page - 1))) ?>" aria-label="Previous page">‹</a>
        <?php for ($pageNumber = $rangeStart; $pageNumber <= $rangeEnd; $pageNumber++): ?>
          <a class="admin-page-link<?= $pageNumber === $page ? ' is-active' : '' ?>" href="<?= e($pageLink($pageNumber)) ?>"><?= $pageNumber ?></a>
        <?php endfor; ?>
        <a class="admin-page-link" href="<?= e($pageLink(min($totalPages, $page + 1))) ?>" aria-label="Next page">›</a>
      </div>
    </div>
  <?php endif; ?>
</section>

<div class="admin-modal" id="projectModal" data-add-title="Add project" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="projectModalTitle">
  <div class="admin-modal__backdrop" data-modal-close></div>
  <div class="admin-modal__panel">
    <div class="admin-modal__head">
      <div>
        <h2 id="projectModalTitle" data-modal-title>Add project</h2>
        <p>Track scope, progress and delivery dates.</p>
      </div>
      <button class="admin-modal__close" type="button" aria-label="Close dialog" data-modal-close>
        <i data-lucide="x"></i>
      </button>
    </div>

    <form data-api="<?= e(url('api/projects.php')) ?>">
      <input type="hidden" name="id" value="">
      <div class="admin-form-grid">
        <div class="admin-field admin-field--full">
          <label for="projectName">Project name</label>
          <input id="projectName" name="name" type="text" maxlength="180" required>
          <span class="admin-field__error" data-error-for="name"></span>
        </div>

        <div class="admin-field">
          <label for="projectClient">Client</label>
          <select id="projectClient" name="client_id">
            <option value="">Internal / unassigned</option>
            <?php foreach ($clients as $client): ?>
              <option value="<?= (int) $client['id'] ?>"><?= e($client['company']) ?> — <?= e($client['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <span class="admin-field__error" data-error-for="client_id"></span>
        </div>

        <div class="admin-field">
          <label for="projectCategory">Category</label>
          <select id="projectCategory" name="category" required>
            <?php foreach ($categories as $option): ?>
              <option value="<?= e($option) ?>"><?= e($option) ?></option>
            <?php endforeach; ?>
          </select>
          <span class="admin-field__error" data-error-for="category"></span>
        </div>

        <div class="admin-field">
          <label for="projectStatus">Status</label>
          <select id="projectStatus" name="status">
            <?php foreach ($statusOptions as $option): ?>
              <option value="<?= e($option) ?>"<?= $option === 'In Progress' ? ' selected' : '' ?>><?= e($option) ?></option>
            <?php endforeach; ?>
          </select>
          <span class="admin-field__error" data-error-for="status"></span>
        </div>

        <div class="admin-field">
          <label for="projectBudget">Budget (USD)</label>
          <input id="projectBudget" name="budget" type="number" min="0" step="0.01" value="0">
          <span class="admin-field__error" data-error-for="budget"></span>
        </div>

        <div class="admin-field">
          <label for="projectDeadline">Deadline</label>
          <input id="projectDeadline" name="deadline" type="date">
          <span class="admin-field__error" data-error-for="deadline"></span>
        </div>

        <div class="admin-field">
          <label for="projectProgress">Progress (%)</label>
          <input id="projectProgress" name="progress" type="number" min="0" max="100" value="0">
          <span class="admin-field__error" data-error-for="progress"></span>
        </div>

        <div class="admin-field admin-field--full">
          <label for="projectImage">Cover image URL</label>
          <input id="projectImage" name="image_url" type="text" placeholder="https://… or assets/img/…">
          <span class="admin-field__error" data-error-for="image_url"></span>
        </div>

        <div class="admin-field admin-field--full">
          <label for="projectDescription">Description</label>
          <textarea id="projectDescription" name="description" rows="3" placeholder="What did the project involve?"></textarea>
          <span class="admin-field__error" data-error-for="description"></span>
        </div>

        <div class="admin-field admin-field--full">
          <label for="projectResults">Results</label>
          <textarea id="projectResults" name="results" rows="3" placeholder="e.g. +48% conversions, 2.1× return on ad spend"></textarea>
          <span class="admin-field__error" data-error-for="results"></span>
        </div>

        <div class="admin-field admin-field--full">
          <label class="admin-check">
            <input type="checkbox" name="featured" value="1">
            Feature this project on the public portfolio
          </label>
          <span class="admin-field__error" data-error-for="featured"></span>
        </div>
      </div>

      <div class="admin-form-actions">
        <button class="admin-btn admin-btn--ghost" type="button" data-modal-close>Cancel</button>
        <button class="admin-btn admin-btn--primary" type="submit">
          <i data-lucide="check"></i>
          Save project
        </button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
