<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

$summary = db()->query(
    "SELECT
        (SELECT COUNT(*) FROM projects) AS total_projects,
        (SELECT COUNT(*) FROM projects WHERE status IN ('In Progress', 'Pending')) AS active_projects,
        (SELECT COUNT(*) FROM projects WHERE status = 'Completed') AS completed_projects,
        (SELECT COUNT(*) FROM clients) AS total_clients,
        (SELECT COUNT(*) FROM clients WHERE status = 'Active') AS active_clients,
        (SELECT COUNT(*) FROM messages WHERE is_read = 0) AS unread_messages,
        (SELECT COUNT(*) FROM tasks WHERE status <> 'Done') AS open_tasks,
        (SELECT COUNT(*) FROM tasks WHERE status <> 'Done' AND due_date IS NOT NULL AND due_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)) AS tasks_due_soon,
        (SELECT COALESCE(SUM(revenue), 0) FROM analytics_daily WHERE YEAR(metric_date) = YEAR(CURDATE())) AS revenue_ytd,
        (SELECT COALESCE(SUM(revenue), 0) FROM analytics_daily WHERE YEAR(metric_date) = YEAR(CURDATE()) - 1) AS revenue_last_year"
)->fetch() ?: [];

$recentProjects = db()->query(
    'SELECT p.id, p.name, p.status, p.progress, p.deadline, c.company AS client_company
     FROM projects p
     LEFT JOIN clients c ON c.id = p.client_id
     ORDER BY p.updated_at DESC, p.id DESC
     LIMIT 5'
)->fetchAll();

$upcomingTasks = db()->query(
    'SELECT t.id, t.title, t.priority, t.due_date, p.name AS project_name
     FROM tasks t
     LEFT JOIN projects p ON p.id = t.project_id
     WHERE t.status <> "Done"
     ORDER BY t.due_date IS NULL, t.due_date ASC, t.id DESC
     LIMIT 6'
)->fetchAll();

$recentActivity = db()->query(
    'SELECT a.action, a.entity_type, a.created_at, ad.name AS admin_name
     FROM activity_log a
     LEFT JOIN admins ad ON ad.id = a.admin_id
     ORDER BY a.created_at DESC
     LIMIT 6'
)->fetchAll();

$topClients = db()->query(
    'SELECT c.company, COUNT(p.id) AS projects, COALESCE(SUM(p.budget), 0) AS value
     FROM clients c
     INNER JOIN projects p ON p.client_id = c.id
     GROUP BY c.id, c.company
     ORDER BY value DESC
     LIMIT 5'
)->fetchAll();

$revenueCurrent = (float) ($summary['revenue_ytd'] ?? 0);
$revenuePrevious = (float) ($summary['revenue_last_year'] ?? 0);
$revenueGrowth = $revenuePrevious > 0
    ? (($revenueCurrent - $revenuePrevious) / $revenuePrevious) * 100
    : 0;

$pageTitle = 'Dashboard';
$pageSubtitle = 'A live view of your studio performance.';
$activeAdmin = 'dashboard';

$activityIcons = [
    'project' => 'folder-kanban',
    'client' => 'users',
    'task' => 'list-checks',
    'message' => 'mail',
    'team' => 'user-round',
    'settings' => 'settings',
];

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-stats">
  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Revenue YTD</span>
      <span class="admin-icon-tile tint-green"><i data-lucide="wallet"></i></span>
    </div>
    <strong class="admin-stat__value">$<?= number_format($revenueCurrent, 0) ?></strong>
    <div class="admin-stat__meta">
      <?php if ($revenuePrevious > 0): ?>
        <span class="<?= $revenueGrowth >= 0 ? 'up' : 'down' ?>"><?= $revenueGrowth >= 0 ? '+' : '' ?><?= number_format($revenueGrowth, 1) ?>%</span>
        <span>vs last year</span>
      <?php else: ?>
        <span>Current year to date</span>
      <?php endif; ?>
    </div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Active projects</span>
      <span class="admin-icon-tile tint-blue"><i data-lucide="folder-kanban"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['active_projects'] ?? 0) ?></strong>
    <div class="admin-stat__meta">
      <span><?= (int) ($summary['completed_projects'] ?? 0) ?> completed</span>
      <span>· <?= (int) ($summary['total_projects'] ?? 0) ?> total</span>
    </div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Active clients</span>
      <span class="admin-icon-tile tint-violet"><i data-lucide="users"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['active_clients'] ?? 0) ?></strong>
    <div class="admin-stat__meta">
      <span>Across <?= (int) ($summary['total_clients'] ?? 0) ?> client accounts</span>
    </div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Unread messages</span>
      <span class="admin-icon-tile tint-orange"><i data-lucide="mail"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['unread_messages'] ?? 0) ?></strong>
    <div class="admin-stat__meta">
      <span><?= (int) ($summary['open_tasks'] ?? 0) ?> open tasks</span>
      <span>· <?= (int) ($summary['tasks_due_soon'] ?? 0) ?> due soon</span>
    </div>
  </article>
</div>

<div class="admin-dashboard-grid">
  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Revenue overview</h2>
        <p>Monthly revenue for <?= e(date('Y')) ?></p>
      </div>
      <a class="admin-card__link" href="<?= e(url('admin/analytics.php')) ?>">
        Analytics <i data-lucide="arrow-up-right"></i>
      </a>
    </div>
    <div class="admin-card__body">
      <div class="admin-chart">
        <canvas id="dashboardRevenueChart" aria-label="Monthly revenue chart" role="img"></canvas>
      </div>
    </div>
  </section>

  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Project mix</h2>
        <p>Projects grouped by current status</p>
      </div>
      <a class="admin-card__link" href="<?= e(url('admin/projects.php')) ?>">
        View all <i data-lucide="arrow-up-right"></i>
      </a>
    </div>
    <div class="admin-card__body">
      <div class="admin-chart admin-chart--sm">
        <canvas id="dashboardStatusChart" aria-label="Projects by status chart" role="img"></canvas>
      </div>
    </div>
  </section>
</div>

<div class="admin-dashboard-grid">
  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Recent projects</h2>
        <p>Latest updates across the studio</p>
      </div>
      <a class="admin-card__link" href="<?= e(url('admin/projects.php')) ?>">
        All projects <i data-lucide="arrow-up-right"></i>
      </a>
    </div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Project</th>
            <th>Client</th>
            <th>Status</th>
            <th>Progress</th>
            <th>Deadline</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!$recentProjects): ?>
            <tr>
              <td colspan="5" class="admin-table__empty">No projects yet. Add your first project to get started.</td>
            </tr>
          <?php endif; ?>
          <?php foreach ($recentProjects as $project): ?>
            <tr>
              <td><span class="is-strong"><?= e($project['name']) ?></span></td>
              <td><?= e($project['client_company'] ?: 'Internal') ?></td>
              <td><span class="admin-badge admin-badge--<?= e(status_slug($project['status'])) ?>"><?= e($project['status']) ?></span></td>
              <td>
                <div class="admin-progress">
                  <div class="admin-progress__bar"><span style="width: <?= (int) $project['progress'] ?>%"></span></div>
                  <small><?= (int) $project['progress'] ?>%</small>
                </div>
              </td>
              <td><?= e(format_date($project['deadline'], 'M j')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Tasks needing attention</h2>
        <p>Upcoming and overdue work</p>
      </div>
      <a class="admin-card__link" href="<?= e(url('admin/tasks.php')) ?>">
        All tasks <i data-lucide="arrow-up-right"></i>
      </a>
    </div>
    <div class="admin-card__body">
      <?php if (!$upcomingTasks): ?>
        <div class="admin-empty">
          <i data-lucide="list-checks"></i>
          No open tasks right now.
        </div>
      <?php else: ?>
        <div class="admin-list">
          <?php foreach ($upcomingTasks as $task): ?>
            <?php
            $isOverdue = $task['due_date'] && $task['due_date'] < date('Y-m-d');
            ?>
            <div class="admin-list__item">
              <div>
                <strong><?= e($task['title']) ?></strong>
                <span>
                  <?= e($task['project_name'] ?: 'General') ?>
                  <?php if ($task['due_date']): ?>
                    · <?= e(format_date($task['due_date'], 'M j')) ?><?= $isOverdue ? ' (overdue)' : '' ?>
                  <?php endif; ?>
                </span>
              </div>
              <div class="admin-badge admin-badge--<?= e(status_slug($task['priority'])) ?>"><?= e($task['priority']) ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </section>
</div>

<div class="admin-dashboard-grid">
  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Recent activity</h2>
        <p>What changed in your workspace</p>
      </div>
    </div>
    <div class="admin-card__body">
      <?php if (!$recentActivity): ?>
        <div class="admin-empty">
          <i data-lucide="activity"></i>
          Activity will appear here as your team works.
        </div>
      <?php else: ?>
        <div class="admin-activity">
          <?php foreach ($recentActivity as $activity): ?>
            <?php $icon = $activityIcons[$activity['entity_type']] ?? 'activity'; ?>
            <div class="admin-activity__item">
              <span class="admin-activity__dot"><i data-lucide="<?= e($icon) ?>"></i></span>
              <div>
                <p><?= e($activity['action']) ?></p>
                <small><?= e($activity['admin_name'] ?: 'System') ?> · <?= e(format_date($activity['created_at'], 'M j, g:i a')) ?></small>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </section>

  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Top clients</h2>
        <p>Ranked by project value</p>
      </div>
      <a class="admin-card__link" href="<?= e(url('admin/clients.php')) ?>">
        All clients <i data-lucide="arrow-up-right"></i>
      </a>
    </div>
    <div class="admin-card__body">
      <?php if (!$topClients): ?>
        <div class="admin-empty">
          <i data-lucide="users"></i>
          Client insights will appear once projects are assigned.
        </div>
      <?php else: ?>
        <div class="admin-list">
          <?php foreach ($topClients as $client): ?>
            <div class="admin-list__item">
              <div>
                <strong><?= e($client['company']) ?></strong>
                <span><?= (int) $client['projects'] ?> <?= (int) $client['projects'] === 1 ? 'project' : 'projects' ?></span>
              </div>
              <strong>$<?= number_format((float) $client['value'], 0) ?></strong>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </section>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
