<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

$currentYear = (int) date('Y');
$previousYear = $currentYear - 1;

$current = db()->prepare(
    'SELECT COALESCE(SUM(visitors), 0) AS visitors,
            COALESCE(SUM(pageviews), 0) AS pageviews,
            COALESCE(SUM(revenue), 0) AS revenue
     FROM analytics_daily
     WHERE YEAR(metric_date) = :year'
);
$current->execute(['year' => $currentYear]);
$currentMetrics = $current->fetch() ?: [];

$previous = db()->prepare(
    'SELECT COALESCE(SUM(visitors), 0) AS visitors,
            COALESCE(SUM(pageviews), 0) AS pageviews,
            COALESCE(SUM(revenue), 0) AS revenue
     FROM analytics_daily
     WHERE YEAR(metric_date) = :year'
);
$previous->execute(['year' => $previousYear]);
$previousMetrics = $previous->fetch() ?: [];

$visitors = (int) ($currentMetrics['visitors'] ?? 0);
$pageviews = (int) ($currentMetrics['pageviews'] ?? 0);
$revenue = (float) ($currentMetrics['revenue'] ?? 0);

$previousVisitors = (int) ($previousMetrics['visitors'] ?? 0);
$previousRevenue = (float) ($previousMetrics['revenue'] ?? 0);

$visitorsGrowth = $previousVisitors > 0 ? (($visitors - $previousVisitors) / $previousVisitors) * 100 : 0;
$revenueGrowth = $previousRevenue > 0 ? (($revenue - $previousRevenue) / $previousRevenue) * 100 : 0;
$valuePerVisitor = $visitors > 0 ? $revenue / $visitors : 0;

$topCategories = db()->query(
    'SELECT category, COUNT(*) AS projects, COALESCE(SUM(budget), 0) AS value
     FROM projects
     GROUP BY category
     ORDER BY value DESC, projects DESC
     LIMIT 6'
)->fetchAll();

$topClients = db()->query(
    'SELECT c.company, COUNT(p.id) AS projects, COALESCE(SUM(p.budget), 0) AS value
     FROM clients c
     INNER JOIN projects p ON p.client_id = c.id
     GROUP BY c.id, c.company
     ORDER BY value DESC
     LIMIT 6'
)->fetchAll();

$pageTitle = 'Analytics';
$pageSubtitle = 'Traffic, revenue and portfolio performance for ' . $currentYear . '.';
$activeAdmin = 'analytics';

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-stats">
  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Visitors YTD</span>
      <span class="admin-icon-tile tint-blue"><i data-lucide="users-round"></i></span>
    </div>
    <strong class="admin-stat__value"><?= number_format($visitors) ?></strong>
    <div class="admin-stat__meta">
      <?php if ($previousVisitors > 0): ?>
        <span class="<?= $visitorsGrowth >= 0 ? 'up' : 'down' ?>"><?= $visitorsGrowth >= 0 ? '+' : '' ?><?= number_format($visitorsGrowth, 1) ?>%</span>
        <span>vs <?= $previousYear ?></span>
      <?php else: ?>
        <span>Current year to date</span>
      <?php endif; ?>
    </div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Pageviews YTD</span>
      <span class="admin-icon-tile tint-violet"><i data-lucide="panels-top-left"></i></span>
    </div>
    <strong class="admin-stat__value"><?= number_format($pageviews) ?></strong>
    <div class="admin-stat__meta">
      <span><?= $visitors > 0 ? number_format($pageviews / $visitors, 1) : '0.0' ?> pages per visitor</span>
    </div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Revenue YTD</span>
      <span class="admin-icon-tile tint-green"><i data-lucide="badge-dollar-sign"></i></span>
    </div>
    <strong class="admin-stat__value">$<?= number_format($revenue, 0) ?></strong>
    <div class="admin-stat__meta">
      <?php if ($previousRevenue > 0): ?>
        <span class="<?= $revenueGrowth >= 0 ? 'up' : 'down' ?>"><?= $revenueGrowth >= 0 ? '+' : '' ?><?= number_format($revenueGrowth, 1) ?>%</span>
        <span>vs <?= $previousYear ?></span>
      <?php else: ?>
        <span>Current year to date</span>
      <?php endif; ?>
    </div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Value per visitor</span>
      <span class="admin-icon-tile tint-orange"><i data-lucide="trending-up"></i></span>
    </div>
    <strong class="admin-stat__value">$<?= number_format($valuePerVisitor, 2) ?></strong>
    <div class="admin-stat__meta"><span>Revenue divided by visitors</span></div>
  </article>
</div>

<section class="admin-card">
  <div class="admin-card__head">
    <div>
      <h2>Audience growth</h2>
      <p>Monthly visitors and pageviews for <?= $currentYear ?></p>
    </div>
  </div>
  <div class="admin-card__body">
    <div class="admin-chart">
      <canvas id="analyticsVisitorsChart" aria-label="Visitors and pageviews chart" role="img"></canvas>
    </div>
  </div>
</section>

<div class="admin-dashboard-grid admin-section">
  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Revenue momentum</h2>
        <p>Monthly revenue trend</p>
      </div>
    </div>
    <div class="admin-card__body">
      <div class="admin-chart">
        <canvas id="analyticsRevenueChart" aria-label="Monthly revenue chart" role="img"></canvas>
      </div>
    </div>
  </section>

  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Project categories</h2>
        <p>Portfolio distribution by discipline</p>
      </div>
    </div>
    <div class="admin-card__body">
      <div class="admin-chart admin-chart--sm">
        <canvas id="analyticsCategoryChart" aria-label="Project category chart" role="img"></canvas>
      </div>
    </div>
  </section>
</div>

<div class="admin-grid-2 admin-section">
  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Top clients</h2>
        <p>Highest portfolio value</p>
      </div>
      <a class="admin-card__link" href="<?= e(url('admin/clients.php')) ?>">
        Manage <i data-lucide="arrow-up-right"></i>
      </a>
    </div>
    <div class="admin-card__body">
      <?php if (!$topClients): ?>
        <div class="admin-empty">
          <i data-lucide="users"></i>
          No client revenue data yet.
        </div>
      <?php else: ?>
        <div class="admin-list">
          <?php foreach ($topClients as $client): ?>
            <div class="admin-list__item">
              <div>
                <strong><?= e($client['company']) ?></strong>
                <span><?= (int) $client['projects'] ?> <?= (int) $client['projects'] === 1 ? 'project' : 'projects' ?></span>
              </div>
              <strong>$<?= number_format((float) $client['value'], 0) ?></strong>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </section>

  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Category value</h2>
        <p>Budget concentration by service line</p>
      </div>
      <a class="admin-card__link" href="<?= e(url('admin/projects.php')) ?>">
        Projects <i data-lucide="arrow-up-right"></i>
      </a>
    </div>
    <div class="admin-card__body">
      <?php if (!$topCategories): ?>
        <div class="admin-empty">
          <i data-lucide="pie-chart"></i>
          Project category insights will appear here.
        </div>
      <?php else: ?>
        <div class="admin-list">
          <?php foreach ($topCategories as $category): ?>
            <div class="admin-list__item">
              <div>
                <strong><?= e($category['category']) ?></strong>
                <span><?= (int) $category['projects'] ?> <?= (int) $category['projects'] === 1 ? 'project' : 'projects' ?></span>
              </div>
              <strong>$<?= number_format((float) $category['value'], 0) ?></strong>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </section>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
