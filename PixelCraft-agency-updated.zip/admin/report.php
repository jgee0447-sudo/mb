<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

$exportType = strtolower(trim((string) ($_GET['export'] ?? '')));

if ($exportType !== '') {
    $allowedTypes = ['projects', 'clients', 'tasks', 'messages', 'analytics'];

    if (!in_array($exportType, $allowedTypes, true)) {
        flash('error', 'That report type is not available.');
        redirect('admin/report.php');
    }

    $filename = 'pixelcraft-' . $exportType . '-' . date('Y-m-d') . '.csv';
    $headers = [];
    $rows = [];

    if ($exportType === 'projects') {
        $headers = ['ID', 'Project', 'Client', 'Category', 'Status', 'Progress %', 'Budget', 'Deadline', 'Created'];
        $statement = db()->query(
            'SELECT p.id, p.name, c.company AS client, p.category, p.status, p.progress, p.budget, p.deadline, p.created_at
             FROM projects p
             LEFT JOIN clients c ON c.id = p.client_id
             ORDER BY p.created_at DESC'
        );

        foreach ($statement->fetchAll() as $row) {
            $rows[] = [
                $row['id'],
                $row['name'],
                $row['client'] ?: 'Internal',
                $row['category'],
                $row['status'],
                $row['progress'],
                number_format((float) $row['budget'], 2, '.', ''),
                $row['deadline'] ?: '',
                $row['created_at'],
            ];
        }
    } elseif ($exportType === 'clients') {
        $headers = ['ID', 'Company', 'Contact', 'Email', 'Phone', 'Status', 'Projects', 'Portfolio Value', 'Created'];
        $statement = db()->query(
            'SELECT c.id, c.company, c.name, c.email, c.phone, c.status, COUNT(p.id) AS projects, COALESCE(SUM(p.budget), 0) AS value, c.created_at
             FROM clients c
             LEFT JOIN projects p ON p.client_id = c.id
             GROUP BY c.id
             ORDER BY c.company ASC'
        );

        foreach ($statement->fetchAll() as $row) {
            $rows[] = [
                $row['id'],
                $row['company'],
                $row['name'],
                $row['email'],
                $row['phone'] ?: '',
                $row['status'],
                $row['projects'],
                number_format((float) $row['value'], 2, '.', ''),
                $row['created_at'],
            ];
        }
    } elseif ($exportType === 'tasks') {
        $headers = ['ID', 'Task', 'Project', 'Owner', 'Status', 'Priority', 'Due Date', 'Created'];
        $statement = db()->query(
            'SELECT t.id, t.title, p.name AS project, tm.name AS owner, t.status, t.priority, t.due_date, t.created_at
             FROM tasks t
             LEFT JOIN projects p ON p.id = t.project_id
             LEFT JOIN team tm ON tm.id = t.team_id
             ORDER BY t.due_date IS NULL, t.due_date ASC, t.id DESC'
        );

        foreach ($statement->fetchAll() as $row) {
            $rows[] = [
                $row['id'],
                $row['title'],
                $row['project'] ?: 'General',
                $row['owner'] ?: 'Unassigned',
                $row['status'],
                $row['priority'],
                $row['due_date'] ?: '',
                $row['created_at'],
            ];
        }
    } elseif ($exportType === 'messages') {
        $headers = ['ID', 'Name', 'Email', 'Phone', 'Subject', 'Message', 'Read', 'Received'];
        $statement = db()->query('SELECT * FROM messages ORDER BY created_at DESC');

        foreach ($statement->fetchAll() as $row) {
            $rows[] = [
                $row['id'],
                $row['name'],
                $row['email'],
                $row['phone'] ?: '',
                $row['subject'],
                $row['message'],
                (int) $row['is_read'] ? 'Yes' : 'No',
                $row['created_at'],
            ];
        }
    } else {
        $headers = ['Date', 'Visitors', 'Pageviews', 'Revenue'];
        $statement = db()->query('SELECT metric_date, visitors, pageviews, revenue FROM analytics_daily ORDER BY metric_date ASC');

        foreach ($statement->fetchAll() as $row) {
            $rows[] = [
                $row['metric_date'],
                $row['visitors'],
                $row['pageviews'],
                number_format((float) $row['revenue'], 2, '.', ''),
            ];
        }
    }

    log_activity('Exported ' . $exportType . ' CSV report', 'report');

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');

    $output = fopen('php://output', 'wb');
    fwrite($output, "\xEF\xBB\xBF");
    fputcsv($output, $headers);

    foreach ($rows as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
    exit;
}

$summary = db()->query(
    "SELECT
        (SELECT COUNT(*) FROM projects) AS projects,
        (SELECT COUNT(*) FROM clients) AS clients,
        (SELECT COUNT(*) FROM tasks WHERE status <> 'Done') AS open_tasks,
        (SELECT COUNT(*) FROM messages WHERE is_read = 0) AS unread_messages,
        (SELECT COUNT(*) FROM analytics_daily) AS analytics_days,
        (SELECT COALESCE(SUM(revenue), 0) FROM analytics_daily WHERE YEAR(metric_date) = YEAR(CURDATE())) AS revenue_ytd"
)->fetch() ?: [];

$pageTitle = 'Reports';
$pageSubtitle = 'Export your workspace data for finance, delivery and client reviews.';
$activeAdmin = 'report';

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-stats">
  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Projects</span>
      <span class="admin-icon-tile tint-blue"><i data-lucide="folder-kanban"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['projects'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Included in project export</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Clients</span>
      <span class="admin-icon-tile tint-violet"><i data-lucide="building-2"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['clients'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Client directory records</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Open tasks</span>
      <span class="admin-icon-tile tint-orange"><i data-lucide="list-checks"></i></span>
    </div>
    <strong class="admin-stat__value"><?= (int) ($summary['open_tasks'] ?? 0) ?></strong>
    <div class="admin-stat__meta"><span>Available in task export</span></div>
  </article>

  <article class="admin-stat">
    <div class="admin-stat__top">
      <span class="admin-stat__label">Revenue YTD</span>
      <span class="admin-icon-tile tint-green"><i data-lucide="wallet"></i></span>
    </div>
    <strong class="admin-stat__value">$<?= number_format((float) ($summary['revenue_ytd'] ?? 0), 0) ?></strong>
    <div class="admin-stat__meta"><span>From <?= (int) ($summary['analytics_days'] ?? 0) ?> analytics snapshots</span></div>
  </article>
</div>

<div class="admin-grid-2">
  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Project register</h2>
        <p>Every project with client, category, status, budget and deadline.</p>
      </div>
      <span class="admin-icon-tile tint-blue"><i data-lucide="folder-kanban"></i></span>
    </div>
    <div class="admin-card__body">
      <p class="admin-muted">Useful for delivery reviews, pipeline planning and finance reconciliation.</p>
      <div class="admin-form-actions">
        <a class="admin-btn admin-btn--primary" href="<?= e(url('admin/report.php?export=projects')) ?>">
          <i data-lucide="download"></i>
          Export projects CSV
        </a>
      </div>
    </div>
  </section>

  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Client directory</h2>
        <p>Contacts, account status and combined project value.</p>
      </div>
      <span class="admin-icon-tile tint-violet"><i data-lucide="users"></i></span>
    </div>
    <div class="admin-card__body">
      <p class="admin-muted">Share with account teams or use it to prepare quarterly business reviews.</p>
      <div class="admin-form-actions">
        <a class="admin-btn admin-btn--primary" href="<?= e(url('admin/report.php?export=clients')) ?>">
          <i data-lucide="download"></i>
          Export clients CSV
        </a>
      </div>
    </div>
  </section>

  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Task log</h2>
        <p>Owners, priorities, statuses and due dates.</p>
      </div>
      <span class="admin-icon-tile tint-orange"><i data-lucide="list-checks"></i></span>
    </div>
    <div class="admin-card__body">
      <p class="admin-muted">Review team workload, overdue items and completed work in one file.</p>
      <div class="admin-form-actions">
        <a class="admin-btn admin-btn--primary" href="<?= e(url('admin/report.php?export=tasks')) ?>">
          <i data-lucide="download"></i>
          Export tasks CSV
        </a>
      </div>
    </div>
  </section>

  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Enquiry archive</h2>
        <p>All contact messages with read status and timestamps.</p>
      </div>
      <span class="admin-icon-tile tint-red"><i data-lucide="mail"></i></span>
    </div>
    <div class="admin-card__body">
      <p class="admin-muted">Keep a record of enquiries outside the dashboard for CRM or audit purposes.</p>
      <div class="admin-form-actions">
        <a class="admin-btn admin-btn--primary" href="<?= e(url('admin/report.php?export=messages')) ?>">
          <i data-lucide="download"></i>
          Export messages CSV
        </a>
      </div>
    </div>
  </section>

  <section class="admin-card">
    <div class="admin-card__head">
      <div>
        <h2>Analytics snapshots</h2>
        <p>Daily visitors, pageviews and revenue.</p>
      </div>
      <span class="admin-icon-tile tint-cyan"><i data-lucide="bar-chart-3"></i></span>
    </div>
    <div class="admin-card__body">
      <p class="admin-muted">Export raw daily metrics for spreadsheets or board reporting.</p>
      <div class="admin-form-actions">
        <a class="admin-btn admin-btn--primary" href="<?= e(url('admin/report.php?export=analytics')) ?>">
          <i data-lucide="download"></i>
          Export analytics CSV
        </a>
      </div>
    </div>
  </section>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
