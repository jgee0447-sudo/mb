<?php
$activeAdmin = $activeAdmin ?? '';
$unreadMessages = $unreadMessages ?? 0;

$adminNav = [
    'dashboard' => ['label' => 'Dashboard', 'href' => 'admin/dashboard.php', 'icon' => 'layout-dashboard'],
    'projects' => ['label' => 'Projects', 'href' => 'admin/projects.php', 'icon' => 'folder-kanban'],
    'clients' => ['label' => 'Clients', 'href' => 'admin/clients.php', 'icon' => 'users'],
    'tasks' => ['label' => 'Tasks', 'href' => 'admin/tasks.php', 'icon' => 'list-checks'],
    'messages' => ['label' => 'Messages', 'href' => 'admin/messages.php', 'icon' => 'mail'],
    'analytics' => ['label' => 'Analytics', 'href' => 'admin/analytics.php', 'icon' => 'bar-chart-3'],
    'report' => ['label' => 'Reports', 'href' => 'admin/report.php', 'icon' => 'file-down'],
    'team' => ['label' => 'Team', 'href' => 'admin/team.php', 'icon' => 'user-round'],
    'settings' => ['label' => 'Settings', 'href' => 'admin/settings.php', 'icon' => 'settings'],
];
?>
<aside class="admin-sidebar" id="adminSidebar">
  <a class="admin-brand" href="<?= e(url('admin/dashboard.php')) ?>">
    <span class="brand-mark">
      <img src="<?= e(ASSETS_URL) ?>/img/logo-mark.svg" alt="" width="40" height="40">
    </span>
    <span class="admin-brand__text">
      <span>PixelCraft</span>
      <small>Admin studio</small>
    </span>
  </a>

  <nav class="admin-nav" aria-label="Admin navigation">
    <span class="admin-nav__label">Workspace</span>
    <?php foreach ($adminNav as $key => $item): ?>
      <a class="admin-nav__link<?= $activeAdmin === $key ? ' is-active' : '' ?>" href="<?= e(url($item['href'])) ?>"<?= $activeAdmin === $key ? ' aria-current="page"' : '' ?>>
        <i data-lucide="<?= e($item['icon']) ?>"></i>
        <span><?= e($item['label']) ?></span>
        <?php if ($key === 'messages' && $unreadMessages > 0): ?>
          <span class="admin-nav__badge"><?= (int) $unreadMessages ?></span>
        <?php endif; ?>
      </a>
    <?php endforeach; ?>
  </nav>

  <div class="admin-sidebar__footer">
    <a class="admin-sidebar__site" href="<?= e(url('index.php')) ?>" target="_blank" rel="noopener">
      <i data-lucide="external-link"></i>
      View website
    </a>
    <form action="<?= e(url('admin/logout.php')) ?>" method="post">
      <?= csrf_field() ?>
      <button class="admin-sidebar__logout" type="submit">
        <i data-lucide="log-out"></i>
        Sign out
      </button>
    </form>
  </div>
</aside>

<div class="admin-overlay" data-close-sidebar></div>
