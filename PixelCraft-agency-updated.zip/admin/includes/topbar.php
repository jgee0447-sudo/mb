<?php
$pageTitle = $pageTitle ?? 'Dashboard';
$pageSubtitle = $pageSubtitle ?? '';
$adminName = $currentAdmin['name'] ?? 'Administrator';
$adminRole = $currentAdmin['role'] ?? 'admin';
$adminAvatar = $currentAdmin['avatar_url'] ?? '';
?>
<header class="admin-topbar">
  <div class="admin-topbar__left">
    <button class="admin-menu-toggle" id="adminMenuToggle" type="button" aria-label="Open admin menu" aria-expanded="false" aria-controls="adminSidebar">
      <i data-lucide="menu"></i>
    </button>
    <div>
      <span class="admin-topbar__date"><?= e(date('l, F j')) ?></span>
      <h1><?= e($pageTitle) ?></h1>
      <?php if ($pageSubtitle !== ''): ?>
        <p><?= e($pageSubtitle) ?></p>
      <?php endif; ?>
    </div>
  </div>

  <div class="admin-topbar__actions">
    <a class="admin-icon-btn" href="<?= e(url('index.php')) ?>" target="_blank" rel="noopener" aria-label="View public website">
      <i data-lucide="globe-2"></i>
    </a>
    <a class="admin-icon-btn" href="<?= e(url('admin/messages.php')) ?>" aria-label="Unread messages">
      <i data-lucide="bell"></i>
      <?php if ($unreadMessages > 0): ?>
        <span class="admin-icon-btn__badge"><?= (int) $unreadMessages ?></span>
      <?php endif; ?>
    </a>

    <div class="admin-user">
      <?php if ($adminAvatar): ?>
        <img src="<?= e(img_src($adminAvatar)) ?>" alt="<?= e($adminName) ?>">
      <?php else: ?>
        <span class="admin-avatar-fallback"><?= e(name_initials($adminName)) ?></span>
      <?php endif; ?>
      <span class="admin-user__text">
        <strong><?= e($adminName) ?></strong>
        <small><?= e(ucfirst($adminRole)) ?></small>
      </span>
    </div>
  </div>
</header>
