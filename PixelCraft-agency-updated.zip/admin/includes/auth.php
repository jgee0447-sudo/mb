<?php
/**
 * Admin authentication guard.
 * Include at the very top of every protected admin page and admin API.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/functions.php';

if (!is_logged_in()) {
    flash('error', 'Please sign in to continue.');
    redirect('admin/login.php');
}

$currentAdminStatement = db()->prepare('SELECT * FROM admins WHERE id = :id LIMIT 1');
$currentAdminStatement->execute(['id' => current_admin_id()]);
$currentAdmin = $currentAdminStatement->fetch();

if (!$currentAdmin) {
    $_SESSION = [];
    session_regenerate_id(true);
    flash('error', 'Your account could not be verified. Please sign in again.');
    redirect('admin/login.php');
}

$idleLimit = 2 * 60 * 60;
if (isset($_SESSION['last_activity']) && (time() - (int) $_SESSION['last_activity']) > $idleLimit) {
    $_SESSION = [];
    session_regenerate_id(true);
    flash('error', 'Your session expired. Please sign in again.');
    redirect('admin/login.php');
}

$_SESSION['last_activity'] = time();
