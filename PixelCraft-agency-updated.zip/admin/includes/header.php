<?php
require_once __DIR__ . '/auth.php';

$pageTitle = $pageTitle ?? 'Dashboard';
$pageSubtitle = $pageSubtitle ?? '';
$activeAdmin = $activeAdmin ?? 'dashboard';

try {
    $unreadMessages = (int) db()->query('SELECT COUNT(*) FROM messages WHERE is_read = 0')->fetchColumn();
} catch (Throwable $exception) {
    $unreadMessages = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <meta name="theme-color" content="#0F2A24">
  <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
  <title><?= e($pageTitle) ?> | PixelCraft Admin</title>
  <link rel="icon" type="image/svg+xml" href="<?= e(ASSETS_URL) ?>/img/logo-mark.svg">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,600;9..144,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(ASSETS_URL) ?>/css/admin.css">
</head>
<body class="admin-body" data-api-base="<?= e(url('api')) ?>">
  <div class="admin-shell">
    <?php include __DIR__ . '/sidebar.php'; ?>

    <div class="admin-main">
      <?php include __DIR__ . '/topbar.php'; ?>

      <div class="admin-content">
        <?php
        $adminFlashes = take_flashes();
        if ($adminFlashes):
        ?>
          <div class="admin-flashes" aria-live="polite">
            <?php foreach ($adminFlashes as $flash): ?>
              <div class="admin-flash admin-flash--<?= e($flash['type']) ?>">
                <i data-lucide="<?= $flash['type'] === 'success' ? 'circle-check' : ($flash['type'] === 'error' ? 'alert-circle' : 'info') ?>"></i>
                <span><?= e($flash['message']) ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
