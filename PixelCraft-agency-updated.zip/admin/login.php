<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

if (is_logged_in()) {
    redirect('admin/dashboard.php');
}

$loginError = '';
$emailValue = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emailValue = strtolower(clean_input($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    if (!verify_csrf()) {
        $loginError = 'Your session expired. Please try again.';
    } elseif ($emailValue === '' || $password === '') {
        $loginError = 'Enter both your email address and password.';
    } else {
        $attemptStatement = db()->prepare(
            'SELECT COUNT(*) FROM login_attempts
             WHERE (email = :email OR ip_address = :ip)
               AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)'
        );
        $attemptStatement->execute(['email' => $emailValue, 'ip' => $ipAddress]);
        $attempts = (int) $attemptStatement->fetchColumn();

        if ($attempts >= 5) {
            $loginError = 'Too many failed attempts. Please wait 15 minutes and try again.';
        } else {
            $statement = db()->prepare('SELECT * FROM admins WHERE email = :email LIMIT 1');
            $statement->execute(['email' => $emailValue]);
            $admin = $statement->fetch();

            if ($admin && password_verify($password, $admin['password_hash'])) {
                db()->prepare('DELETE FROM login_attempts WHERE email = :email OR ip_address = :ip')
                    ->execute(['email' => $emailValue, 'ip' => $ipAddress]);

                $update = db()->prepare('UPDATE admins SET last_login = NOW() WHERE id = :id');
                $update->execute(['id' => $admin['id']]);

                session_regenerate_id(true);
                $_SESSION['admin_id'] = (int) $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                $_SESSION['admin_email'] = $admin['email'];
                $_SESSION['admin_role'] = $admin['role'];
                $_SESSION['last_activity'] = time();

                log_activity('Signed in to the admin panel');
                flash('success', 'Welcome back, ' . $admin['name'] . '.');
                redirect('admin/dashboard.php');
            }

            db()->prepare(
                'INSERT INTO login_attempts (email, ip_address, attempted_at) VALUES (:email, :ip, NOW())'
            )->execute(['email' => $emailValue, 'ip' => $ipAddress]);

            $loginError = 'Those credentials do not match our records.';
        }
    }
}

$flashes = take_flashes();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <meta name="theme-color" content="#0F2A24">
  <title>Admin Sign In | PixelCraft</title>
  <link rel="icon" type="image/svg+xml" href="<?= e(ASSETS_URL) ?>/img/logo-mark.svg">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,600;9..144,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(ASSETS_URL) ?>/css/admin.css">
</head>
<body class="login-page">

  <main class="login-shell">
    <section class="login-visual" aria-hidden="true">
      <a class="login-brand" href="<?= e(url('index.php')) ?>">
        <span class="brand-mark">
          <img src="<?= e(ASSETS_URL) ?>/img/logo-mark.svg" alt="" width="40" height="40">
        </span>
        <span>
          <strong>PixelCraft</strong>
          <small>Admin Studio</small>
        </span>
      </a>

      <div class="login-visual__copy">
        <span class="login-eyebrow">Agency command centre</span>
        <h2>Run the studio from one calm, focused workspace.</h2>
        <p>Track projects, clients, tasks, messages, and growth — all in one place, with the numbers that matter.</p>
      </div>

      <ul class="login-features">
        <li><i data-lucide="layout-dashboard"></i> Live project and revenue overview</li>
        <li><i data-lucide="users"></i> Client and team management</li>
        <li><i data-lucide="bar-chart-3"></i> Monthly performance analytics</li>
      </ul>

      <div class="login-visual__foot">
        <span class="login-avatar">MK</span>
        <p>PixelCraft has doubled its project throughput since moving everything into this dashboard.</p>
      </div>
    </section>

    <section class="login-form-side">
      <div class="login-card">
        <div class="login-card__head">
          <span class="login-eyebrow">Secure sign in</span>
          <h1>Welcome back</h1>
          <p>Enter your credentials to open the PixelCraft workspace.</p>
        </div>

        <?php if ($loginError !== ''): ?>
          <div class="admin-flash admin-flash--error" role="alert">
            <i data-lucide="alert-circle"></i>
            <span><?= e($loginError) ?></span>
          </div>
        <?php endif; ?>

        <?php foreach ($flashes as $flash): ?>
          <div class="admin-flash admin-flash--<?= e($flash['type']) ?>" role="status">
            <i data-lucide="<?= $flash['type'] === 'success' ? 'circle-check' : 'info' ?>"></i>
            <span><?= e($flash['message']) ?></span>
          </div>
        <?php endforeach; ?>

        <form class="login-form" action="<?= e(url('admin/login.php')) ?>" method="post" novalidate>
          <?= csrf_field() ?>

          <div class="admin-field">
            <label for="loginEmail">Email address</label>
            <div class="admin-input-icon">
              <i data-lucide="mail"></i>
              <input type="email" id="loginEmail" name="email" value="<?= e($emailValue) ?>" placeholder="you@pixelcraft.agency" autocomplete="username" required autofocus>
            </div>
          </div>

          <div class="admin-field">
            <div class="admin-field__label-row">
              <label for="loginPassword">Password</label>
              <span class="admin-field__hint">Minimum 8 characters</span>
            </div>
            <div class="admin-input-icon">
              <i data-lucide="lock"></i>
              <input type="password" id="loginPassword" name="password" placeholder="Enter your password" autocomplete="current-password" required data-password-input>
              <button class="password-toggle" type="button" aria-label="Show password" data-toggle-password>
                <i data-lucide="eye"></i>
              </button>
            </div>
          </div>

          <button class="admin-btn admin-btn--primary admin-btn--block" type="submit">
            Sign in
            <i data-lucide="arrow-right"></i>
          </button>
        </form>

        <div class="login-demo">
          <i data-lucide="key-round"></i>
          <div>
            <strong>Demo credentials</strong>
            <span>admin@pixelcraft.agency &middot; Admin@123</span>
          </div>
        </div>

        <div class="login-card__foot">
          <a href="<?= e(url('index.php')) ?>">
            <i data-lucide="arrow-left"></i>
            Back to website
          </a>
          <span>&copy; <?= date('Y') ?> PixelCraft</span>
        </div>
      </div>
    </section>
  </main>

  <script src="https://unpkg.com/lucide@latest"></script>
  <script>
    if (window.lucide) { window.lucide.createIcons(); }
    document.querySelectorAll('[data-toggle-password]').forEach(function (button) {
      button.addEventListener('click', function () {
        var input = document.querySelector('[data-password-input]');
        if (!input) { return; }
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        button.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      });
    });
  </script>
</body>
</html>
