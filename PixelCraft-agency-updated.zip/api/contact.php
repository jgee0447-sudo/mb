<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_method(['POST']);

$expectsJson = wants_json();
$payload = api_payload();

$errors = [];
$name = clean_input((string) ($payload['name'] ?? ''));
$email = strtolower(clean_input((string) ($payload['email'] ?? '')));
$phone = clean_input((string) ($payload['phone'] ?? ''));
$subject = clean_input((string) ($payload['subject'] ?? ''));
$message = trim(strip_tags((string) ($payload['message'] ?? '')));
$website = trim((string) ($payload['website'] ?? ''));

if ($subject === '') {
    $subject = 'Website enquiry';
}

if ($website !== '') {
    if ($expectsJson) {
        json_response(['success' => true, 'message' => 'Thanks! Your message has been received.']);
    }
    flash('success', 'Thanks! Your message has been received.');
    redirect('contact.php');
}

if (!verify_csrf()) {
    if ($expectsJson) {
        json_response(['success' => false, 'message' => 'Your session expired. Refresh the page and try again.'], 419);
    }
    flash('error', 'Your session expired. Please try again.');
    redirect('contact.php');
}

if (mb_strlen($name) < 2 || mb_strlen($name) > 140) {
    $errors['name'] = 'Please enter your name (2–140 characters).';
}

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 160) {
    $errors['email'] = 'Please enter a valid email address.';
}

if ($phone !== '' && mb_strlen($phone) > 40) {
    $errors['phone'] = 'That phone number is too long.';
}

if (mb_strlen($subject) > 180) {
    $errors['subject'] = 'Please keep the subject under 180 characters.';
}

if (mb_strlen($message) < 10) {
    $errors['message'] = 'Please tell us a little more (at least 10 characters).';
} elseif (mb_strlen($message) > 5000) {
    $errors['message'] = 'Please keep your message under 5,000 characters.';
}

if ($errors) {
    if ($expectsJson) {
        api_fail('Please check the highlighted fields and try again.', $errors);
    }
    flash('error', reset($errors));
    redirect('contact.php');
}

$statement = db()->prepare(
    'INSERT INTO messages (name, email, phone, subject, message, is_read, created_at)
     VALUES (:name, :email, :phone, :subject, :message, 0, NOW())'
);
$statement->execute([
    'name' => $name,
    'email' => $email,
    'phone' => $phone !== '' ? $phone : null,
    'subject' => $subject,
    'message' => $message,
]);

if ($expectsJson) {
    json_response([
        'success' => true,
        'message' => 'Thanks for reaching out! We will reply within one business day.',
    ], 201);
}

flash('success', 'Thanks for reaching out! We will reply within one business day.');
redirect('contact.php');
