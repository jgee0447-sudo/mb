<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

$admin = api_admin();
$method = api_method(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']);
$statuses = ['Completed', 'In Progress', 'Pending', 'On Hold', 'Cancelled'];

if ($method === 'GET') {
    $conditions = [];
    $params = [];

    $id = api_optional_int($_GET['id'] ?? null);
    if ($id) {
        $conditions[] = 'p.id = :id';
        $params['id'] = $id;
    }

    $status = trim((string) ($_GET['status'] ?? ''));
    if ($status !== '') {
        $conditions[] = 'p.status = :status';
        $params['status'] = $status;
    }

    $category = trim((string) ($_GET['category'] ?? ''));
    if ($category !== '') {
        $conditions[] = 'p.category = :category';
        $params['category'] = $category;
    }

    $search = trim((string) ($_GET['search'] ?? ''));
    if ($search !== '') {
        $conditions[] = '(p.name LIKE :search_name OR p.description LIKE :search_description)';
        $like = '%' . $search . '%';
        $params['search_name'] = $like;
        $params['search_description'] = $like;
    }

    $sql = 'SELECT p.*, c.name AS client_name, c.company AS client_company
            FROM projects p
            LEFT JOIN clients c ON c.id = p.client_id';

    if ($conditions) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }

    $sql .= ' ORDER BY p.created_at DESC, p.id DESC LIMIT 200';

    $statement = db()->prepare($sql);
    $statement->execute($params);
    $projects = $statement->fetchAll();

    if ($id && !$projects) {
        api_fail('Project not found.', [], 404);
    }

    json_response([
        'success' => true,
        'data' => $id ? $projects[0] : $projects,
        'count' => count($projects),
    ]);
}

api_csrf();
$payload = api_payload();

$projectId = $method === 'DELETE'
    ? api_optional_int($payload['id'] ?? $_GET['id'] ?? null)
    : api_id_or_fail($payload);

if ($method === 'DELETE') {
    if (!$projectId) {
        api_fail('A valid project ID is required.');
    }

    $statement = db()->prepare('SELECT name FROM projects WHERE id = :id LIMIT 1');
    $statement->execute(['id' => $projectId]);
    $existing = $statement->fetch();

    if (!$existing) {
        api_fail('Project not found.', [], 404);
    }

    db()->prepare('DELETE FROM projects WHERE id = :id')->execute(['id' => $projectId]);
    log_activity('Deleted project — ' . $existing['name'], 'project', $projectId);

    json_response(['success' => true, 'message' => 'Project deleted successfully.']);
}

$name = clean_input((string) ($payload['name'] ?? ''));
$category = clean_input((string) ($payload['category'] ?? ''));
$status = clean_input((string) ($payload['status'] ?? 'In Progress'));
$description = trim((string) ($payload['description'] ?? ''));
$results = trim((string) ($payload['results'] ?? ''));
$imageUrl = trim((string) ($payload['image_url'] ?? ''));
$deadline = api_valid_date(isset($payload['deadline']) ? (string) $payload['deadline'] : null);
$budgetRaw = (string) ($payload['budget'] ?? '0');
$progressRaw = (string) ($payload['progress'] ?? '0');
$featured = !empty($payload['featured']) ? 1 : 0;
$clientId = api_optional_int($payload['client_id'] ?? null);

$errors = [];
$categories = project_categories();

if ($name === '' || mb_strlen($name) > 180) {
    $errors['name'] = 'A project name is required (max 180 characters).';
}

if ($category === '' || !in_array($category, $categories, true)) {
    $errors['category'] = 'Choose a valid project category.';
}

if (!in_array($status, $statuses, true)) {
    $errors['status'] = 'Choose a valid project status.';
}

if ($clientId !== null) {
    $clientCheck = db()->prepare('SELECT COUNT(*) FROM clients WHERE id = :id');
    $clientCheck->execute(['id' => $clientId]);
    if ((int) $clientCheck->fetchColumn() === 0) {
        $errors['client_id'] = 'The selected client no longer exists.';
    }
}

if ($imageUrl !== '') {
    if (!valid_image_ref($imageUrl) || mb_strlen($imageUrl) > 500) {
        $errors['image_url'] = 'Enter a valid image URL or an assets/… path.';
    }
}

if ($deadline === null && trim((string) ($payload['deadline'] ?? '')) !== '') {
    $errors['deadline'] = 'Enter a valid deadline date.';
}

if (!is_numeric($budgetRaw) || (float) $budgetRaw < 0) {
    $errors['budget'] = 'Budget must be a positive number.';
}

$progress = (int) $progressRaw;
if ($progress < 0 || $progress > 100) {
    $errors['progress'] = 'Progress must be between 0 and 100.';
}

if ($errors) {
    api_fail('Please check the highlighted fields and try again.', $errors);
}

$data = [
    'client_id' => $clientId,
    'name' => $name,
    'category' => $category,
    'status' => $status,
    'description' => $description,
    'results' => $results,
    'image_url' => $imageUrl !== '' ? $imageUrl : null,
    'deadline' => $deadline,
    'budget' => number_format((float) $budgetRaw, 2, '.', ''),
    'progress' => $progress,
    'featured' => $featured,
];

if ($method === 'POST') {
    $statement = db()->prepare(
        'INSERT INTO projects
         (client_id, name, category, status, description, results, image_url, deadline, budget, progress, featured, created_at, updated_at)
         VALUES
         (:client_id, :name, :category, :status, :description, :results, :image_url, :deadline, :budget, :progress, :featured, NOW(), NOW())'
    );
    $statement->execute($data);
    $projectId = (int) db()->lastInsertId();

    log_activity('Created project — ' . $name, 'project', $projectId);

    json_response([
        'success' => true,
        'message' => 'Project created successfully.',
        'id' => $projectId,
    ], 201);
}

$data['id'] = $projectId;

$statement = db()->prepare(
    'UPDATE projects SET
        client_id = :client_id,
        name = :name,
        category = :category,
        status = :status,
        description = :description,
        results = :results,
        image_url = :image_url,
        deadline = :deadline,
        budget = :budget,
        progress = :progress,
        featured = :featured,
        updated_at = NOW()
     WHERE id = :id'
);
$statement->execute($data);

if ($statement->rowCount() === 0) {
    $check = db()->prepare('SELECT COUNT(*) FROM projects WHERE id = :id');
    $check->execute(['id' => $projectId]);
    if ((int) $check->fetchColumn() === 0) {
        api_fail('Project not found.', [], 404);
    }
}

log_activity('Updated project — ' . $name, 'project', $projectId);

json_response([
    'success' => true,
    'message' => 'Project updated successfully.',
    'id' => $projectId,
]);
