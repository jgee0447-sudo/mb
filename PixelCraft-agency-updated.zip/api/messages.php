<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_admin();
$method = api_method(['GET', 'PUT', 'PATCH', 'DELETE']);

if ($method === 'GET') {
    $conditions = [];
    $params = [];

    $id = api_optional_int($_GET['id'] ?? null);
    if ($id) {
        $conditions[] = 'id = :id';
        $params['id'] = $id;
    }

    $read = $_GET['read'] ?? '';
    if ($read === 'unread') {
        $conditions[] = 'is_read = 0';
    } elseif ($read === 'read') {
        $conditions[] = 'is_read = 1';
    }

    $search = trim((string) ($_GET['search'] ?? ''));
    if ($search !== '') {
        $conditions[] = '(name LIKE :search_name OR email LIKE :search_email OR subject LIKE :search_subject OR message LIKE :search_message)';
        $like = '%' . $search . '%';
        $params['search_name'] = $like;
        $params['search_email'] = $like;
        $params['search_subject'] = $like;
        $params['search_message'] = $like;
    }

    $sql = 'SELECT * FROM messages';

    if ($conditions) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }

    $sql .= ' ORDER BY is_read ASC, created_at DESC LIMIT 300';

    $statement = db()->prepare($sql);
    $statement->execute($params);
    $messages = $statement->fetchAll();

    if ($id && !$messages) {
        api_fail('Message not found.', [], 404);
    }

    json_response([
        'success' => true,
        'data' => $id ? $messages[0] : $messages,
        'count' => count($messages),
    ]);
}

api_csrf();
$payload = api_payload();
$messageId = api_optional_int($payload['id'] ?? $_GET['id'] ?? null);

if (!$messageId) {
    api_fail('A valid message ID is required.');
}

$statement = db()->prepare('SELECT * FROM messages WHERE id = :id LIMIT 1');
$statement->execute(['id' => $messageId]);
$existing = $statement->fetch();

if (!$existing) {
    api_fail('Message not found.', [], 404);
}

if ($method === 'DELETE') {
    db()->prepare('DELETE FROM messages WHERE id = :id')->execute(['id' => $messageId]);
    log_activity('Deleted message from ' . $existing['name'], 'message', $messageId);

    json_response(['success' => true, 'message' => 'Message deleted.']);
}

$isRead = array_key_exists('is_read', $payload)
    ? (!empty($payload['is_read']) ? 1 : 0)
    : 1;

$statement = db()->prepare('UPDATE messages SET is_read = :is_read WHERE id = :id');
$statement->execute(['is_read' => $isRead, 'id' => $messageId]);

json_response([
    'success' => true,
    'message' => $isRead ? 'Message marked as read.' : 'Message marked as unread.',
    'is_read' => $isRead,
]);
