<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_admin();
$method = api_method(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']);

if ($method === 'GET') {
    $conditions = [];
    $params = [];

    $id = api_optional_int($_GET['id'] ?? null);
    if ($id) {
        $conditions[] = 'c.id = :id';
        $params['id'] = $id;
    }

    $status = trim((string) ($_GET['status'] ?? ''));
    if ($status !== '') {
        $conditions[] = 'c.status = :status';
        $params['status'] = $status;
    }

    $search = trim((string) ($_GET['search'] ?? ''));
    if ($search !== '') {
        $conditions[] = '(c.name LIKE :search_name OR c.company LIKE :search_company OR c.email LIKE :search_email)';
        $like = '%' . $search . '%';
        $params['search_name'] = $like;
        $params['search_company'] = $like;
        $params['search_email'] = $like;
    }

    $sql = 'SELECT c.*, COUNT(p.id) AS project_count, COALESCE(SUM(p.budget), 0) AS project_value
            FROM clients c
            LEFT JOIN projects p ON p.client_id = c.id';

    if ($conditions) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }

    $sql .= ' GROUP BY c.id ORDER BY c.created_at DESC, c.id DESC LIMIT 200';

    $statement = db()->prepare($sql);
    $statement->execute($params);
    $clients = $statement->fetchAll();

    if ($id && !$clients) {
        api_fail('Client not found.', [], 404);
    }

    json_response([
        'success' => true,
        'data' => $id ? $clients[0] : $clients,
        'count' => count($clients),
    ]);
}

api_csrf();
$payload = api_payload();

$clientId = $method === 'DELETE'
    ? api_optional_int($payload['id'] ?? $_GET['id'] ?? null)
    : api_id_or_fail($payload);

if ($method === 'DELETE') {
    if (!$clientId) {
        api_fail('A valid client ID is required.');
    }

    $statement = db()->prepare('SELECT name, company FROM clients WHERE id = :id LIMIT 1');
    $statement->execute(['id' => $clientId]);
    $existing = $statement->fetch();

    if (!$existing) {
        api_fail('Client not found.', [], 404);
    }

    db()->prepare('DELETE FROM clients WHERE id = :id')->execute(['id' => $clientId]);
    log_activity('Deleted client — ' . $existing['company'], 'client', $clientId);

    json_response(['success' => true, 'message' => 'Client deleted. Related projects were kept and unassigned.']);
}

$name = clean_input((string) ($payload['name'] ?? ''));
$company = clean_input((string) ($payload['company'] ?? ''));
$email = strtolower(clean_input((string) ($payload['email'] ?? '')));
$phone = clean_input((string) ($payload['phone'] ?? ''));
$status = clean_input((string) ($payload['status'] ?? 'Active'));
$logoInitial = strtoupper(clean_input((string) ($payload['logo_initial'] ?? '')));

$errors = [];

if (mb_strlen($name) < 2 || mb_strlen($name) > 140) {
    $errors['name'] = 'A contact name is required (2–140 characters).';
}

if (mb_strlen($company) < 2 || mb_strlen($company) > 160) {
    $errors['company'] = 'A company name is required (2–160 characters).';
}

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 160) {
    $errors['email'] = 'Enter a valid email address.';
}

if ($phone !== '' && mb_strlen($phone) > 40) {
    $errors['phone'] = 'That phone number is too long.';
}

if (!in_array($status, ['Active', 'Inactive'], true)) {
    $errors['status'] = 'Choose a valid client status.';
}

if ($logoInitial === '') {
    $logoInitial = name_initials($company);
}

if (mb_strlen($logoInitial) > 4) {
    $errors['logo_initial'] = 'Use up to 4 characters for the logo initials.';
}

if ($errors) {
    api_fail('Please check the highlighted fields and try again.', $errors);
}

$data = [
    'name' => $name,
    'company' => $company,
    'email' => $email,
    'phone' => $phone !== '' ? $phone : null,
    'status' => $status,
    'logo_initial' => $logoInitial,
];

if ($method === 'POST') {
    $statement = db()->prepare(
        'INSERT INTO clients (name, company, email, phone, status, logo_initial, created_at, updated_at)
         VALUES (:name, :company, :email, :phone, :status, :logo_initial, NOW(), NOW())'
    );
    $statement->execute($data);
    $clientId = (int) db()->lastInsertId();

    log_activity('Added client — ' . $company, 'client', $clientId);

    json_response([
        'success' => true,
        'message' => 'Client added successfully.',
        'id' => $clientId,
    ], 201);
}

$data['id'] = $clientId;

$statement = db()->prepare(
    'UPDATE clients SET
        name = :name,
        company = :company,
        email = :email,
        phone = :phone,
        status = :status,
        logo_initial = :logo_initial,
        updated_at = NOW()
     WHERE id = :id'
);
$statement->execute($data);

$check = db()->prepare('SELECT COUNT(*) FROM clients WHERE id = :id');
$check->execute(['id' => $clientId]);
if ((int) $check->fetchColumn() === 0) {
    api_fail('Client not found.', [], 404);
}

log_activity('Updated client — ' . $company, 'client', $clientId);

json_response([
    'success' => true,
    'message' => 'Client updated successfully.',
    'id' => $clientId,
]);
