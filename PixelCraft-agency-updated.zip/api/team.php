<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_admin();
$method = api_method(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']);

if ($method === 'GET') {
    $id = api_optional_int($_GET['id'] ?? null);

    if ($id) {
        $statement = db()->prepare('SELECT * FROM team WHERE id = :id LIMIT 1');
        $statement->execute(['id' => $id]);
        $member = $statement->fetch();

        if (!$member) {
            api_fail('Team member not found.', [], 404);
        }

        json_response(['success' => true, 'data' => $member]);
    }

    $members = db()->query('SELECT * FROM team ORDER BY name ASC')->fetchAll();
    json_response(['success' => true, 'data' => $members, 'count' => count($members)]);
}

api_csrf();
$payload = api_payload();

$memberId = $method === 'DELETE'
    ? api_optional_int($payload['id'] ?? $_GET['id'] ?? null)
    : api_id_or_fail($payload);

if ($method === 'DELETE') {
    if (!$memberId) {
        api_fail('A valid team member ID is required.');
    }

    $statement = db()->prepare('SELECT name FROM team WHERE id = :id LIMIT 1');
    $statement->execute(['id' => $memberId]);
    $existing = $statement->fetch();

    if (!$existing) {
        api_fail('Team member not found.', [], 404);
    }

    db()->prepare('DELETE FROM team WHERE id = :id')->execute(['id' => $memberId]);
    log_activity('Removed team member — ' . $existing['name'], 'team', $memberId);

    json_response(['success' => true, 'message' => 'Team member removed.']);
}

$name = clean_input((string) ($payload['name'] ?? ''));
$role = clean_input((string) ($payload['role'] ?? ''));
$bio = trim((string) ($payload['bio'] ?? ''));
$photoUrl = trim((string) ($payload['photo_url'] ?? ''));
$socialFields = [
    'facebook_url' => 'Facebook',
    'instagram_url' => 'Instagram',
    'linkedin_url' => 'LinkedIn',
    'twitter_url' => 'X / Twitter',
];
$socials = [];
$errors = [];

if (mb_strlen($name) < 2 || mb_strlen($name) > 140) {
    $errors['name'] = 'A name is required (2–140 characters).';
}

if (mb_strlen($role) < 2 || mb_strlen($role) > 140) {
    $errors['role'] = 'A role is required (2–140 characters).';
}

if (mb_strlen($bio) > 1200) {
    $errors['bio'] = 'Keep the bio under 1,200 characters.';
}

if ($photoUrl !== '') {
    if (!valid_image_ref($photoUrl) || mb_strlen($photoUrl) > 500) {
        $errors['photo_url'] = 'Enter a valid photo URL or an assets/… path.';
    }
}

foreach ($socialFields as $field => $label) {
    $value = trim((string) ($payload[$field] ?? ''));
    $socials[$field] = $value !== '' ? $value : null;

    if ($value !== '' && (!filter_var($value, FILTER_VALIDATE_URL) || mb_strlen($value) > 500)) {
        $errors[$field] = 'Enter a valid ' . $label . ' URL.';
    }
}

if ($errors) {
    api_fail('Please check the highlighted fields and try again.', $errors);
}

$data = array_merge([
    'name' => $name,
    'role' => $role,
    'bio' => $bio,
    'photo_url' => $photoUrl !== '' ? $photoUrl : null,
], $socials);

if ($method === 'POST') {
    $statement = db()->prepare(
        'INSERT INTO team (name, role, bio, photo_url, facebook_url, instagram_url, linkedin_url, twitter_url, created_at, updated_at)
         VALUES (:name, :role, :bio, :photo_url, :facebook_url, :instagram_url, :linkedin_url, :twitter_url, NOW(), NOW())'
    );
    $statement->execute($data);
    $memberId = (int) db()->lastInsertId();

    log_activity('Added team member — ' . $name, 'team', $memberId);

    json_response([
        'success' => true,
        'message' => 'Team member added.',
        'id' => $memberId,
    ], 201);
}

$data['id'] = $memberId;

$statement = db()->prepare(
    'UPDATE team SET
        name = :name,
        role = :role,
        bio = :bio,
        photo_url = :photo_url,
        facebook_url = :facebook_url,
        instagram_url = :instagram_url,
        linkedin_url = :linkedin_url,
        twitter_url = :twitter_url,
        updated_at = NOW()
     WHERE id = :id'
);
$statement->execute($data);

$check = db()->prepare('SELECT COUNT(*) FROM team WHERE id = :id');
$check->execute(['id' => $memberId]);
if ((int) $check->fetchColumn() === 0) {
    api_fail('Team member not found.', [], 404);
}

log_activity('Updated team member — ' . $name, 'team', $memberId);

json_response([
    'success' => true,
    'message' => 'Team member updated.',
    'id' => $memberId,
]);
