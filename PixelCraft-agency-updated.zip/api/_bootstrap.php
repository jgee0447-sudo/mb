<?php
/**
 * Shared helpers for JSON API endpoints.
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

function api_method(array $allowed): string
{
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

    if (!in_array($method, $allowed, true)) {
        header('Allow: ' . implode(', ', $allowed));
        json_response(['success' => false, 'message' => 'Method not allowed.'], 405);
    }

    return $method;
}

function api_admin(): array
{
    if (!is_logged_in()) {
        json_response(['success' => false, 'message' => 'Authentication required.'], 401);
    }

    $statement = db()->prepare('SELECT id, name, email, role, avatar_url FROM admins WHERE id = :id LIMIT 1');
    $statement->execute(['id' => current_admin_id()]);
    $admin = $statement->fetch();

    if (!$admin) {
        json_response(['success' => false, 'message' => 'Authentication required.'], 401);
    }

    return $admin;
}

function api_csrf(): void
{
    if (!verify_csrf()) {
        json_response(['success' => false, 'message' => 'Your session expired. Refresh the page and try again.'], 419);
    }
}

function api_payload(): array
{
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (str_contains($contentType, 'application/json')) {
        return json_input();
    }

    if (!empty($_POST)) {
        return $_POST;
    }

    return json_input();
}

function api_fail(string $message, array $errors = [], int $status = 422): never
{
    json_response([
        'success' => false,
        'message' => $message,
        'errors' => $errors,
    ], $status);
}

function api_optional_int(mixed $value): ?int
{
    if ($value === null || $value === '' || $value === false) {
        return null;
    }

    return filter_var($value, FILTER_VALIDATE_INT) !== false ? (int) $value : null;
}

function api_valid_date(?string $value): ?string
{
    if ($value === null || trim($value) === '') {
        return null;
    }

    $date = DateTime::createFromFormat('Y-m-d', trim($value));

    return $date && $date->format('Y-m-d') === trim($value) ? $date->format('Y-m-d') : null;
}

function api_id_or_fail(array $payload): int
{
    $id = api_optional_int($payload['id'] ?? null);

    if (!$id || $id < 1) {
        api_fail('A valid record ID is required.');
    }

    return $id;
}
