<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_admin();
$method = api_method(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']);
$statuses = ['To Do', 'In Progress', 'Done'];
$priorities = ['Low', 'Medium', 'High'];

if ($method === 'GET') {
    $conditions = [];
    $params = [];

    $id = api_optional_int($_GET['id'] ?? null);
    if ($id) {
        $conditions[] = 't.id = :id';
        $params['id'] = $id;
    }

    $status = trim((string) ($_GET['status'] ?? ''));
    if ($status !== '') {
        $conditions[] = 't.status = :status';
        $params['status'] = $status;
    }

    $projectId = api_optional_int($_GET['project_id'] ?? null);
    if ($projectId) {
        $conditions[] = 't.project_id = :project_id';
        $params['project_id'] = $projectId;
    }

    $search = trim((string) ($_GET['search'] ?? ''));
    if ($search !== '') {
        $conditions[] = '(t.title LIKE :search_title OR t.description LIKE :search_description)';
        $like = '%' . $search . '%';
        $params['search_title'] = $like;
        $params['search_description'] = $like;
    }

    $sql = 'SELECT t.*, p.name AS project_name, tm.name AS team_name, tm.photo_url AS team_photo
            FROM tasks t
            LEFT JOIN projects p ON p.id = t.project_id
            LEFT JOIN team tm ON tm.id = t.team_id';

    if ($conditions) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }

    $sql .= ' ORDER BY FIELD(t.status, "In Progress", "To Do", "Done"), t.due_date IS NULL, t.due_date ASC, t.id DESC LIMIT 300';

    $statement = db()->prepare($sql);
    $statement->execute($params);
    $tasks = $statement->fetchAll();

    if ($id && !$tasks) {
        api_fail('Task not found.', [], 404);
    }

    json_response([
        'success' => true,
        'data' => $id ? $tasks[0] : $tasks,
        'count' => count($tasks),
    ]);
}

api_csrf();
$payload = api_payload();

$taskId = $method === 'DELETE'
    ? api_optional_int($payload['id'] ?? $_GET['id'] ?? null)
    : api_id_or_fail($payload);

if ($method === 'DELETE') {
    if (!$taskId) {
        api_fail('A valid task ID is required.');
    }

    $statement = db()->prepare('SELECT title FROM tasks WHERE id = :id LIMIT 1');
    $statement->execute(['id' => $taskId]);
    $existing = $statement->fetch();

    if (!$existing) {
        api_fail('Task not found.', [], 404);
    }

    db()->prepare('DELETE FROM tasks WHERE id = :id')->execute(['id' => $taskId]);
    log_activity('Deleted task — ' . $existing['title'], 'task', $taskId);

    json_response(['success' => true, 'message' => 'Task deleted successfully.']);
}

$title = clean_input((string) ($payload['title'] ?? ''));
$description = trim((string) ($payload['description'] ?? ''));
$status = clean_input((string) ($payload['status'] ?? 'To Do'));
$priority = clean_input((string) ($payload['priority'] ?? 'Medium'));
$projectId = api_optional_int($payload['project_id'] ?? null);
$teamId = api_optional_int($payload['team_id'] ?? null);
$dueDate = api_valid_date(isset($payload['due_date']) ? (string) $payload['due_date'] : null);

$errors = [];

if ($title === '' || mb_strlen($title) > 180) {
    $errors['title'] = 'A task title is required (max 180 characters).';
}

if (!in_array($status, $statuses, true)) {
    $errors['status'] = 'Choose a valid task status.';
}

if (!in_array($priority, $priorities, true)) {
    $errors['priority'] = 'Choose a valid priority.';
}

if ($projectId !== null) {
    $check = db()->prepare('SELECT COUNT(*) FROM projects WHERE id = :id');
    $check->execute(['id' => $projectId]);
    if ((int) $check->fetchColumn() === 0) {
        $errors['project_id'] = 'The selected project no longer exists.';
    }
}

if ($teamId !== null) {
    $check = db()->prepare('SELECT COUNT(*) FROM team WHERE id = :id');
    $check->execute(['id' => $teamId]);
    if ((int) $check->fetchColumn() === 0) {
        $errors['team_id'] = 'The selected team member no longer exists.';
    }
}

if ($dueDate === null && trim((string) ($payload['due_date'] ?? '')) !== '') {
    $errors['due_date'] = 'Enter a valid due date.';
}

if ($errors) {
    api_fail('Please check the highlighted fields and try again.', $errors);
}

$data = [
    'project_id' => $projectId,
    'team_id' => $teamId,
    'title' => $title,
    'description' => $description,
    'status' => $status,
    'priority' => $priority,
    'due_date' => $dueDate,
];

if ($method === 'POST') {
    $statement = db()->prepare(
        'INSERT INTO tasks (project_id, team_id, title, description, status, priority, due_date, created_at, updated_at)
         VALUES (:project_id, :team_id, :title, :description, :status, :priority, :due_date, NOW(), NOW())'
    );
    $statement->execute($data);
    $taskId = (int) db()->lastInsertId();

    log_activity('Created task — ' . $title, 'task', $taskId);

    json_response([
        'success' => true,
        'message' => 'Task created successfully.',
        'id' => $taskId,
    ], 201);
}

$data['id'] = $taskId;

$statement = db()->prepare(
    'UPDATE tasks SET
        project_id = :project_id,
        team_id = :team_id,
        title = :title,
        description = :description,
        status = :status,
        priority = :priority,
        due_date = :due_date,
        updated_at = NOW()
     WHERE id = :id'
);
$statement->execute($data);

$check = db()->prepare('SELECT COUNT(*) FROM tasks WHERE id = :id');
$check->execute(['id' => $taskId]);
if ((int) $check->fetchColumn() === 0) {
    api_fail('Task not found.', [], 404);
}

log_activity('Updated task — ' . $title, 'task', $taskId);

json_response([
    'success' => true,
    'message' => 'Task updated successfully.',
    'id' => $taskId,
]);
