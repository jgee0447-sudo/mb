<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_admin();
api_method(['GET']);

$currentYear = (int) date('Y');
$previousYear = $currentYear - 1;

$totals = db()->query(
    "SELECT
        (SELECT COUNT(*) FROM projects) AS total_projects,
        (SELECT COUNT(*) FROM projects WHERE status IN ('In Progress', 'Pending')) AS active_projects,
        (SELECT COUNT(*) FROM projects WHERE status = 'Completed') AS completed_projects,
        (SELECT COUNT(*) FROM clients) AS total_clients,
        (SELECT COUNT(*) FROM clients WHERE status = 'Active') AS active_clients,
        (SELECT COUNT(*) FROM team) AS team_members,
        (SELECT COUNT(*) FROM messages WHERE is_read = 0) AS unread_messages,
        (SELECT COUNT(*) FROM tasks WHERE status <> 'Done') AS open_tasks,
        (SELECT COUNT(*) FROM tasks WHERE status <> 'Done' AND due_date IS NOT NULL AND due_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)) AS tasks_due_soon,
        (SELECT COALESCE(SUM(revenue), 0) FROM analytics_daily WHERE YEAR(metric_date) = YEAR(CURDATE())) AS revenue_ytd,
        (SELECT COALESCE(SUM(revenue), 0) FROM analytics_daily WHERE YEAR(metric_date) = YEAR(CURDATE()) - 1) AS revenue_last_year,
        (SELECT COALESCE(SUM(visitors), 0) FROM analytics_daily WHERE YEAR(metric_date) = YEAR(CURDATE())) AS visitors_ytd,
        (SELECT COALESCE(SUM(visitors), 0) FROM analytics_daily WHERE YEAR(metric_date) = YEAR(CURDATE()) - 1) AS visitors_last_year,
        (SELECT COALESCE(SUM(pageviews), 0) FROM analytics_daily WHERE YEAR(metric_date) = YEAR(CURDATE())) AS pageviews_ytd"
)->fetch() ?: [];

$projectsByStatus = [
    'Completed' => 0,
    'In Progress' => 0,
    'Pending' => 0,
    'On Hold' => 0,
    'Cancelled' => 0,
];

foreach (db()->query('SELECT status, COUNT(*) AS total FROM projects GROUP BY status')->fetchAll() as $row) {
    $projectsByStatus[$row['status']] = (int) $row['total'];
}

$monthly = [];
for ($month = 1; $month <= 12; $month++) {
    $monthly[$month] = [
        'month' => date('M', mktime(0, 0, 0, $month, 1)),
        'visitors' => 0,
        'pageviews' => 0,
        'revenue' => 0.0,
    ];
}

$monthlyStatement = db()->prepare(
    'SELECT MONTH(metric_date) AS month_number,
            COALESCE(SUM(visitors), 0) AS visitors,
            COALESCE(SUM(pageviews), 0) AS pageviews,
            COALESCE(SUM(revenue), 0) AS revenue
     FROM analytics_daily
     WHERE YEAR(metric_date) = :year
     GROUP BY MONTH(metric_date)
     ORDER BY month_number ASC'
);
$monthlyStatement->execute(['year' => $currentYear]);

foreach ($monthlyStatement->fetchAll() as $row) {
    $number = (int) $row['month_number'];
    if (isset($monthly[$number])) {
        $monthly[$number]['visitors'] = (int) $row['visitors'];
        $monthly[$number]['pageviews'] = (int) $row['pageviews'];
        $monthly[$number]['revenue'] = (float) $row['revenue'];
    }
}

$categories = db()->query(
    'SELECT category, COUNT(*) AS total
     FROM projects
     GROUP BY category
     ORDER BY total DESC, category ASC'
)->fetchAll();

$recentActivity = db()->query(
    'SELECT a.action, a.entity_type, a.created_at, ad.name AS admin_name
     FROM activity_log a
     LEFT JOIN admins ad ON ad.id = a.admin_id
     ORDER BY a.created_at DESC
     LIMIT 7'
)->fetchAll();

$recentProjects = db()->query(
    'SELECT p.id, p.name, p.status, p.progress, p.image_url, c.company AS client_company
     FROM projects p
     LEFT JOIN clients c ON c.id = p.client_id
     ORDER BY p.updated_at DESC, p.id DESC
     LIMIT 5'
)->fetchAll();

$taskSummary = [
    'To Do' => 0,
    'In Progress' => 0,
    'Done' => 0,
];

foreach (db()->query('SELECT status, COUNT(*) AS total FROM tasks GROUP BY status')->fetchAll() as $row) {
    $taskSummary[$row['status']] = (int) $row['total'];
}

$topClients = db()->query(
    'SELECT c.company, COUNT(p.id) AS projects, COALESCE(SUM(p.budget), 0) AS value
     FROM clients c
     INNER JOIN projects p ON p.client_id = c.id
     GROUP BY c.id, c.company
     ORDER BY value DESC
     LIMIT 5'
)->fetchAll();

$revenueCurrent = (float) ($totals['revenue_ytd'] ?? 0);
$revenuePrevious = (float) ($totals['revenue_last_year'] ?? 0);
$visitorsCurrent = (int) ($totals['visitors_ytd'] ?? 0);
$visitorsPrevious = (int) ($totals['visitors_last_year'] ?? 0);

$revenueGrowth = $revenuePrevious > 0
    ? round((($revenueCurrent - $revenuePrevious) / $revenuePrevious) * 100, 1)
    : 0.0;

$visitorsGrowth = $visitorsPrevious > 0
    ? round((($visitorsCurrent - $visitorsPrevious) / $visitorsPrevious) * 100, 1)
    : 0.0;

json_response([
    'success' => true,
    'data' => [
        'year' => $currentYear,
        'totals' => [
            'total_projects' => (int) ($totals['total_projects'] ?? 0),
            'active_projects' => (int) ($totals['active_projects'] ?? 0),
            'completed_projects' => (int) ($totals['completed_projects'] ?? 0),
            'total_clients' => (int) ($totals['total_clients'] ?? 0),
            'active_clients' => (int) ($totals['active_clients'] ?? 0),
            'team_members' => (int) ($totals['team_members'] ?? 0),
            'unread_messages' => (int) ($totals['unread_messages'] ?? 0),
            'open_tasks' => (int) ($totals['open_tasks'] ?? 0),
            'tasks_due_soon' => (int) ($totals['tasks_due_soon'] ?? 0),
            'revenue_ytd' => $revenueCurrent,
            'revenue_last_year' => $revenuePrevious,
            'revenue_growth' => $revenueGrowth,
            'visitors_ytd' => $visitorsCurrent,
            'visitors_last_year' => $visitorsPrevious,
            'visitors_growth' => $visitorsGrowth,
            'pageviews_ytd' => (int) ($totals['pageviews_ytd'] ?? 0),
            'previous_year' => $previousYear,
        ],
        'projects_by_status' => $projectsByStatus,
        'task_summary' => $taskSummary,
        'monthly' => array_values($monthly),
        'categories' => array_map(static function (array $row): array {
            return ['category' => $row['category'], 'total' => (int) $row['total']];
        }, $categories),
        'recent_activity' => $recentActivity,
        'recent_projects' => $recentProjects,
        'top_clients' => array_map(static function (array $row): array {
            return [
                'company' => $row['company'],
                'projects' => (int) $row['projects'],
                'value' => (float) $row['value'],
            ];
        }, $topClients),
    ],
]);
