<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Terms of Service';
$pageDescription = 'The terms that apply when you browse the PixelCraft website and engage our digital agency services.';
$activePage = '';

require __DIR__ . '/includes/header.php';
?>
<main id="mainContent">

  <section class="page-hero">
    <div class="container">
      <div class="page-hero__inner reveal">
        <nav class="breadcrumbs" aria-label="Breadcrumb">
          <a href="<?= e(url('index.php')) ?>">Home</a>
          <i data-lucide="chevron-right"></i>
          <span aria-current="page">Terms of Service</span>
        </nav>
        <span class="eyebrow">Legal</span>
        <h1>Terms of Service</h1>
        <p>Last updated: <?= e(date('F j, Y')) ?>. These terms govern your use of this website and the general basis on which we provide services.</p>
      </div>
    </div>
  </section>

  <section class="container">
    <div class="legal-layout reveal">
      <h2>Using this website</h2>
      <p>By accessing this website, you agree to use it lawfully and respectfully. You must not attempt to disrupt the site, gain unauthorised access to our systems, or use the content in a way that infringes the rights of others.</p>

      <h2>Intellectual property</h2>
      <p>Unless otherwise stated, the content on this website — including text, graphics, logos, images, and code — is owned by or licensed to PixelCraft and is protected by applicable intellectual property laws. You may view and share links to our content, but you may not reproduce, republish, or distribute it for commercial purposes without written permission.</p>

      <h2>Project engagements</h2>
      <p>Any services we provide are governed by a separate written proposal or agreement. That agreement will define the scope, deliverables, timeline, fees, payment schedule, and ownership of project materials. If there is a conflict between these terms and a signed agreement, the signed agreement controls.</p>

      <h2>Proposals and estimates</h2>
      <p>Estimates and timelines shared on this website or during early conversations are indicative only. A binding commitment is created only when both parties sign a proposal or agreement and any required deposit is received.</p>

      <h2>Third-party services</h2>
      <p>Our work may rely on third-party platforms, hosting providers, plugins, or APIs. We are not responsible for outages, policy changes, or data practices of third-party providers, though we will make reasonable efforts to help resolve issues that affect your project.</p>

      <h2>Limitation of liability</h2>
      <p>To the maximum extent permitted by law, PixelCraft is not liable for indirect, incidental, or consequential losses arising from your use of this website or our services. Nothing in these terms limits liability that cannot be limited by law.</p>

      <h2>Website availability</h2>
      <p>We aim to keep this website available and accurate, but we do not guarantee uninterrupted access or that all information is complete or current. We may update, suspend, or remove parts of the site at any time.</p>

      <h2>Governing law</h2>
      <p>These terms are governed by the laws of Pakistan. Any dispute relating to this website will be subject to the jurisdiction of the courts of Lahore, unless a separate agreement says otherwise.</p>

      <h2>Contact us</h2>
      <p>If you have questions about these terms, email <a href="mailto:<?= e(setting('site_email')) ?>"><?= e(setting('site_email')) ?></a> or write to <?= e(setting('site_address')) ?>.</p>
    </div>
  </section>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
