/**
 * PixelCraft public website interactions.
 * Vanilla JS only — no build step required.
 */
(function () {
  'use strict';

  var doc = document;
  var csrfMeta = doc.querySelector('meta[name="csrf-token"]');
  var csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function qs(selector, context) {
    return (context || doc).querySelector(selector);
  }

  function qsa(selector, context) {
    return Array.prototype.slice.call((context || doc).querySelectorAll(selector));
  }

  function renderIcons() {
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }
  }

  function setIcon(element, name) {
    if (!element) {
      return;
    }
    element.setAttribute('data-lucide', name);
    element.innerHTML = '';
    renderIcons();
  }

  /* ---------------------------------------------------------
     Toasts
     --------------------------------------------------------- */
  var toastTimer = null;

  function toast(message, type) {
    if (!message) {
      return;
    }

    var existing = qs('.toast');
    if (existing) {
      existing.remove();
    }

    var node = doc.createElement('div');
    node.className = 'toast' + (type === 'error' ? ' toast--error' : '');
    node.setAttribute('role', 'status');
    node.setAttribute('aria-live', 'polite');

    var icon = doc.createElement('i');
    icon.setAttribute('data-lucide', type === 'error' ? 'alert-circle' : 'circle-check');
    var text = doc.createElement('span');
    text.textContent = message;

    node.appendChild(icon);
    node.appendChild(text);
    doc.body.appendChild(node);
    renderIcons();

    requestAnimationFrame(function () {
      node.classList.add('is-visible');
    });

    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      node.classList.remove('is-visible');
      setTimeout(function () {
        node.remove();
      }, 300);
    }, 5200);
  }

  window.PixelCraftToast = toast;

  /* ---------------------------------------------------------
     Sticky header state
     --------------------------------------------------------- */
  var header = qs('#siteHeader');

  function updateHeader() {
    if (!header) {
      return;
    }
    header.classList.toggle('is-scrolled', window.scrollY > 12);
  }

  updateHeader();
  window.addEventListener('scroll', updateHeader, { passive: true });

  /* ---------------------------------------------------------
     Mobile navigation
     --------------------------------------------------------- */
  var navToggle = qs('#navToggle');
  var navMenu = qs('#primaryNav');

  function closeNav() {
    if (!navMenu || !navToggle) {
      return;
    }
    navMenu.classList.remove('is-open');
    navToggle.setAttribute('aria-expanded', 'false');
    navToggle.setAttribute('aria-label', 'Open navigation menu');
    setIcon(qs('svg, i', navToggle) || navToggle.firstElementChild, 'menu');
  }

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', function () {
      var isOpen = navMenu.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
      navToggle.setAttribute('aria-label', isOpen ? 'Close navigation menu' : 'Open navigation menu');
      setIcon(qs('svg, i', navToggle) || navToggle.firstElementChild, isOpen ? 'x' : 'menu');
    });

    qsa('a, button', navMenu).forEach(function (link) {
      link.addEventListener('click', closeNav);
    });

    doc.addEventListener('click', function (event) {
      if (!navMenu.classList.contains('is-open')) {
        return;
      }
      if (!navMenu.contains(event.target) && !navToggle.contains(event.target)) {
        closeNav();
      }
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth > 980) {
        closeNav();
      }
    });
  }

  /* ---------------------------------------------------------
     Contact modal
     --------------------------------------------------------- */
  var modal = qs('#contactModal');
  var lastFocused = null;

  function resetModalForm() {
    if (!modal) {
      return;
    }
    var form = qs('#modalContactForm', modal);
    var success = qs('.form-success', modal);
    var status = qs('#modalFormStatus', modal);
    var submit = qs('#modalSubmit', modal);

    if (success) {
      success.classList.remove('is-visible');
    }
    if (form) {
      form.style.display = '';
    }
    if (status) {
      status.className = 'form-status';
      status.textContent = '';
    }
    if (submit) {
      submit.disabled = false;
      submit.innerHTML = 'Send Message<i data-lucide="send"></i>';
      renderIcons();
    }
  }

  function openModal(trigger) {
    if (!modal) {
      return;
    }
    lastFocused = trigger || doc.activeElement;
    resetModalForm();
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    doc.body.classList.add('no-scroll');

    var firstField = qs('input:not([type="hidden"]), textarea', modal);
    if (firstField) {
      setTimeout(function () {
        firstField.focus();
      }, 160);
    }
  }

  function closeModal() {
    if (!modal) {
      return;
    }
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    doc.body.classList.remove('no-scroll');
    if (lastFocused && typeof lastFocused.focus === 'function') {
      lastFocused.focus();
    }
  }

  qsa('[data-open-modal]').forEach(function (trigger) {
    trigger.addEventListener('click', function (event) {
      event.preventDefault();
      openModal(trigger);
    });
  });

  qsa('[data-close-modal]').forEach(function (trigger) {
    trigger.addEventListener('click', closeModal);
  });

  if (modal) {
    modal.addEventListener('keydown', function (event) {
      if (event.key !== 'Tab') {
        return;
      }

      var focusable = qsa(
        'a[href], button:not([disabled]), input:not([type="hidden"]):not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])',
        modal
      ).filter(function (element) {
        return element.offsetParent !== null;
      });

      if (!focusable.length) {
        return;
      }

      var first = focusable[0];
      var last = focusable[focusable.length - 1];

      if (event.shiftKey && doc.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && doc.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });
  }

  doc.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      if (modal && modal.classList.contains('is-open')) {
        closeModal();
      }
      closeNav();
    }
  });

  /* ---------------------------------------------------------
     Scroll reveal
     --------------------------------------------------------- */
  var revealNodes = qsa('.reveal');

  if (revealNodes.length) {
    if (reduceMotion || !('IntersectionObserver' in window)) {
      revealNodes.forEach(function (node) {
        node.classList.add('is-visible');
      });
    } else {
      var revealObserver = new IntersectionObserver(
        function (entries, observer) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              entry.target.classList.add('is-visible');
              observer.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
      );

      revealNodes.forEach(function (node) {
        revealObserver.observe(node);
      });
    }
  }

  /* ---------------------------------------------------------
     Animated counters
     --------------------------------------------------------- */
  var counters = qsa('[data-counter]');

  function runCounter(node) {
    var target = parseFloat(node.getAttribute('data-counter')) || 0;
    var decimals = parseInt(node.getAttribute('data-decimals') || '0', 10);
    var prefix = node.getAttribute('data-prefix') || '';
    var suffix = node.getAttribute('data-suffix') || '';
    var duration = reduceMotion ? 0 : 1500;
    var start = null;

    function update(value) {
      var formatted = value.toFixed(decimals).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      node.textContent = prefix + formatted + suffix;
    }

    if (!duration) {
      update(target);
      return;
    }

    function step(timestamp) {
      if (start === null) {
        start = timestamp;
      }
      var progress = Math.min((timestamp - start) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 3);
      update(target * eased);
      if (progress < 1) {
        requestAnimationFrame(step);
      }
    }

    requestAnimationFrame(step);
  }

  if (counters.length) {
    if (!('IntersectionObserver' in window)) {
      counters.forEach(runCounter);
    } else {
      var counterObserver = new IntersectionObserver(
        function (entries, observer) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              runCounter(entry.target);
              observer.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.4 }
      );

      counters.forEach(function (node) {
        counterObserver.observe(node);
      });
    }
  }

  /* ---------------------------------------------------------
     Portfolio filtering
     --------------------------------------------------------- */
  var filterBar = qs('[data-filter-bar]');

  if (filterBar) {
    var filterButtons = qsa('[data-filter]', filterBar);
    var projectCards = qsa('[data-category]');
    var resultsLabel = qs('[data-filter-count]');

    function applyFilter(value) {
      var visible = 0;

      filterButtons.forEach(function (btn) {
        var active = btn.getAttribute('data-filter') === value;
        btn.classList.toggle('is-active', active);
        btn.setAttribute('aria-pressed', String(active));
      });

      projectCards.forEach(function (card) {
        var match = value === 'all' || card.getAttribute('data-category') === value;
        card.hidden = !match;
        if (match) {
          visible += 1;
        }
      });

      if (resultsLabel) {
        resultsLabel.textContent = visible + (visible === 1 ? ' project' : ' projects');
      }
    }

    filterButtons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        applyFilter(btn.getAttribute('data-filter'));
      });
    });

    var params = new URLSearchParams(window.location.search);
    var requested = params.get('category');
    if (requested) {
      var matchButton = filterButtons.filter(function (btn) {
        return btn.getAttribute('data-filter') === requested;
      })[0];
      if (matchButton) {
        applyFilter(requested);
      }
    }
  }

  /* ---------------------------------------------------------
     FAQ accordion
     --------------------------------------------------------- */
  qsa('.faq-item').forEach(function (item) {
    var question = qs('.faq-question', item);
    var answer = qs('.faq-answer', item);

    if (!question || !answer) {
      return;
    }

    var expanded = item.classList.contains('is-open');
    question.setAttribute('aria-expanded', String(expanded));
    answer.setAttribute('aria-hidden', String(!expanded));

    question.addEventListener('click', function () {
      var open = item.classList.toggle('is-open');
      question.setAttribute('aria-expanded', String(open));
      answer.setAttribute('aria-hidden', String(!open));
    });
  });

  /* ---------------------------------------------------------
     Contact forms (modal + contact page)
     --------------------------------------------------------- */
  function clearFieldErrors(form) {
    qsa('.form-error', form).forEach(function (node) {
      node.textContent = '';
    });
    qsa('.is-invalid', form).forEach(function (node) {
      node.classList.remove('is-invalid');
    });
    var status = qs('[data-form-status], .form-status', form);
    if (status) {
      status.className = 'form-status';
      status.textContent = '';
    }
  }

  function showFieldError(form, fieldName, message) {
    var field = qs('[name="' + fieldName + '"]', form);
    if (field) {
      field.classList.add('is-invalid');
    }
    var holder = qs('[data-error-for="' + fieldName + '"]', form) || qs('[data-error-for="' + field.id + '"]', form);
    if (holder) {
      holder.textContent = message;
    }
  }

  function showStatus(form, message, type) {
    var status = qs('[data-form-status], .form-status', form);
    if (!status) {
      toast(message, type === 'error' ? 'error' : 'success');
      return;
    }
    status.className = 'form-status is-' + type;
    status.innerHTML = '<i data-lucide="' + (type === 'error' ? 'alert-circle' : 'circle-check') + '"></i><span></span>';
    status.querySelector('span').textContent = message;
    renderIcons();
  }

  function validateContactForm(form) {
    var errors = {};
    var name = form.elements.namedItem('name');
    var email = form.elements.namedItem('email');
    var subject = form.elements.namedItem('subject');
    var message = form.elements.namedItem('message');

    if (!name || !name.value.trim() || name.value.trim().length < 2) {
      errors.name = 'Please enter your name.';
    }
    if (!email || !email.value.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
      errors.email = 'Enter a valid email address.';
    }
    if (subject && !subject.value.trim()) {
      errors.subject = 'Please choose a topic.';
    }
    if (!message || !message.value.trim() || message.value.trim().length < 10) {
      errors.message = 'Please tell us a little more (at least 10 characters).';
    }

    return errors;
  }

  qsa('form.contact-form').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      clearFieldErrors(form);

      var errors = validateContactForm(form);
      if (Object.keys(errors).length) {
        Object.keys(errors).forEach(function (field) {
          showFieldError(form, field, errors[field]);
        });
        var firstInvalid = qs('.is-invalid', form);
        if (firstInvalid) {
          firstInvalid.focus();
        }
        return;
      }

      var submit = qs('[type="submit"]', form);
      var original = submit ? submit.innerHTML : '';
      if (submit) {
        submit.disabled = true;
        submit.innerHTML = 'Sending…';
      }

      var payload = new FormData(form);

      fetch(form.getAttribute('action'), {
        method: 'POST',
        headers: {
          'X-CSRF-Token': csrfToken,
          'X-Requested-With': 'XMLHttpRequest',
          Accept: 'application/json'
        },
        body: payload,
        credentials: 'same-origin'
      })
        .then(function (response) {
          return response.json().catch(function () {
            return { success: false, message: 'Unexpected server response. Please try again.' };
          });
        })
        .then(function (data) {
          if (data.success) {
            if (submit) {
              submit.disabled = false;
              submit.innerHTML = original;
              renderIcons();
            }
            form.reset();

            var panel = form.closest('.modal-panel');
            var success = panel ? qs('.form-success', panel) : qs('[data-form-success]');

            if (success) {
              form.style.display = 'none';
              success.classList.add('is-visible');
              renderIcons();
            } else {
              showStatus(form, data.message || 'Thanks! We will be in touch shortly.', 'success');
            }

            toast(data.message || 'Message sent successfully.');
          } else {
            if (data.errors) {
              Object.keys(data.errors).forEach(function (field) {
                showFieldError(form, field, data.errors[field]);
              });
            }
            showStatus(form, data.message || 'Please check the form and try again.', 'error');
            if (submit) {
              submit.disabled = false;
              submit.innerHTML = original;
              renderIcons();
            }
          }
        })
        .catch(function () {
          showStatus(form, 'Network error. Please check your connection and try again.', 'error');
          if (submit) {
            submit.disabled = false;
            submit.innerHTML = original;
            renderIcons();
          }
        });
    });

    qsa('input, textarea', form).forEach(function (field) {
      field.addEventListener('input', function () {
        field.classList.remove('is-invalid');
        var holder = qs('[data-error-for="' + field.id + '"]', form);
        if (holder) {
          holder.textContent = '';
        }
      });
    });
  });

  /* ---------------------------------------------------------
     Flash auto-dismiss
     --------------------------------------------------------- */
  setTimeout(function () {
    qsa('.site-flash').forEach(function (node) {
      node.style.transition = 'opacity .4s ease, transform .4s ease';
      node.style.opacity = '0';
      node.style.transform = 'translateY(-8px)';
      setTimeout(function () {
        node.remove();
      }, 450);
    });
  }, 5200);

  renderIcons();
})();
