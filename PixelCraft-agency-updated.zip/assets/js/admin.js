'use strict';

(function () {
  const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
  const apiBase = (document.body.dataset.apiBase || '../api').replace(/\/$/, '');
  const colors = {
    blue: '#F2542D',
    violet: '#8B3F6E',
    green: '#2F7D57',
    orange: '#F5C451',
    red: '#D6361F',
    cyan: '#2A7F9E',
    navy: '#0F2A24',
    muted: '#76827B',
    line: '#EEE6D4'
  };

  const currency = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0
  });

  function renderIcons() {
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }
  }

  function toast(message, type = 'success') {
    let element = document.getElementById('adminToast');

    if (!element) {
      element = document.createElement('div');
      element.id = 'adminToast';
      element.className = 'admin-toast';
      element.setAttribute('role', 'status');
      element.setAttribute('aria-live', 'polite');
      document.body.appendChild(element);
    }

    element.className = 'admin-toast' + (type === 'error' ? ' admin-toast--error' : '');
    element.innerHTML = '<i data-lucide="' + (type === 'error' ? 'alert-circle' : 'circle-check') + '"></i><span></span>';
    element.querySelector('span').textContent = message;

    requestAnimationFrame(function () {
      element.classList.add('is-visible');
    });

    window.clearTimeout(element._toastTimer);
    element._toastTimer = window.setTimeout(function () {
      element.classList.remove('is-visible');
    }, 4200);

    renderIcons();
  }

  async function api(url, options = {}) {
    const method = (options.method || 'GET').toUpperCase();
    const headers = Object.assign({ Accept: 'application/json' }, options.headers || {});
    let body = options.body;

    if (method !== 'GET' && method !== 'HEAD') {
      headers['X-CSRF-Token'] = csrfToken;
    }

    if (body && !(body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(body);
    }

    const response = await fetch(url, {
      method: method,
      headers: headers,
      body: body,
      credentials: 'same-origin'
    });

    const contentType = response.headers.get('content-type') || '';
    let payload;

    if (contentType.includes('application/json')) {
      payload = await response.json();
    } else {
      const text = await response.text();
      payload = { success: false, message: text.slice(0, 180) || 'The server returned an unexpected response.' };
    }

    if (response.status === 401) {
      window.location.assign('login.php');
      throw new Error('Authentication required.');
    }

    if (!response.ok || payload.success === false) {
      const error = new Error(payload.message || 'Something went wrong.');
      error.errors = payload.errors || {};
      throw error;
    }

    return payload;
  }

  let lastFocusedElement = null;

  function openModal(modal) {
    if (!modal) {
      return;
    }

    lastFocusedElement = document.activeElement;
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';

    window.setTimeout(function () {
      const firstField = modal.querySelector('input:not([type="hidden"]):not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled])');
      if (firstField) {
        firstField.focus();
      }
    }, 80);
  }

  function closeModal(modal) {
    if (!modal) {
      return;
    }

    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';

    if (lastFocusedElement && typeof lastFocusedElement.focus === 'function') {
      lastFocusedElement.focus();
    }
  }

  function clearErrors(form) {
    if (!form) {
      return;
    }

    form.querySelectorAll('.is-invalid').forEach(function (field) {
      field.classList.remove('is-invalid');
    });

    form.querySelectorAll('[data-error-for]').forEach(function (element) {
      element.textContent = '';
    });
  }

  function showErrors(form, errors) {
    Object.keys(errors || {}).forEach(function (field) {
      const input = form.querySelector('[name="' + field + '"]');
      const message = form.querySelector('[data-error-for="' + field + '"]');

      if (input) {
        input.classList.add('is-invalid');
      }

      if (message) {
        message.textContent = errors[field];
      }
    });
  }

  function resetForm(form) {
    if (!form) {
      return;
    }

    form.reset();
    form.dataset.id = '';
    clearErrors(form);

    const idField = form.querySelector('[name="id"]');
    if (idField) {
      idField.value = '';
    }
  }

  function fillForm(form, record) {
    if (!form || !record) {
      return;
    }

    Array.from(form.elements).forEach(function (field) {
      if (!field.name || field.name === 'id' || field.name === '_token') {
        return;
      }

      const key = field.name.replace(/\[\]$/, '');
      if (!Object.prototype.hasOwnProperty.call(record, key)) {
        return;
      }

      const value = record[key] === null || record[key] === undefined ? '' : record[key];

      if (field.type === 'checkbox') {
        field.checked = value === '1' || value === 1 || value === true;
      } else if (field.type === 'radio') {
        field.checked = String(field.value) === String(value);
      } else {
        field.value = value;
      }
    });
  }

  function setModalTitle(modal, title) {
    const titleElement = modal?.querySelector('[data-modal-title]');
    if (titleElement && title) {
      titleElement.textContent = title;
    }
  }

  function initMobileSidebar() {
    const toggle = document.getElementById('adminMenuToggle');
    const sidebar = document.getElementById('adminSidebar');
    const overlay = document.querySelector('[data-close-sidebar]');

    if (!toggle || !sidebar) {
      return;
    }

    function setSidebar(open) {
      sidebar.classList.toggle('is-open', open);
      overlay?.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    }

    toggle.addEventListener('click', function () {
      setSidebar(!sidebar.classList.contains('is-open'));
    });

    overlay?.addEventListener('click', function () {
      setSidebar(false);
    });

    sidebar.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.innerWidth <= 1180) {
          setSidebar(false);
        }
      });
    });
  }

  function initFlashDismissal() {
    document.querySelectorAll('.admin-flash').forEach(function (flash) {
      window.setTimeout(function () {
        flash.style.transition = 'opacity .3s ease, transform .3s ease';
        flash.style.opacity = '0';
        flash.style.transform = 'translateY(-4px)';
        window.setTimeout(function () {
          flash.remove();
        }, 320);
      }, 6500);
    });
  }

  function initModals() {
    document.addEventListener('click', function (event) {
      const openButton = event.target.closest('[data-modal-open]');

      if (openButton) {
        const modal = document.querySelector(openButton.dataset.modalOpen);
        if (!modal) {
          return;
        }

        if (openButton.hasAttribute('data-modal-reset')) {
          const form = modal.querySelector('form');
          resetForm(form);
          setModalTitle(modal, modal.dataset.addTitle || '');
        }

        openModal(modal);
        return;
      }

      const closeButton = event.target.closest('[data-modal-close]');
      if (closeButton) {
        closeModal(closeButton.closest('.admin-modal'));
        return;
      }

      if (event.target.classList.contains('admin-modal__backdrop')) {
        closeModal(event.target.closest('.admin-modal'));
      }
    });

    document.addEventListener('keydown', function (event) {
      const modal = document.querySelector('.admin-modal.is-open');

      if (!modal) {
        return;
      }

      if (event.key === 'Escape') {
        closeModal(modal);
        return;
      }

      if (event.key !== 'Tab') {
        return;
      }

      const focusable = Array.from(modal.querySelectorAll(
        'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled])'
      )).filter(function (element) {
        return element.offsetParent !== null;
      });

      if (!focusable.length) {
        return;
      }

      const first = focusable[0];
      const last = focusable[focusable.length - 1];

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });
  }

  function initRecordEditing() {
    document.addEventListener('click', async function (event) {
      const editButton = event.target.closest('[data-edit-api]');
      if (!editButton) {
        return;
      }

      event.preventDefault();

      const modal = document.querySelector(editButton.dataset.modalOpen || '#adminEditModal');
      const form = modal?.querySelector('form');
      const id = editButton.dataset.editId;
      const apiUrl = editButton.dataset.editApi;

      if (!modal || !form || !id || !apiUrl) {
        return;
      }

      editButton.disabled = true;

      try {
        const result = await api(apiUrl + (apiUrl.includes('?') ? '&' : '?') + 'id=' + encodeURIComponent(id));
        const record = Array.isArray(result.data) ? result.data[0] : result.data;

        resetForm(form);
        fillForm(form, record);
        form.dataset.id = id;

        const idField = form.querySelector('[name="id"]');
        if (idField) {
          idField.value = id;
        }

        setModalTitle(modal, editButton.dataset.editTitle || 'Edit record');
        openModal(modal);
      } catch (error) {
        toast(error.message, 'error');
      } finally {
        editButton.disabled = false;
      }
    });
  }

  function initRecordFilling() {
    document.addEventListener('click', function (event) {
      const button = event.target.closest('[data-edit-record]');
      if (!button) {
        return;
      }

      const modal = document.querySelector(button.dataset.modalOpen || '#adminEditModal');
      const form = modal?.querySelector('form');

      if (!modal || !form) {
        return;
      }

      let record;
      try {
        record = JSON.parse(button.dataset.editRecord || '{}');
      } catch (error) {
        toast('Could not load this record.', 'error');
        return;
      }

      resetForm(form);
      fillForm(form, record);
      form.dataset.id = record.id || '';

      const idField = form.querySelector('[name="id"]');
      if (idField && record.id) {
        idField.value = record.id;
      }

      setModalTitle(modal, button.dataset.editTitle || 'Edit record');
      openModal(modal);
    });
  }

  function initApiForms() {
    document.querySelectorAll('form[data-api]').forEach(function (form) {
      form.addEventListener('submit', async function (event) {
        event.preventDefault();
        clearErrors(form);

        const payload = {};
        new FormData(form).forEach(function (value, key) {
          payload[key] = value;
        });

        form.querySelectorAll('input[type="checkbox"][name]').forEach(function (checkbox) {
          payload[checkbox.name] = checkbox.checked ? '1' : '0';
        });

        if (form.dataset.id) {
          payload.id = form.dataset.id;
        }

        const method = form.dataset.method || (form.dataset.id ? 'PUT' : 'POST');
        const submitButton = form.querySelector('[type="submit"]');
        const originalLabel = submitButton ? submitButton.innerHTML : '';

        if (submitButton) {
          submitButton.disabled = true;
          submitButton.textContent = 'Saving…';
        }

        try {
          const result = await api(form.dataset.api, { method: method, body: payload });
          toast(result.message || 'Saved successfully.');
          closeModal(form.closest('.admin-modal'));

          window.setTimeout(function () {
            window.location.reload();
          }, 650);
        } catch (error) {
          toast(error.message, 'error');
          showErrors(form, error.errors || {});

          if (submitButton) {
            submitButton.disabled = false;
            submitButton.innerHTML = originalLabel;
          }
        }
      });
    });
  }

  function initDeletes() {
    document.addEventListener('click', async function (event) {
      const button = event.target.closest('[data-delete-api]');
      if (!button) {
        return;
      }

      event.preventDefault();

      if (!window.confirm(button.dataset.confirm || 'Delete this record? This action cannot be undone.')) {
        return;
      }

      const apiUrl = button.dataset.deleteApi;
      const id = button.dataset.deleteId;

      if (!apiUrl || !id) {
        return;
      }

      button.disabled = true;

      try {
        const result = await api(apiUrl, { method: 'DELETE', body: { id: id } });
        toast(result.message || 'Deleted successfully.');

        const row = button.closest('tr') || button.closest('[data-message-row]') || button.closest('.admin-team-card');
        if (row) {
          row.style.transition = 'opacity .25s ease';
          row.style.opacity = '0';
        }

        window.setTimeout(function () {
          window.location.reload();
        }, 550);
      } catch (error) {
        button.disabled = false;
        toast(error.message, 'error');
      }
    });
  }

  function adjustUnreadBadges(delta) {
    document.querySelectorAll('.admin-nav__badge, .admin-icon-btn__badge').forEach(function (badge) {
      const current = parseInt(badge.textContent, 10) || 0;
      const next = Math.max(0, current + delta);

      if (next === 0) {
        badge.remove();
      } else {
        badge.textContent = String(next);
      }
    });
  }

  function setMessageRowState(id, isRead) {
    const row = document.querySelector('[data-message-row="' + id + '"]');
    if (!row) {
      return;
    }

    row.classList.toggle('is-unread', !isRead);
    row.querySelectorAll('[data-message-unread]').forEach(function (badge) {
      badge.remove();
    });

    const status = row.querySelector('[data-message-status]');
    if (status) {
      status.textContent = isRead ? 'Read' : 'Unread';
    }
  }

  function initMessages() {
    document.addEventListener('click', async function (event) {
      const viewButton = event.target.closest('[data-message-view]');
      const toggleButton = event.target.closest('[data-message-toggle]');

      if (viewButton) {
        const modal = document.querySelector(viewButton.dataset.modalOpen || '#messageModal');
        const apiUrl = viewButton.dataset.messageApi;

        if (!modal || !apiUrl) {
          return;
        }

        try {
          const result = await api(apiUrl + '?id=' + encodeURIComponent(viewButton.dataset.messageId));
          const message = result.data;

          modal.querySelectorAll('[data-message-field]').forEach(function (element) {
            const value = message[element.dataset.messageField] ?? '';
            element.textContent = value;
          });

          const reply = modal.querySelector('[data-message-reply]');
          if (reply) {
            reply.href = 'mailto:' + encodeURIComponent(message.email) + '?subject=' +
              encodeURIComponent('Re: ' + message.subject);
          }

          openModal(modal);

          if (!Number(message.is_read)) {
            await api(apiUrl, { method: 'PUT', body: { id: message.id, is_read: 1 } });
            setMessageRowState(message.id, true);
            adjustUnreadBadges(-1);
            message.is_read = 1;
          }
        } catch (error) {
          toast(error.message, 'error');
        }

        return;
      }

      if (toggleButton) {
        const apiUrl = toggleButton.dataset.messageApi;
        const id = toggleButton.dataset.messageId;
        const markRead = toggleButton.dataset.markRead === '1';

        if (!apiUrl || !id) {
          return;
        }

        toggleButton.disabled = true;

        try {
          const result = await api(apiUrl, { method: 'PUT', body: { id: id, is_read: markRead ? 1 : 0 } });
          setMessageRowState(id, markRead);
          adjustUnreadBadges(markRead ? -1 : 1);
          toast(result.message || 'Message updated.');
        } catch (error) {
          toast(error.message, 'error');
        } finally {
          toggleButton.disabled = false;
        }
      }
    });
  }

  function initAutoSubmit() {
    document.querySelectorAll('[data-auto-submit]').forEach(function (field) {
      field.addEventListener('change', function () {
        field.form?.submit();
      });
    });
  }

  let statsPromise = null;

  function getStats() {
    if (!statsPromise) {
      statsPromise = api(apiBase + '/stats.php').then(function (result) {
        return result.data;
      });
    }

    return statsPromise;
  }

  function chartFont() {
    return {
      family: "'Inter', system-ui, sans-serif",
      size: 10
    };
  }

  function baseScales(currencyAxis) {
    return {
      x: {
        grid: { display: false },
        ticks: { color: colors.muted, font: chartFont() },
        border: { display: false }
      },
      y: {
        beginAtZero: true,
        grid: { color: colors.line },
        border: { display: false },
        ticks: {
          color: colors.muted,
          font: chartFont(),
          callback: currencyAxis ? function (value) { return currency.format(value); } : undefined
        }
      }
    };
  }

  function createRevenueChart(canvas, labels, values) {
    if (!canvas || !window.Chart) {
      return;
    }

    const context = canvas.getContext('2d');
    const gradient = context.createLinearGradient(0, 0, 0, 290);
    gradient.addColorStop(0, 'rgba(47, 91, 234, .24)');
    gradient.addColorStop(1, 'rgba(47, 91, 234, 0)');

    new window.Chart(canvas, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Revenue',
          data: values,
          borderColor: colors.blue,
          backgroundColor: gradient,
          fill: true,
          tension: 0.38,
          borderWidth: 2.2,
          pointRadius: 0,
          pointHoverRadius: 4,
          pointHoverBackgroundColor: colors.blue
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { intersect: false, mode: 'index' },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: colors.navy,
            padding: 10,
            cornerRadius: 8,
            displayColors: false,
            callbacks: {
              label: function (context) {
                return currency.format(context.parsed.y);
              }
            }
          }
        },
        scales: baseScales(true)
      }
    });
  }

  function createVisitorsChart(canvas, labels, visitors, pageviews) {
    if (!canvas || !window.Chart) {
      return;
    }

    new window.Chart(canvas, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Visitors',
            data: visitors,
            backgroundColor: colors.blue,
            borderRadius: 5,
            maxBarThickness: 18
          },
          {
            label: 'Pageviews',
            data: pageviews,
            backgroundColor: '#C9D6FF',
            borderRadius: 5,
            maxBarThickness: 18
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            align: 'end',
            labels: {
              boxWidth: 7,
              boxHeight: 7,
              usePointStyle: true,
              color: colors.muted,
              font: chartFont()
            }
          }
        },
        scales: baseScales(false)
      }
    });
  }

  function createDoughnutChart(canvas, labels, values, palette) {
    if (!canvas || !window.Chart) {
      return;
    }

    new window.Chart(canvas, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [{
          data: values,
          backgroundColor: palette,
          borderWidth: 0,
          hoverOffset: 5
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: 7,
              boxHeight: 7,
              usePointStyle: true,
              color: colors.muted,
              padding: 13,
              font: chartFont()
            }
          }
        }
      }
    });
  }

  async function initCharts() {
    const dashboardRevenue = document.getElementById('dashboardRevenueChart');
    const dashboardStatus = document.getElementById('dashboardStatusChart');
    const analyticsVisitors = document.getElementById('analyticsVisitorsChart');
    const analyticsRevenue = document.getElementById('analyticsRevenueChart');
    const analyticsCategory = document.getElementById('analyticsCategoryChart');

    if (!dashboardRevenue && !dashboardStatus && !analyticsVisitors && !analyticsRevenue && !analyticsCategory) {
      return;
    }

    if (!window.Chart) {
      return;
    }

    window.Chart.defaults.font.family = "'Inter', system-ui, sans-serif";
    window.Chart.defaults.color = colors.muted;

    try {
      const stats = await getStats();
      const labels = stats.monthly.map(function (month) { return month.month; });
      const revenue = stats.monthly.map(function (month) { return month.revenue; });
      const visitors = stats.monthly.map(function (month) { return month.visitors; });
      const pageviews = stats.monthly.map(function (month) { return month.pageviews; });

      if (dashboardRevenue) {
        createRevenueChart(dashboardRevenue, labels, revenue);
      }

      if (dashboardStatus) {
        const statusLabels = Object.keys(stats.projects_by_status).filter(function (key) {
          return stats.projects_by_status[key] > 0;
        });
        const statusValues = statusLabels.map(function (key) {
          return stats.projects_by_status[key];
        });
        createDoughnutChart(
          dashboardStatus,
          statusLabels,
          statusValues,
          [colors.green, colors.blue, colors.orange, colors.violet, colors.red]
        );
      }

      if (analyticsVisitors) {
        createVisitorsChart(analyticsVisitors, labels, visitors, pageviews);
      }

      if (analyticsRevenue) {
        createRevenueChart(analyticsRevenue, labels, revenue);
      }

      if (analyticsCategory) {
        createDoughnutChart(
          analyticsCategory,
          stats.categories.map(function (item) { return item.category; }),
          stats.categories.map(function (item) { return item.total; }),
          [colors.blue, colors.violet, colors.cyan, colors.orange, colors.green, colors.red]
        );
      }
    } catch (error) {
      toast(error.message || 'Could not load analytics.', 'error');
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    renderIcons();
    initMobileSidebar();
    initFlashDismissal();
    initModals();
    initRecordEditing();
    initRecordFilling();
    initApiForms();
    initDeletes();
    initMessages();
    initAutoSubmit();
    initCharts();
  });
})();
