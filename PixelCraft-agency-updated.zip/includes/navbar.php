<?php
/**
 * Shared public navbar.
 * $activePage is set by each page before including header.php.
 */

$siteSettings = site_settings();
$activePage = $activePage ?? '';
$navItems = [
    'home' => ['label' => 'Overview', 'href' => 'index.php', 'icon' => 'layout-dashboard'],
    'about' => ['label' => 'About', 'href' => 'about.php', 'icon' => 'users'],
    'services' => ['label' => 'Services', 'href' => 'services.php', 'icon' => 'layers'],
    'portfolio' => ['label' => 'Portfolio', 'href' => 'portfolio.php', 'icon' => 'folder-kanban'],
    'blog' => ['label' => 'Blog', 'href' => 'blog.php', 'icon' => 'newspaper'],
    'contact' => ['label' => 'Contact', 'href' => 'contact.php', 'icon' => 'mail'],
];
?>
<header class="site-header" id="siteHeader">
  <div class="container navbar">
    <a class="brand" href="<?= e(url('index.php')) ?>" aria-label="<?= e($siteSettings['site_name']) ?> home">
      <span class="brand-mark">
        <img src="<?= e(ASSETS_URL) ?>/img/logo-mark.svg" alt="" width="40" height="40">
      </span>
      <span class="brand-text">
        <span class="brand-name"><?= e($siteSettings['site_name']) ?></span>
        <span class="brand-tagline"><?= e($siteSettings['site_tagline']) ?></span>
      </span>
    </a>

    <nav class="nav-menu" id="primaryNav" aria-label="Primary navigation">
      <span class="nav-label">Menu</span>
      <?php foreach ($navItems as $key => $item): ?>
        <a class="nav-link<?= $activePage === $key ? ' is-active' : '' ?>" href="<?= e(url($item['href'])) ?>"<?= $activePage === $key ? ' aria-current="page"' : '' ?>>
          <i data-lucide="<?= e($item['icon']) ?>"></i>
          <span><?= e($item['label']) ?></span>
        </a>
      <?php endforeach; ?>
      <div class="nav-status">
        <span class="nav-status__dot"></span>
        <div><strong>Open for projects</strong><small>Replies within 1 business day</small></div>
      </div>
      <button class="btn btn-primary nav-cta-mobile" type="button" data-open-modal>Get Started</button>
    </nav>

    <div class="nav-actions">
      <a class="btn btn-outline btn-sm nav-admin-link" href="<?= e(url('admin/login.php')) ?>"><i data-lucide="lock-keyhole"></i> Admin login</a>
      <button class="btn btn-primary nav-cta-desktop" type="button" data-open-modal>
        Get Started
        <i data-lucide="arrow-up-right"></i>
      </button>
      <button class="nav-toggle" id="navToggle" type="button" aria-label="Open navigation menu" aria-expanded="false" aria-controls="primaryNav">
        <i data-lucide="menu"></i>
      </button>
    </div>
  </div>
</header>
