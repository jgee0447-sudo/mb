<?php
/**
 * Shared public footer, contact modal, and front-end scripts.
 */

$siteSettings = site_settings();
$footerServices = featured_services(6);
?>
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <a class="brand" href="<?= e(url('index.php')) ?>" aria-label="<?= e($siteSettings['site_name']) ?> home">
          <span class="brand-mark">
            <img src="<?= e(ASSETS_URL) ?>/img/logo-mark.svg" alt="" width="40" height="40">
          </span>
          <span class="brand-text">
            <span class="brand-name"><?= e($siteSettings['site_name']) ?></span>
            <span class="brand-tagline"><?= e($siteSettings['site_tagline']) ?></span>
          </span>
        </a>
        <p><?= e($siteSettings['social_note'] ?: "Creative solutions for modern businesses. Let's build your digital future together.") ?></p>
        <div class="social-links">
          <?php if (!empty($siteSettings['facebook_url'])): ?>
            <a href="<?= e($siteSettings['facebook_url']) ?>" aria-label="Facebook" target="_blank" rel="noopener"><i data-lucide="facebook"></i></a>
          <?php endif; ?>
          <?php if (!empty($siteSettings['instagram_url'])): ?>
            <a href="<?= e($siteSettings['instagram_url']) ?>" aria-label="Instagram" target="_blank" rel="noopener"><i data-lucide="instagram"></i></a>
          <?php endif; ?>
          <?php if (!empty($siteSettings['linkedin_url'])): ?>
            <a href="<?= e($siteSettings['linkedin_url']) ?>" aria-label="LinkedIn" target="_blank" rel="noopener"><i data-lucide="linkedin"></i></a>
          <?php endif; ?>
          <?php if (!empty($siteSettings['twitter_url'])): ?>
            <a href="<?= e($siteSettings['twitter_url']) ?>" aria-label="Twitter" target="_blank" rel="noopener"><i data-lucide="twitter"></i></a>
          <?php endif; ?>
        </div>
      </div>

      <div class="footer-column">
        <h3>Quick Links</h3>
        <ul class="footer-links">
          <li><a href="<?= e(url('index.php')) ?>">Home</a></li>
          <li><a href="<?= e(url('about.php')) ?>">About</a></li>
          <li><a href="<?= e(url('services.php')) ?>">Services</a></li>
          <li><a href="<?= e(url('portfolio.php')) ?>">Portfolio</a></li>
          <li><a href="<?= e(url('blog.php')) ?>">Blog</a></li>
          <li><a href="<?= e(url('contact.php')) ?>">Contact</a></li>
        </ul>
      </div>

      <div class="footer-column">
        <h3>Our Services</h3>
        <ul class="footer-links">
          <?php foreach ($footerServices as $service): ?>
            <li><a href="<?= e(url('services.php#' . $service['slug'])) ?>"><?= e($service['title']) ?></a></li>
          <?php endforeach; ?>
        </ul>
      </div>

      <div class="footer-column">
        <h3>Contact Us</h3>
        <ul class="footer-contact">
          <li><i data-lucide="phone"></i><a href="tel:<?= e(preg_replace('/[^0-9+]/', '', $siteSettings['site_phone'])) ?>"><?= e($siteSettings['site_phone']) ?></a></li>
          <li><i data-lucide="mail"></i><a href="mailto:<?= e($siteSettings['site_email']) ?>"><?= e($siteSettings['site_email']) ?></a></li>
          <li><i data-lucide="map-pin"></i><span><?= e($siteSettings['site_address']) ?></span></li>
        </ul>
      </div>
    </div>

    <div class="nx-bigword" aria-hidden="true">PixelCraft</div>
    <div class="footer-bottom">
      <span>&copy; <?= date('Y') ?> <?= e($siteSettings['site_name']) ?> Digital Agency. All rights reserved.</span>
      <div class="footer-legal">
        <a href="<?= e(url('privacy.php')) ?>">Privacy Policy</a>
        <a href="<?= e(url('terms.php')) ?>">Terms of Service</a>
      </div>
    </div>
  </div>
</footer>

<?php include __DIR__ . '/modal.php'; ?>

<script src="https://unpkg.com/lucide@latest"></script>
<script src="<?= e(ASSETS_URL) ?>/js/script.js"></script>
</body>
</html>
