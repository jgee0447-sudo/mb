<?php
/**
 * Shared public document head, meta tags, and opening body markup.
 *
 * Pages set these variables before including this file:
 * $pageTitle, $pageDescription, $activePage, $bodyClass, $ogImage.
 */

if (!defined('APP_ROOT')) {
    require_once __DIR__ . '/../config/config.php';
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/functions.php';

$siteSettings = site_settings();
$pageTitle = $pageTitle ?? 'Creative Digital Agency';
$pageDescription = $pageDescription ?? 'PixelCraft is a creative digital agency building websites, brands, and digital experiences that grow modern businesses.';
$activePage = $activePage ?? '';
$bodyClass = $bodyClass ?? '';
$ogImage = og_image($ogImage ?? '');
$fullTitle = $pageTitle . ' | ' . $siteSettings['site_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($fullTitle) ?></title>
  <meta name="description" content="<?= e($pageDescription) ?>">
  <meta name="theme-color" content="#F2542D">
  <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
  <link rel="canonical" href="<?= e(url(ltrim($_SERVER['REQUEST_URI'] ?? '', '/'))) ?>">

  <!-- Open Graph / social sharing -->
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="<?= e($siteSettings['site_name']) ?>">
  <meta property="og:title" content="<?= e($fullTitle) ?>">
  <meta property="og:description" content="<?= e($pageDescription) ?>">
  <meta property="og:image" content="<?= e($ogImage) ?>">
  <meta property="og:url" content="<?= e(url(ltrim($_SERVER['REQUEST_URI'] ?? '', '/'))) ?>">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?= e($fullTitle) ?>">
  <meta name="twitter:description" content="<?= e($pageDescription) ?>">
  <meta name="twitter:image" content="<?= e($ogImage) ?>">

  <link rel="icon" type="image/svg+xml" href="<?= e(ASSETS_URL) ?>/img/logo-mark.svg">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,600;9..144,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(ASSETS_URL) ?>/css/style.css">
  <link rel="stylesheet" href="<?= e(ASSETS_URL) ?>/css/public-dashboard.css">
</head>
<body class="<?= e($bodyClass) ?>">
  <a class="skip-link" href="#mainContent">Skip to main content</a>

  <?php include __DIR__ . '/navbar.php'; ?>

  <div class="pc-topbar">
    <div class="pc-topbar__title">
      <span><?= e(date('l, F j')) ?></span>
      <strong><?= e($activePage === 'home' ? 'Studio overview' : $pageTitle) ?></strong>
    </div>
    <div class="pc-topbar__actions">
      <a class="pc-chip" href="<?= e(url('portfolio.php')) ?>"><i data-lucide="folder-kanban"></i> Our work</a>
      <a class="pc-chip" href="<?= e(url('contact.php')) ?>"><i data-lucide="phone"></i> Contact</a>
      <button class="btn btn-primary btn-sm" type="button" data-open-modal>Start a project <i data-lucide="arrow-up-right"></i></button>
    </div>
  </div>

  <?php
  $flashes = take_flashes();
  if ($flashes):
  ?>
    <div class="site-flashes" aria-live="polite">
      <?php foreach ($flashes as $flash): ?>
        <div class="site-flash site-flash--<?= e($flash['type']) ?>">
          <i data-lucide="<?= $flash['type'] === 'success' ? 'circle-check' : 'info' ?>"></i>
          <span><?= e($flash['message']) ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
