<?php
/**
 * Shared data helpers used by public pages and admin pages.
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';

/**
 * Load all settings once, with safe defaults.
 */
function site_settings(): array
{
    static $settings = null;

    if ($settings !== null) {
        return $settings;
    }

    $defaults = [
        'site_name' => 'PixelCraft',
        'site_tagline' => 'Digital Agency',
        'site_email' => 'hello@pixelcraft.agency',
        'site_phone' => '+92 300 123 4567',
        'site_address' => '4th Floor, Creative Hub, Gulberg III, Lahore, Pakistan',
        'working_hours' => 'Mon – Fri, 9:00 AM – 6:00 PM',
        'facebook_url' => 'https://facebook.com',
        'instagram_url' => 'https://instagram.com',
        'linkedin_url' => 'https://linkedin.com',
        'twitter_url' => 'https://twitter.com',
        'social_note' => '',
        'map_embed' => 'https://www.google.com/maps?q=Gulberg%20III%20Lahore&output=embed',
    ];

    try {
        $rows = db()->query('SELECT setting_key, setting_value FROM settings')->fetchAll();
        foreach ($rows as $row) {
            $defaults[$row['setting_key']] = $row['setting_value'];
        }
    } catch (Throwable $exception) {
        error_log('Could not load settings: ' . $exception->getMessage());
    }

    $settings = $defaults;
    return $settings;
}

/** Get a single setting with a fallback. */
function setting(string $key, string $default = ''): string
{
    $settings = site_settings();
    return $settings[$key] ?? $default;
}

/** Format a date from the database for display. */
function format_date(?string $date, string $format = 'M j, Y'): string
{
    if (!$date) {
        return '—';
    }

    $timestamp = strtotime($date);
    return $timestamp ? date($format, $timestamp) : '—';
}

/** Map a project status to a CSS-friendly slug. */
function status_slug(string $status): string
{
    return strtolower(str_replace(' ', '-', $status));
}

/** Truncate text without breaking HTML words. */
function excerpt(string $text, int $limit = 150): string
{
    $plain = trim(strip_tags($text));
    if (mb_strlen($plain) <= $limit) {
        return $plain;
    }

    return rtrim(mb_substr($plain, 0, $limit)) . '…';
}

/** Record an admin activity entry. */
function log_activity(string $action, ?string $entityType = null, ?int $entityId = null): void
{
    try {
        $statement = db()->prepare(
            'INSERT INTO activity_log (admin_id, action, entity_type, entity_id, created_at)
             VALUES (:admin_id, :action, :entity_type, :entity_id, NOW())'
        );
        $statement->execute([
            'admin_id' => current_admin_id(),
            'action' => $action,
            'entity_type' => $entityType,
            'entity_id' => $entityId,
        ]);
    } catch (Throwable $exception) {
        error_log('Activity log failed: ' . $exception->getMessage());
    }
}

/** Fetch featured testimonials for public pages. */
function featured_testimonials(int $limit = 3): array
{
    $statement = db()->prepare(
        'SELECT * FROM testimonials WHERE is_featured = 1 ORDER BY created_at DESC LIMIT :limit'
    );
    $statement->bindValue(':limit', $limit, PDO::PARAM_INT);
    $statement->execute();

    return $statement->fetchAll();
}

/** Fetch team members for the public About page. */
function team_members(): array
{
    return db()->query('SELECT * FROM team ORDER BY created_at ASC')->fetchAll();
}

/** Fetch featured services. */
function featured_services(int $limit = 6): array
{
    $statement = db()->prepare(
        'SELECT * FROM services WHERE is_featured = 1 ORDER BY sort_order ASC, title ASC LIMIT :limit'
    );
    $statement->bindValue(':limit', $limit, PDO::PARAM_INT);
    $statement->execute();

    return $statement->fetchAll();
}

/** Fetch featured projects for public pages. */
function featured_projects(int $limit = 6): array
{
    $statement = db()->prepare(
        'SELECT p.*, c.name AS client_name
         FROM projects p
         LEFT JOIN clients c ON c.id = p.client_id
         WHERE p.featured = 1
         ORDER BY p.created_at DESC
         LIMIT :limit'
    );
    $statement->bindValue(':limit', $limit, PDO::PARAM_INT);
    $statement->execute();

    return $statement->fetchAll();
}

/** Public project categories used by filters and dropdowns. */
function project_categories(): array
{
    return ['E-Commerce', 'Branding', 'Mobile App', 'Marketing', 'Corporate', 'Social Media'];
}

/**
 * Resolve an image reference to a URL the browser can load.
 * Absolute URLs pass through; relative paths such as
 * "assets/img/projects/project-01.svg" are resolved against the site root.
 */
function img_src(?string $path): string
{
    $path = trim((string) $path);

    if ($path === '') {
        return '';
    }

    if (preg_match('#^(https?:)?//#i', $path) || str_starts_with($path, 'data:')) {
        return $path;
    }

    return url(ltrim($path, '/'));
}

/** Social sharing needs a raster image, so SVG artwork falls back to the PNG cover. */
function og_image(?string $path): string
{
    $path = trim((string) $path);

    if ($path === '' || preg_match('/\.svg(\?.*)?$/i', $path)) {
        return url('assets/img/og-cover.png');
    }

    return img_src($path);
}

/** True for an absolute http(s) URL or a local "assets/..." image path. */
function valid_image_ref(string $value): bool
{
    if (filter_var($value, FILTER_VALIDATE_URL)) {
        return true;
    }

    return (bool) preg_match('#^assets/[A-Za-z0-9_./-]+\.(svg|png|jpe?g|webp|gif)$#i', $value);
}

/** Build one or two initials from a person's name. */
function name_initials(?string $name): string
{
    $parts = preg_split('/\s+/', trim((string) $name)) ?: [];
    $initials = '';

    foreach (array_slice($parts, 0, 2) as $part) {
        $initials .= mb_strtoupper(mb_substr($part, 0, 1));
    }

    return $initials !== '' ? $initials : 'PC';
}
