<?php
/**
 * Global "Get Started" contact modal.
 * Uses api/contact.php and the shared CSRF token.
 */
?>
<div class="modal" id="contactModal" role="dialog" aria-modal="true" aria-labelledby="contactModalTitle" aria-hidden="true">
  <div class="modal-backdrop" data-close-modal></div>
  <div class="modal-panel">
    <button class="modal-close" type="button" aria-label="Close contact form" data-close-modal>
      <i data-lucide="x"></i>
    </button>

    <span class="eyebrow">Let's Talk</span>
    <h2 id="contactModalTitle">Start Your Project</h2>
    <p>Share a little about what you have in mind and we will get back to you within one business day.</p>

    <form class="contact-form" id="modalContactForm" action="<?= e(url('api/contact.php')) ?>" method="post" novalidate>
      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
      <div class="honeypot" aria-hidden="true">
        <label for="modalWebsite">Website</label>
        <input type="text" id="modalWebsite" name="website" tabindex="-1" autocomplete="off">
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="modalName">Your name</label>
          <input class="form-control" type="text" id="modalName" name="name" placeholder="Jane Cooper" autocomplete="name" required>
          <span class="form-error" data-error-for="modalName"></span>
        </div>
        <div class="form-group">
          <label for="modalEmail">Email address</label>
          <input class="form-control" type="email" id="modalEmail" name="email" placeholder="jane@company.com" autocomplete="email" required>
          <span class="form-error" data-error-for="modalEmail"></span>
        </div>
      </div>

      <div class="form-group">
        <label for="modalPhone">Phone <span class="optional">(optional)</span></label>
        <input class="form-control" type="tel" id="modalPhone" name="phone" placeholder="+92 300 123 4567" autocomplete="tel">
        <span class="form-error" data-error-for="modalPhone"></span>
      </div>

      <div class="form-group">
        <label for="modalMessage">Tell us about your project</label>
        <textarea class="form-control" id="modalMessage" name="message" placeholder="A few words about your goals, timeline, and budget..." required></textarea>
        <span class="form-error" data-error-for="modalMessage"></span>
      </div>

      <div class="form-status" id="modalFormStatus" role="status" aria-live="polite"></div>

      <button class="btn btn-primary" type="submit" id="modalSubmit">
        Send Message
        <i data-lucide="send"></i>
      </button>
    </form>

    <div class="form-success" id="modalFormSuccess" role="status" aria-live="polite">
      <span class="success-icon"><i data-lucide="check"></i></span>
      <h3>Message Sent!</h3>
      <p>Thanks for reaching out. Our team will be in touch shortly.</p>
      <button class="btn btn-outline btn-sm" type="button" data-close-modal>Close</button>
    </div>
  </div>
</div>
