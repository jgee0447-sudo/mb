<?php
/**
 * PixelCraft application configuration.
 *
 * This file is loaded by every public page, admin page, and API endpoint.
 * Database credentials live in config/db.php so they can be edited separately.
 */

declare(strict_types=1);

/* ---------------------------------------------------------
   Error reporting
   Set display_errors to false in production.
   --------------------------------------------------------- */
ini_set('display_errors', '1');
error_reporting(E_ALL);

/* ---------------------------------------------------------
   Application constants
   --------------------------------------------------------- */
define('APP_NAME', 'PixelCraft');
define('APP_ROOT', dirname(__DIR__));

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['SERVER_PORT'] ?? '') === '443');

$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$documentRoot = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '');
$applicationRoot = str_replace('\\', '/', realpath(APP_ROOT) ?: '');

$basePath = '';
if ($documentRoot !== '' && str_starts_with($applicationRoot, $documentRoot)) {
    $basePath = rtrim(substr($applicationRoot, strlen($documentRoot)), '/');
}

define('BASE_URL', ($isHttps ? 'https' : 'http') . '://' . $host . $basePath);
define('ASSETS_URL', BASE_URL . '/assets');

/* ---------------------------------------------------------
   Secure session configuration
   --------------------------------------------------------- */
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');

    session_name('pixelcraft_session');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    session_start();
}

/* ---------------------------------------------------------
   General helpers
   --------------------------------------------------------- */

/** Escape text for safe HTML output. */
function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Build an absolute application URL. */
function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

/** Redirect and stop execution. */
function redirect(string $path): never
{
    header('Location: ' . (str_starts_with($path, 'http') ? $path : url($path)));
    exit;
}

/** Create (or reuse) the session CSRF token. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

/** Render a hidden CSRF field. */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

/**
 * Validate a CSRF token from POST data or the X-CSRF-Token header.
 * API requests use the header; regular forms use the hidden field.
 */
function verify_csrf(?string $token = null): bool
{
    $submitted = $token
        ?? $_POST['csrf_token']
        ?? $_SERVER['HTTP_X_CSRF_TOKEN']
        ?? '';

    return is_string($submitted)
        && $submitted !== ''
        && isset($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $submitted);
}

/** Store a one-time flash message. */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

/** Read and clear flash messages. */
function take_flashes(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);

    return $messages;
}

/** Check whether an administrator is signed in. */
function is_logged_in(): bool
{
    return !empty($_SESSION['admin_id']);
}

/** Return the signed-in administrator's ID. */
function current_admin_id(): ?int
{
    return isset($_SESSION['admin_id']) ? (int) $_SESSION['admin_id'] : null;
}

/** Trim and strip tags from a submitted string. */
function clean_input(?string $value): string
{
    return trim(strip_tags((string) $value));
}

/** Send a JSON response and stop. */
function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** Determine whether the current request expects JSON. */
function wants_json(): bool
{
    $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
    $requestedWith = $_SERVER['HTTP_X_REQUESTED_WITH'] ?? '';

    return str_contains($accept, 'application/json')
        || strtolower($requestedWith) === 'xmlhttprequest'
        || str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json');
}

/** Read a JSON request body as an associative array. */
function json_input(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw ?: '[]', true);

    return is_array($decoded) ? $decoded : [];
}
