<?php
/**
 * PDO database connection.
 * Edit the four constants below to match your local environment.
 */

declare(strict_types=1);

require_once __DIR__ . '/config.php';

define('DB_HOST', getenv('PIXELCRAFT_DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('PIXELCRAFT_DB_PORT') ?: '3306');
define('DB_NAME', getenv('PIXELCRAFT_DB_NAME') ?: 'pixelcraft');
define('DB_USER', getenv('PIXELCRAFT_DB_USER') ?: 'root');
define('DB_PASS', getenv('PIXELCRAFT_DB_PASS') ?: '');

/**
 * Return a shared PDO instance.
 * Prepared statements are used throughout the application.
 */
function db(): PDO
{
    static $connection = null;

    if ($connection instanceof PDO) {
        return $connection;
    }

    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
        DB_HOST,
        DB_PORT,
        DB_NAME
    );

    try {
        $connection = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false,
        ]);
    } catch (PDOException $exception) {
        error_log('PixelCraft database connection failed: ' . $exception->getMessage());

        if (wants_json()) {
            json_response([
                'success' => false,
                'message' => 'The database is unavailable. Please try again later.',
            ], 500);
        }

        http_response_code(500);
        exit(
            '<div style="font-family:Inter,Arial,sans-serif;max-width:680px;margin:12vh auto;padding:32px;'
            . 'border:1px solid #e3e9f5;border-radius:16px;background:#fff;color:#0f1b3d;">'
            . '<h1 style="font-family:Poppins,Arial,sans-serif;margin-top:0;">Database connection needed</h1>'
            . '<p>The PixelCraft database could not be reached. Start MySQL in XAMPP, then import '
            . '<code>database/schema.sql</code> and <code>database/seed.sql</code>.</p>'
            . '<p style="color:#707b98;">Check the credentials in <code>config/db.php</code> if the problem continues.</p>'
            . '</div>'
        );
    }

    return $connection;
}
