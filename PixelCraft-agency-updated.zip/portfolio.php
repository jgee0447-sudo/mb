<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Portfolio';
$pageDescription = 'Browse PixelCraft case studies across e-commerce, branding, mobile apps, corporate websites, marketing, and social media.';
$activePage = 'portfolio';

$projects = db()->query(
    'SELECT p.*, c.name AS client_name, c.company AS client_company
     FROM projects p
     LEFT JOIN clients c ON c.id = p.client_id
     ORDER BY p.featured DESC, p.created_at DESC'
)->fetchAll();

$categories = [];
foreach ($projects as $project) {
    if (!in_array($project['category'], $categories, true)) {
        $categories[] = $project['category'];
    }
}
sort($categories);

require __DIR__ . '/includes/header.php';
?>
<main id="mainContent">

  <section class="page-hero">
    <div class="container">
      <div class="page-hero__inner reveal">
        <nav class="breadcrumbs" aria-label="Breadcrumb">
          <a href="<?= e(url('index.php')) ?>">Home</a>
          <i data-lucide="chevron-right"></i>
          <span aria-current="page">Portfolio</span>
        </nav>
        <span class="eyebrow">Selected Work</span>
        <h1>Work that looks good and performs even better.</h1>
        <p>Websites, identities, products, and campaigns built for real business outcomes. Filter by discipline or browse the full collection.</p>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="blog-tools">
        <div class="filter-bar" data-filter-bar>
          <button class="filter-btn is-active" type="button" data-filter="all" aria-pressed="true">All Work</button>
          <?php foreach ($categories as $category): ?>
            <button class="filter-btn" type="button" data-filter="<?= e($category) ?>" aria-pressed="false"><?= e($category) ?></button>
          <?php endforeach; ?>
        </div>
        <span class="blog-meta" data-filter-count><?= count($projects) ?> projects</span>
      </div>

      <div class="portfolio-grid">
        <?php foreach ($projects as $index => $project): ?>
          <a class="project-card reveal delay-<?= (int) (($index % 3) + 1) ?>" href="<?= e(url('project-single.php?id=' . (int) $project['id'])) ?>" data-category="<?= e($project['category']) ?>">
            <div class="project-media">
              <img src="<?= e(img_src($project['image_url'])) ?>" alt="<?= e($project['name']) ?>" loading="lazy">
              <span class="project-category"><?= e($project['category']) ?></span>
              <span class="project-open"><i data-lucide="arrow-up-right"></i></span>
            </div>
            <div class="project-content">
              <div>
                <h3><?= e($project['name']) ?></h3>
                <p><?= e($project['client_company'] ?: $project['client_name'] ?: 'PixelCraft Studio') ?> &middot; <?= e($project['status']) ?></p>
              </div>
              <i data-lucide="arrow-up-right"></i>
            </div>
          </a>
        <?php endforeach; ?>

        <?php if (!$projects): ?>
          <div class="empty-state">
            <i data-lucide="folder-open"></i>
            <p>Our portfolio is being updated. Please check back shortly.</p>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <section class="section section--tint">
    <div class="container">
      <div class="split-grid">
        <div class="split-copy reveal">
          <span class="eyebrow">The Common Thread</span>
          <h2 class="section-title">Every project starts with a measurable goal.</h2>
          <p>We do not begin with a moodboard. We begin with the outcome you need: more qualified leads, higher conversion, a clearer story, or a product people can use without frustration.</p>
          <p>That focus keeps the work honest. It also makes the results easier to see, discuss, and improve after launch.</p>
          <a class="btn btn-primary" href="<?= e(url('contact.php')) ?>">
            Discuss Your Project
            <i data-lucide="arrow-right"></i>
          </a>
        </div>

        <div class="split-media reveal delay-2">
          <img src="<?= e(img_src('assets/img/scenes/portfolio-review.svg')) ?>" alt="Designers reviewing a project on a large screen" width="1000" height="750" loading="lazy">
          <div class="media-badge">
            <span class="icon-tile icon-tile--sm tint-orange"><i data-lucide="trending-up"></i></span>
            <span>
              <strong>38% average lift</strong>
              <span>Across recent conversion-focused launches</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="cta-section">
    <div class="container">
      <div class="cta-banner reveal">
        <div class="cta-copy">
          <span class="eyebrow">Your Project Could Be Next</span>
          <h2>Let's create work worth showing off.</h2>
          <p>Tell us about your business and where you want to go. We will help you find the clearest route to get there.</p>
          <button class="btn btn-white" type="button" data-open-modal>
            Start Your Project
            <i data-lucide="arrow-up-right"></i>
          </button>
        </div>
        <div class="cta-media">
          <img src="<?= e(img_src('assets/img/scenes/portfolio-win.svg')) ?>" alt="Creative team celebrating a project launch" loading="lazy">
        </div>
      </div>
    </div>
  </section>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
