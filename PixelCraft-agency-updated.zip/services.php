<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Digital Services';
$pageDescription = 'Explore PixelCraft services: website development, UI/UX design, branding, digital marketing, social media management, and content creation.';
$activePage = 'services';

$services = featured_services(6);
$tints = ['tint-blue', 'tint-violet', 'tint-orange', 'tint-green', 'tint-cyan', 'tint-red'];

require __DIR__ . '/includes/header.php';
?>
<main id="mainContent">

  <section class="page-hero">
    <div class="container">
      <div class="page-hero__inner reveal">
        <nav class="breadcrumbs" aria-label="Breadcrumb">
          <a href="<?= e(url('index.php')) ?>">Home</a>
          <i data-lucide="chevron-right"></i>
          <span aria-current="page">Services</span>
        </nav>
        <span class="eyebrow">What We Do</span>
        <h1>Digital services designed to move your business forward.</h1>
        <p>Six connected capabilities, one senior team. Choose a single service or bring us in end-to-end — either way, you get strategy, craft, and accountability from day one.</p>
        <div class="hero-actions">
          <button class="btn btn-primary" type="button" data-open-modal>
            Discuss Your Project
            <i data-lucide="arrow-up-right"></i>
          </button>
          <a class="btn btn-outline" href="<?= e(url('portfolio.php')) ?>">See the Results</a>
        </div>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="section-head reveal">
        <div class="section-head__copy">
          <span class="eyebrow">Our Capabilities</span>
          <h2 class="section-title">Expertise that works together.</h2>
          <p class="section-subtitle">Every service is delivered by senior specialists and shaped around your goals, timeline, and internal team.</p>
        </div>
      </div>

      <div class="services-grid">
        <?php foreach ($services as $index => $service): ?>
          <article class="service-card reveal delay-<?= (int) (($index % 3) + 1) ?>" id="<?= e($service['slug']) ?>">
            <span class="icon-tile <?= e($tints[$index % count($tints)]) ?>"><i data-lucide="<?= e($service['icon']) ?>"></i></span>
            <h3><?= e($service['title']) ?></h3>
            <p><?= e($service['description']) ?></p>
            <a class="card-arrow" href="<?= e(url('contact.php?service=' . urlencode($service['title']))) ?>" aria-label="Enquire about <?= e($service['title']) ?>">
              <i data-lucide="arrow-up-right"></i>
            </a>
          </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section class="section section--tint">
    <div class="container">
      <div class="split-grid split-grid--reverse">
        <div class="split-media reveal">
          <img src="<?= e(img_src('assets/img/scenes/services-design.svg')) ?>" alt="Designer working on a digital interface" width="1000" height="750" loading="lazy">
          <div class="media-badge">
            <span class="icon-tile icon-tile--sm tint-green"><i data-lucide="badge-check"></i></span>
            <span>
              <strong>Senior-only delivery</strong>
              <span>No junior hand-offs</span>
            </span>
          </div>
        </div>

        <div class="split-copy reveal delay-2">
          <span class="eyebrow">How We Deliver</span>
          <h2 class="section-title">A clear scope, a steady cadence, no surprises.</h2>
          <p>We begin every engagement with a short discovery sprint so the scope is grounded in reality. From there, you get a weekly rhythm of progress, decisions, and next steps.</p>
          <ul class="check-list">
            <li><span class="check-icon"><i data-lucide="check"></i></span> Fixed scope and transparent estimates</li>
            <li><span class="check-icon"><i data-lucide="check"></i></span> Weekly demos and written updates</li>
            <li><span class="check-icon"><i data-lucide="check"></i></span> Post-launch support and training</li>
          </ul>
          <a class="btn btn-primary" href="<?= e(url('contact.php')) ?>">
            Start a Conversation
            <i data-lucide="arrow-right"></i>
          </a>
        </div>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="section-head reveal">
        <div class="section-head__copy">
          <span class="eyebrow">Our Process</span>
          <h2 class="section-title">From first conversation to launch.</h2>
        </div>
      </div>

      <div class="process-grid">
        <article class="process-step reveal delay-1">
          <h3>Discovery</h3>
          <p>We clarify goals, audiences, constraints, and the metrics that will define success.</p>
        </article>
        <article class="process-step reveal delay-2">
          <h3>Strategy</h3>
          <p>We define the experience, priorities, and roadmap before design begins.</p>
        </article>
        <article class="process-step reveal delay-3">
          <h3>Design &amp; Build</h3>
          <p>Design and engineering work together in short cycles with regular reviews.</p>
        </article>
        <article class="process-step reveal delay-3">
          <h3>Launch &amp; Grow</h3>
          <p>We ship, measure, refine, and support your team through the next phase.</p>
        </article>
      </div>
    </div>
  </section>

  <section class="section section--tint">
    <div class="container">
      <div class="faq-layout">
        <div class="faq-copy reveal">
          <span class="eyebrow">Common Questions</span>
          <h2 class="section-title">Good to know before we start.</h2>
          <p class="section-subtitle">Still curious about something? Send us a note and we will answer honestly.</p>
          <button class="btn btn-outline" type="button" data-open-modal>
            Ask a Question
            <i data-lucide="message-circle"></i>
          </button>
        </div>

        <div class="faq-list reveal delay-2">
          <div class="faq-item is-open">
            <button class="faq-question" type="button" aria-expanded="true">
              How long does a typical website project take?
              <i data-lucide="plus"></i>
            </button>
            <div class="faq-answer" aria-hidden="false">
              <div><p>Most marketing websites take 6–10 weeks from kickoff to launch. Larger platforms and e-commerce builds usually run 10–16 weeks depending on scope, integrations, and content readiness.</p></div>
            </div>
          </div>
          <div class="faq-item">
            <button class="faq-question" type="button" aria-expanded="false">
              What does a project cost?
              <i data-lucide="plus"></i>
            </button>
            <div class="faq-answer" aria-hidden="true">
              <div><p>Every project is scoped individually. After a short discovery conversation, we provide a fixed proposal with clear deliverables, milestones, and payment terms so there are no surprises.</p></div>
            </div>
          </div>
          <div class="faq-item">
            <button class="faq-question" type="button" aria-expanded="false">
              Can you work with our in-house team?
              <i data-lucide="plus"></i>
            </button>
            <div class="faq-answer" aria-hidden="true">
              <div><p>Absolutely. Many of our best partnerships are collaborative. We can lead a workstream, support your designers and developers, or provide strategic direction while your team executes.</p></div>
            </div>
          </div>
          <div class="faq-item">
            <button class="faq-question" type="button" aria-expanded="false">
              Do you offer ongoing support?
              <i data-lucide="plus"></i>
            </button>
            <div class="faq-answer" aria-hidden="true">
              <div><p>Yes. We offer monthly support plans covering maintenance, small improvements, analytics reviews, and campaign optimisation. Many clients continue with us long after launch.</p></div>
            </div>
          </div>
          <div class="faq-item">
            <button class="faq-question" type="button" aria-expanded="false">
              How do we get started?
              <i data-lucide="plus"></i>
            </button>
            <div class="faq-answer" aria-hidden="true">
              <div><p>Send us a message through the contact form or book a free consultation. We will reply within one business day to schedule a short discovery call.</p></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="cta-section">
    <div class="container">
      <div class="cta-banner reveal">
        <div class="cta-copy">
          <span class="eyebrow">Ready When You Are</span>
          <h2>Let's turn your next idea into measurable growth.</h2>
          <p>Share your goals and we will suggest the most direct path to get there — even if that means a smaller engagement to start.</p>
          <button class="btn btn-white" type="button" data-open-modal>
            Get a Free Proposal
            <i data-lucide="arrow-up-right"></i>
          </button>
        </div>
        <div class="cta-media">
          <img src="<?= e(img_src('assets/img/scenes/services-kanban.svg')) ?>" alt="PixelCraft team collaborating around a table" loading="lazy">
        </div>
      </div>
    </div>
  </section>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
